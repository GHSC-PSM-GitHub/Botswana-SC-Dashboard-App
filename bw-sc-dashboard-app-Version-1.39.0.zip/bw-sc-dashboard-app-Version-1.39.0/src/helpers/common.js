export const getNextPeriod = (ym) => {
  //ym = "202103";
  let year = parseInt(ym.substring(0, 4));
  let month = parseInt(ym.substring(4));

  if (month == 12) {
    month = 1;
    year = year + 1;
  } else {
    month = month + 1;
  }

  ym = year + month.toString().padStart(2, "0");

  return ym;
};

export const GetSortOrder = () => {
  return function (a, b) {
    if (a.startValue > b.startValue) {
      return 1;
    } else if (a.startValue < b.startValue) {
      return -1;
    }
    return 0;
  };
};

export const postData = async (url = "", data = {}) => {
  const response = await fetch(url, {
    method: "POST",
    // mode: "cors", // no-cors, *cors, same-origin
    cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
    credentials: "include", // include, *same-origin, omit
    headers: {
      "Content-Type": "application/csv",
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
    redirect: "follow", // manual, *follow, error
    referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
    body: data, // body data type must match "Content-Type" header
  });
  return response.json(); // parses JSON response into native JavaScript objects
};