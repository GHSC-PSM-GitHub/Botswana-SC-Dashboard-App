import React, { useEffect, useState } from "react";
import { useConfig } from "@dhis2/app-runtime";
import { postData } from "./common";

const DeleteDataValues = ({ onComplete, vJsonData, resposeSaveJson }) => {
  const { baseUrl } = useConfig();

  const apiUrl = baseUrl + "/api/dataValueSets";

  const [loading, setLoading] = useState(false);
  const [called, setCalled] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    postData(apiUrl, vJsonData).then((data) => {
      console.log("DeleteDataValues dhis2 respose: ", data);
      onComplete();
      resposeSaveJson(called, loading, error);
    });
  }, []);
  return <></>;
};

export { DeleteDataValues }
