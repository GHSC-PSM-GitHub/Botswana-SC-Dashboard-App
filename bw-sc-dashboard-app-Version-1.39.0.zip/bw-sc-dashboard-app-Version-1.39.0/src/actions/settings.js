import { useState, useEffect } from 'react'
import { useDataEngine } from '@dhis2/app-runtime'

const artInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [art_loading, setLoading] = useState(true)
    const [art_req, setReq] = useState(0)
    const [art_data, setData] = useState(0)
    const [art_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){

                if (request.readyState === 4){

                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    }
                    setReq(request)
                    setLoading(false)
                }
            };

            request.send();
    }, [])

    return { art_loading, art_req, art_data, art_error }
}

const venInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [ven_loading, setLoading] = useState(true)
    const [ven_req, setReq] = useState(0)
    const [ven_data, setData] = useState(0)
    const [ven_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){

                if (request.readyState === 4){

                    if (request.status === 404) {
                        engine.mutate(mutationJson, {             
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    }
                    setReq(request)
                    setLoading(false)
                }
            };

            request.send();
    }, [])

    return { ven_loading, ven_req, ven_data, ven_error }
}

const labInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [lab_loading, setLoading] = useState(true)
    const [lab_req, setReq] = useState(0)
    const [lab_data, setData] = useState(0)
    const [lab_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){

                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {             
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })                                                
                    } 
                    setReq(request)
                    setLoading(false)
                }
                

            };

            request.send();
    }, [])

    return { lab_loading, lab_req, lab_data, lab_error }
}

const labTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [labTemplate_loading, setLoading] = useState(true)
    const [labTemplate_req, setReq] = useState(0)
    const [labTemplate_data, setData] = useState(0)
    const [labTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { labTemplate_loading, labTemplate_req, labTemplate_data, labTemplate_error }
}

const labTemplateUpdateSettings = (mutationJson) => {

    const engine = useDataEngine()
    const [labTemplate_update_loading, setLoading] = useState(true)
    const [labTemplate_update_req, setReq] = useState(0)
    const [labTemplate_update_data, setData] = useState(0)
    const [labTemplate_update_error, setError] = useState(0)

    useEffect(() => {
			engine.mutate(mutationJson, {
					onComplete: data => {
							setData(data)
					},
					onError: error => {
							setError(error)
							console.error('error: ', error)
					},
			})
    }, [])

    return { labTemplate_update_loading, labTemplate_update_req, labTemplate_update_data, labTemplate_update_error }
}

const venTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [venTemplate_loading, setLoading] = useState(true)
    const [venTemplate_req, setReq] = useState(0)
    const [venTemplate_data, setData] = useState(0)
    const [venTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { venTemplate_loading, venTemplate_req, venTemplate_data, venTemplate_error }
}

const venTemplateUpdateSettings = (mutationJson) => {
    const engine = useDataEngine()
    const [venTemplate_update_loading, setLoading] = useState(true)
    const [venTemplate_update_req, setReq] = useState(0)
    const [venTemplate_update_data, setData] = useState(0)
    const [venTemplate_update_error, setError] = useState(0)

    useEffect(() => {
			engine.mutate(mutationJson, {
					onComplete: data => {
						setData(data)
					},
					onError: error => {
						setError(error)
						console.error('error: ', error)
					},
			})
    }, [])

    return { venTemplate_update_loading, venTemplate_update_req, venTemplate_update_data, venTemplate_update_error }
}

const artLogTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [artLogTemplate_loading, setLoading] = useState(true)
    const [artLogTemplate_req, setReq] = useState(0)
    const [artLogTemplate_data, setData] = useState(0)
    const [artLogTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { artLogTemplate_loading, artLogTemplate_req, artLogTemplate_data, artLogTemplate_error }
}

const artRegTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [artRegTemplate_loading, setLoading] = useState(true)
    const [artRegTemplate_req, setReq] = useState(0)
    const [artRegTemplate_data, setData] = useState(0)
    const [artRegTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { artRegTemplate_loading, artRegTemplate_req, artRegTemplate_data, artRegTemplate_error }
}
  
const artTemplateUpdateSettings = (mutationJson) => {

const engine = useDataEngine()
const [artTemplate_update_loading, setLoading] = useState(true)
const [artTemplate_update_req, setReq] = useState(0)
const [artTemplate_update_data, setData] = useState(0)
const [artTemplate_update_error, setError] = useState(0)

useEffect(() => {
    engine.mutate(mutationJson, {
        onComplete: data => {
        setData(data)
        },
        onError: error => {
        setError(error)
        console.error('error: ', error)
        },
    })
}, [])

return { artTemplate_update_loading, artTemplate_update_req, artTemplate_update_data, artTemplate_update_error }
}

const cmsInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [cms_loading, setLoading] = useState(true)
    const [cms_req, setReq] = useState(0)
    const [cms_data, setData] = useState(0)
    const [cms_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){

                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    }
                    setReq(request)
                    setLoading(false)
                }

            };

            request.send();
    }, [])

    return { cms_loading, cms_req, cms_data, cms_error }
}

const cmsLabTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [cmsLabTemplate_loading, setLoading] = useState(true)
    const [cmsLabTemplate_req, setReq] = useState(0)
    const [cmsLabTemplate_data, setData] = useState(0)
    const [cmsLabTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { cmsLabTemplate_loading, cmsLabTemplate_req, cmsLabTemplate_data, cmsLabTemplate_error }
}

const cmsLabTemplateUpdateSettings = (mutationJson) => {

    const engine = useDataEngine()
    const [cmsLabTemplate_update_loading, setLoading] = useState(true)
    const [cmsLabTemplate_update_req, setReq] = useState(0)
    const [cmsLabTemplate_update_data, setData] = useState(0)
    const [cmsLabTemplate_update_error, setError] = useState(0)

    useEffect(() => {
			engine.mutate(mutationJson, {
					onComplete: data => {
							setData(data)
					},
					onError: error => {
							setError(error)
							console.error('error: ', error)
					},
			})
    }, [])

    return { cmsLabTemplate_update_loading, cmsLabTemplate_update_req, cmsLabTemplate_update_data, cmsLabTemplate_update_error }
}

const cmsVenTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [cmsVenTemplate_loading, setLoading] = useState(true)
    const [cmsVenTemplate_req, setReq] = useState(0)
    const [cmsVenTemplate_data, setData] = useState(0)
    const [cmsVenTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { cmsVenTemplate_loading, cmsVenTemplate_req, cmsVenTemplate_data, cmsVenTemplate_error }
}

const cmsVenTemplateUpdateSettings = (mutationJson) => {

    const engine = useDataEngine()
    const [cmsVenTemplate_update_loading, setLoading] = useState(true)
    const [cmsVenTemplate_update_req, setReq] = useState(0)
    const [cmsVenTemplate_update_data, setData] = useState(0)
    const [cmsVenTemplate_update_error, setError] = useState(0)

    useEffect(() => {
			engine.mutate(mutationJson, {
					onComplete: data => {
							setData(data)
					},
					onError: error => {
							setError(error)
							console.error('error: ', error)
					},
			})
    }, [])

    return { cmsVenTemplate_update_loading, cmsVenTemplate_update_req, cmsVenTemplate_update_data, cmsVenTemplate_update_error }
}

const pipelineInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [art_loading, setLoading] = useState(true)
    const [art_req, setReq] = useState(0)
    const [art_data, setData] = useState(0)
    const [art_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){

                if (request.readyState === 4){

                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    }
                    setReq(request)
                    setLoading(false)
                }
            };

            request.send();
    }, [])

    return { art_loading, art_req, art_data, art_error }
}

const pipelineTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [pipelineTemplate_loading, setLoading] = useState(true)
    const [pipelineTemplate_req, setReq] = useState(0)
    const [pipelineTemplate_data, setData] = useState(0)
    const [pipelineTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { pipelineTemplate_loading, pipelineTemplate_req, pipelineTemplate_data, pipelineTemplate_error }
}
  
const pipelineTemplateUpdateSettings = (mutationJson) => {

const engine = useDataEngine()
const [pipelineTemplate_update_loading, setLoading] = useState(true)
const [pipelineTemplate_update_req, setReq] = useState(0)
const [pipelineTemplate_update_data, setData] = useState(0)
const [pipelineTemplate_update_error, setError] = useState(0)

useEffect(() => {
    engine.mutate(mutationJson, {
        onComplete: data => {
        setData(data)
        },
        onError: error => {
        setError(error)
        console.error('error: ', error)
        },
    })
}, [])

return { pipelineTemplate_update_loading, pipelineTemplate_update_req, pipelineTemplate_update_data, pipelineTemplate_update_error }
}

// pipelineInitialSettings

const generalInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [general_loading, setLoading] = useState(true)
    const [general_req, setReq] = useState(0)
    const [general_data, setData] = useState(0)
    const [general_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){

                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    }
                    setReq(request)
                    setLoading(false)
                }

            };

            request.send();
    }, [])

    return { general_loading, general_req, general_data, general_error }
}

const labEquipmentTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [pipelineTemplate_loading, setLoading] = useState(true)
    const [pipelineTemplate_req, setReq] = useState(0)
    const [pipelineTemplate_data, setData] = useState(0)
    const [pipelineTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { pipelineTemplate_loading, pipelineTemplate_req, pipelineTemplate_data, pipelineTemplate_error }
}

const labTestTemplateInitialSettings = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [pipelineTemplate_loading, setLoading] = useState(true)
    const [pipelineTemplate_req, setReq] = useState(0)
    const [pipelineTemplate_data, setData] = useState(0)
    const [pipelineTemplate_error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();  
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                        engine.mutate(mutationJson, {
                            onComplete: data => {
                                setData(data)
                            },
                            onError: error => {
                                setError(error)
                                console.error('error: ', error)
                            },
                        })
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { pipelineTemplate_loading, pipelineTemplate_req, pipelineTemplate_data, pipelineTemplate_error }
}

export { artInitialSettings, venInitialSettings, labInitialSettings, cmsInitialSettings, generalInitialSettings, labTemplateInitialSettings, labTemplateUpdateSettings, venTemplateInitialSettings, venTemplateUpdateSettings, artLogTemplateInitialSettings, artRegTemplateInitialSettings, artTemplateUpdateSettings, cmsLabTemplateInitialSettings, cmsVenTemplateInitialSettings, cmsLabTemplateUpdateSettings, cmsVenTemplateUpdateSettings, pipelineInitialSettings, pipelineTemplateInitialSettings, pipelineTemplateUpdateSettings,  labEquipmentTemplateInitialSettings, labTestTemplateInitialSettings }