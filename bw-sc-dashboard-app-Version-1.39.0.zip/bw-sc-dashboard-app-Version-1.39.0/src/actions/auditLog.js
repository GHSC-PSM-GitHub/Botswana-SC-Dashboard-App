import { useState, useEffect } from 'react'
import { useDataMutation, useDataQuery, DataQuery, useDataEngine } from '@dhis2/app-runtime';

const useImportTemplateAppLogs = (Url, mutationJson) => {

    const engine = useDataEngine()
    const [loading, setLoading] = useState(true)
    const [req, setReq] = useState(0)
    const [data, setData] = useState(0)
    const [error, setError] = useState(0)

    useEffect(() => {
            var request = new XMLHttpRequest();
            request.open('GET', Url, true);

            request.withCredentials = true;
            request.onreadystatechange = function(){
                if (request.readyState === 4){
                    if (request.status === 404) {
                      try{
                        engine.mutate(mutationJson, {             
                          onComplete: data => {
                              setData(data)
                          },
                          onError: error => {
                              setError(error)
                              console.error('error: ', error)
                          },
                        })
                      }catch{
                        
                      }
                    } 
                    setReq(request)
                    setLoading(false)
                }
            };
            request.send();
    }, [])

    return { loading, req, data, error }
}

const ExcelImportAppLogsJson = ({ onComplete, query, importTemplateLogsJson, onResponse }) => {
  // query['type'] = importTemplateLogsJson.length < 2 ? "create" : "update"
  query['type'] = "update"
  query['data'] = importTemplateLogsJson
  const [mutate, { called, loading, error, data }] = useDataMutation(query, {
    onComplete: data => {
      onComplete(data);
    },
    onError: error => {
      console.error('error: ', error.message)
    }
  })
	useEffect(() => {
    mutate();
  }, []);
  onResponse(called, loading, error, data);
  return (
    <>
    </>
  )
}

export { useImportTemplateAppLogs, ExcelImportAppLogsJson }