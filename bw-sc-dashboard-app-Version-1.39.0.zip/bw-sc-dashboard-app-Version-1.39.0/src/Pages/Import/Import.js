import React, { Component } from 'react';

class Import extends Component {

    constructor(props) {
		super(props);
		this.state = {

		}
	}

    render() {
        return (
          <>
            <h2>Import</h2>
            <p>
              This is the data importing menu. It is used for uploading LMIS
              reports (ARVs, Lab, and VEN), CMS Stock Situation Report, and
              PipeLine/QAT reports. The reports are uploaded monthly by the CMS
              LMIS Officers. All data should be prepared in pre-defined standard
              excel templates for each report. Any deviation from the standard
              templates will cause errors during the importing process. The
              uploaded data should be from end of a month for all data sources.
            </p>
          </>
        );
    }
}

export default Import;
