import classes from "./LoadingSpinner.module.css";

const LoadingSpinner = () => {
  return (
    <center style={{marginTop:"100px"}}>
      <div className={classes.spinner}></div>
    </center>
  );
};

export default LoadingSpinner;
