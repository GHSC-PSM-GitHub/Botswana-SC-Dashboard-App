import classes from "./LoadingSpinner.module.css";

const LoadingSpinnerOpaque = () => {
  return (
    <div className="sw_spinner">
      <center>
        <div className={classes.spinner}></div>
      </center>
    </div>
  );
};

export default LoadingSpinnerOpaque;
