import React, { useEffect, useState } from "react";
import Constants from "../../helpers/constants";
import moment from "moment";
import { useAlert, useConfig, useDataEngine } from "@dhis2/app-runtime";
import CustomSpinnerButton from "../../components/CustomSpinnerButton/CustomSpinnerButton";
import "./ImportQATSPlanData.css";
import { postData } from "../../helpers/common";
// import planningUnits from "./planningUnits";

// {
//   "AdjustmentOptionSet": "I1wspo7Dzoq",
//   "AdminRole": "iD0vDEOG4C4",
//   "LossOptionSet": "ZsaWeD2rYvk",
//   "OperatorRole": "wMduLvLoRbt",
//   "QATImportALL": 1,
//   "UserGuidURL": "https://drive.google.com/file/d/1jDkxSN_xslIhcCvdrf4EFRvRXNBFOILU/view"
// }

const genSettingsQuery = {
  dataStore: {
    resource: `dataStore/Excel-Import-App/General-Settings`,
  },
};

const qatTemplateQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.QAT_Template}`,
  },
};

const qatTemplateUpdateMutation = (datavalue) => {
  return {
    resource: `dataStore/${Constants.namespace}/${Constants.GeneralKey}`,
    type: "update",
    data: datavalue,
  };
};

const orgUnitsQuery = {
  orgUnitGroups: {
    resource: "organisationUnitGroups",
    id: "wPYnJoyEDaQ",
    params: {
      fields: "organisationUnits[id,displayName]",
    },
  },
};

const getViewRow = async (row, ym) => {
  const ymMap = {};
  //const OpeningBalanceTest = [0, "", ""];
  const viewRow = [];
  const OpeningBalance = [];
  const ForecastConsumption = [];
  const Shipments = [];
  const Received = [];
  const ShippedArrived = [];
  const OnHoldShipments = [];
  const ExpiredStock = [];
  const Ordered = [];
  const Planned = [];
  const Adjustments = [];
  const EndingBalance = [];
  const AMC = [];
  const MonthsOfStock = [];

  ym.forEach((o, i) => {
    ymMap[o] = i + 3;
    // OpeningBalanceTest.push(0);
    OpeningBalance.push(0);
    ForecastConsumption.push(0);
    Shipments.push(0);
    Received.push(0);
    ShippedArrived.push(0);
    OnHoldShipments.push(0);
    ExpiredStock.push(0);
    Ordered.push(0);
    Planned.push(0);
    Adjustments.push(0);
    EndingBalance.push(0);
    AMC.push(0);
    MonthsOfStock.push(0);
  });

  // console.log("OpeningBalanceTest: ", OpeningBalanceTest);
  // console.log("ymMap: ", ymMap);

  // const valueToInsert = 4;
  // const position = 3; // Insert at index 3

  // OpeningBalanceTest.splice(position, 0, valueToInsert);

  // console.log(OpeningBalanceTest); // Output: [1, 2, 3, 4, 5, 6]

  //console.log("row: ", row);
  // const viewRow = [];
  // const OpeningBalance = [];
  // const ForecastConsumption = [];
  // const Shipments = [];
  // const Received = [];
  // const ShippedArrived = [];
  // const OnHoldShipments = [];
  // const ExpiredStock = [];
  // const Ordered = [];
  // const Planned = [];
  // const Adjustments = [];
  // const EndingBalance = [];
  // const AMC = [];
  // const MonthsOfStock = [];

  row.forEach((obj, i) => {
    // console.log("obj: ", obj);
    if (i === 0) {
      // OpeningBalanceTest[0] = obj.planningUnitId;
      OpeningBalance[0] = obj.planningUnitId;
      ForecastConsumption[0] = obj.planningUnitId;
      Shipments[0] = obj.planningUnitId;
      Received[0] = obj.planningUnitId;
      ShippedArrived[0] = obj.planningUnitId;
      OnHoldShipments[0] = obj.planningUnitId;
      ExpiredStock[0] = obj.planningUnitId;
      Ordered[0] = obj.planningUnitId;
      Planned[0] = obj.planningUnitId;
      Adjustments[0] = obj.planningUnitId;
      EndingBalance[0] = obj.planningUnitId;
      AMC[0] = obj.planningUnitId;
      MonthsOfStock[0] = obj.planningUnitId;

      // OpeningBalance.push(obj.planningUnitId);
      // ForecastConsumption.push(obj.planningUnitId);
      // Shipments.push(obj.planningUnitId);
      // Received.push(obj.planningUnitId);
      // ShippedArrived.push(obj.planningUnitId);
      // OnHoldShipments.push(obj.planningUnitId);
      // ExpiredStock.push(obj.planningUnitId);
      // Ordered.push(obj.planningUnitId);
      // Planned.push(obj.planningUnitId);
      // Adjustments.push(obj.planningUnitId);
      // EndingBalance.push(obj.planningUnitId);
      // AMC.push(obj.planningUnitId);
      // MonthsOfStock.push(obj.planningUnitId);

      //OpeningBalanceTest[1] = obj.planningUnit;
      OpeningBalance[1] = obj.planningUnit;
      ForecastConsumption[1] = obj.planningUnit;
      Shipments[1] = obj.planningUnit;
      Received[1] = obj.planningUnit;
      ShippedArrived[1] = obj.planningUnit;
      OnHoldShipments[1] = obj.planningUnit;
      ExpiredStock[1] = obj.planningUnit;
      Ordered[1] = obj.planningUnit;
      Planned[1] = obj.planningUnit;
      Adjustments[1] = obj.planningUnit;
      EndingBalance[1] = obj.planningUnit;
      AMC[1] = obj.planningUnit;
      MonthsOfStock[1] = obj.planningUnit;

      // OpeningBalance.push(obj.planningUnit);
      // ForecastConsumption.push(obj.planningUnit);
      // Shipments.push(obj.planningUnit);
      // Received.push(obj.planningUnit);
      // ShippedArrived.push(obj.planningUnit);
      // OnHoldShipments.push(obj.planningUnit);
      // ExpiredStock.push(obj.planningUnit);
      // Ordered.push(obj.planningUnit);
      // Planned.push(obj.planningUnit);
      // Adjustments.push(obj.planningUnit);
      // EndingBalance.push(obj.planningUnit);
      // AMC.push(obj.planningUnit);
      // MonthsOfStock.push(obj.planningUnit);

      // Supply Plan parameters
      // OpeningBalanceTest[2] = "Opening Balance";
      // OpeningBalanceTest[2] = "Opening Balance";
      OpeningBalance[2] = "Opening Balance";
      ForecastConsumption[2] = "Forecast Consumption";
      Shipments[2] = "Shipments";
      Received[2] = "Received";
      ShippedArrived[2] = "Shipped Arrived";
      OnHoldShipments[2] = "OnHold Shipments";
      ExpiredStock[2] = "Expired Stock";
      Ordered[2] = "Ordered";
      Planned[2] = "Planned";
      Adjustments[2] = "Adjustments";
      EndingBalance[2] = "Ending Balance";
      AMC[2] = "AMC";
      MonthsOfStock[2] = "Months Of Stock";
      // OpeningBalance.push("Opening Balance");
      // ForecastConsumption.push("Forecast Consumption");
      // Shipments.push("Shipments");
      // Received.push("Received");
      // ShippedArrived.push("Shipped Arrived");
      // OnHoldShipments.push("OnHold Shipments");
      // ExpiredStock.push("Expired Stock");
      // Ordered.push("Ordered");
      // Planned.push("Planned");
      // Adjustments.push("Adjustments");
      // EndingBalance.push("Ending Balance");
      // AMC.push("AMC");
      // MonthsOfStock.push("Months Of Stock");
    }

    //OpeningBalanceTest[ymMap[obj.transDate]] = obj.OpeningBalance;
    OpeningBalance[ymMap[obj.transDate]] = obj.OpeningBalance;
    ForecastConsumption[ymMap[obj.transDate]] = obj.ForecastConsumption;
    Shipments[ymMap[obj.transDate]] = obj.Shipments;
    Received[ymMap[obj.transDate]] = obj.Received;
    ShippedArrived[ymMap[obj.transDate]] = obj.ShippedArrived;
    OnHoldShipments[ymMap[obj.transDate]] = obj.OnHoldShipments;
    ExpiredStock[ymMap[obj.transDate]] = obj.ExpiredStock;
    Ordered[ymMap[obj.transDate]] = obj.Ordered;
    Planned[ymMap[obj.transDate]] = obj.Planned;
    Adjustments[ymMap[obj.transDate]] = obj.Adjustments;
    EndingBalance[ymMap[obj.transDate]] = obj.EndingBalance;
    AMC[ymMap[obj.transDate]] = obj.AMC;
    MonthsOfStock[ymMap[obj.transDate]] = obj.MonthsOfStock;

    // OpeningBalance.push(obj.OpeningBalance);
    // ForecastConsumption.push(obj.ForecastConsumption);
    // Shipments.push(obj.Shipments);
    // Received.push(obj.Received);
    // ShippedArrived.push(obj.ShippedArrived);
    // OnHoldShipments.push(obj.OnHoldShipments);
    // ExpiredStock.push(obj.ExpiredStock);
    // Ordered.push(obj.Ordered);
    // Planned.push(obj.Planned);
    // Adjustments.push(obj.Adjustments);
    // EndingBalance.push(obj.EndingBalance);
    // AMC.push(obj.AMC);
    // MonthsOfStock.push(obj.MonthsOfStock);
  });

  // console.log("OpeningBalanceTest: ", OpeningBalanceTest);

  viewRow.push(OpeningBalance);
  viewRow.push(ForecastConsumption);
  viewRow.push(Shipments);
  viewRow.push(Received);
  viewRow.push(ShippedArrived);
  viewRow.push(OnHoldShipments);
  viewRow.push(ExpiredStock);
  viewRow.push(Ordered);
  viewRow.push(Planned);
  viewRow.push(Adjustments);
  viewRow.push(EndingBalance);
  viewRow.push(AMC);
  viewRow.push(MonthsOfStock);
  return viewRow;
};

const getViewTable = async (vTable, ym) => {
  const results = await Promise.all(
    vTable.map(async (row) => {
      return await getViewRow(row, ym); // Assuming getViewRow returns a value
    })
  );
  return results;
};

function formatDate(dateStr) {
  const options = { year: "numeric", month: "short" };
  return new Date(dateStr).toLocaleDateString("en-US", options);
}

const ImportQATSPlanData = () => {
  const { baseUrl } = useConfig();

  const apiUrl =
    baseUrl +
    `/api/dataValueSets?dataset=${process.env.REACT_APP_QAT_DATASET_ID}`;

  const engine = useDataEngine();

  const [isLoading, setIsLoading] = useState(false);

  const [results, setResults] = useState([]);

  const [headers, setHeaders] = useState([]);

  const [tableData, setTableData] = useState([]);

  const [isShowTable, setIsShowTable] = useState(false);

  // Create the alert
  const { show: showSuccess } = useAlert(({ Msg }) => `${Msg}`, {
    success: true,
    duration: 3000,
  });
  const { show: showCritical } = useAlert(({ Msg }) => `${Msg}`, {
    critical: true,
  });

  function getMonthsBack(months) {
    const date = new Date();
    date.setMonth(date.getMonth() - months); // Move to the 13th month ago (12 months ago)

    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Ensure two digits for the month

    return `${year}-${month}`;
  }

  const getOrgUnits = async () => {
    try {
      const orgUnitsPromis = engine.query(orgUnitsQuery);
      const orgUnits = await orgUnitsPromis;
      console.log("orgUnits: ", orgUnits.orgUnitGroups.organisationUnits);
      return orgUnits.orgUnitGroups.organisationUnits;
    } catch (error) {
      throw error;
    }
  };

  const getTemplate = async () => {
    try {
      const piplineTemplatePromis = engine.query(qatTemplateQuery);
      const template = await piplineTemplatePromis;
      return template.dataStore;
    } catch (error) {
      throw error;
    }
  };

  const sendDataToDhis2 = async (mutation) => {
    try {
      const dataPromis = engine.mutate(mutation);
      const response = await dataPromis;
      console.log("sendDataToDhis2 response: ", response);
      return response;
    } catch (error) {
      throw error;
    }
  };

  const getTime = () => {
    return moment().valueOf();
  };

  const getDifTime = (presentTime, previousTime) => {
    return (presentTime - previousTime) / 1000 + " seconds";
  };

  const getValue = (yearMonth, deCo, value) => {
    let obj = {
      period: yearMonth,
      dataElement: deCo.split("-")[0],
      categoryOptionCombo: deCo.split("-")[1],
    };

    if (value == null) {
      obj.deleted = true;
    } else {
      obj.value = value;
    }

    return obj;
  };

  const getCSV = (yearMonth, deCo, value, orgUnit) => {
    let obj = {
      period: yearMonth,
      dataElement: deCo.split("-")[0],
      categoryOptionCombo: deCo.split("-")[1],
    };

    if (value == null) {
      return `${obj.dataElement},${obj.period},${orgUnit},${obj.categoryOptionCombo},,,,,,,true\n`;
    } else {
      return `${obj.dataElement},${obj.period},${orgUnit},${obj.categoryOptionCombo},,${value},,,,,\n`;
    }
  };

  const getToken = async () => {
    const url = `${process.env.REACT_APP_API_URL}/authenticate`;
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username: process.env.REACT_APP_USER_NAME,
        password: process.env.REACT_APP_PASSWORD,
      }),
    };

    try {
      const response = await fetch(url, options);

      if (!response.ok) {
        console.log(await response.json());
        throw new Error(`HTTP error! status: ${response.status}}`);
      }

      const data = await response.json();

      const token = data.token;
      //console.log("token: ", token);
      return token;
    } catch (error) {
      throw error;
    }
  };

  const fetchData = async (token, pQATImportALL) => {
    // const genSettings = await engine.query(genSettingsQuery);
    // const genSettingsResult = genSettings.dataStore;

    // console.log("genSettingsResult: ", genSettingsResult.QATImportALL);

    const url = `${
      process.env.REACT_APP_API_URL
    }/api/export/supplyPlan/programId/2034/versionId/-1${
      pQATImportALL == 1 ? "" : "/startDate/" + getMonthsBack(12)
    }`;

    console.log("url: ", url);

    const options = {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    try {
      const response = await fetch(url, options);
      // console.log("response: ", response);
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return await response.json();
      //console.log(data);
    } catch (error) {
      //console.error("Error:", error);
      throw error;
    }
  };

  const getQatData = async () => {
    setIsLoading(true);
    const t1 = getTime();

    console.log("QAT Start: ", t1);

    // setResults((prevResults) => [...prevResults, `Logging in QAT...`]);

    try {
      const genSettings = await engine.query(genSettingsQuery);
      const genSettingsResult = genSettings.dataStore;

      console.log("genSettingsResult: ", genSettingsResult.QATImportALL);

      // setResults((prevResults) => [...prevResults, `Fetching Facility...`]);
      const orgUnits = await getOrgUnits();

      const t2 = getTime();
      console.log("Getting facility time : ", getDifTime(t2, t1));

      // prettier-ignore
      // setResults(prevResults => [...prevResults, `${orgUnits.length} rows found, passed ${ getDifTime(t2, t1)}`]);

      const orgUnitId = orgUnits[0].id;
      console.log("orgUnitId: ", orgUnitId);

      setResults((prevResults) => [
        ...prevResults,
        `Fetching Data Elements...`,
      ]);
      const template = await getTemplate();
      console.log("template: ", template);

      const t3 = getTime();
      console.log("Getting facility time : ", getDifTime(t3, t2));

      // prettier-ignore
      setResults(prevResults => [...prevResults, `${template.length} rows found, ${ getDifTime(t3, t2)}`]);

      setResults((prevResults) => [...prevResults, `Logging into QAT...`]);
      const token = await getToken();
      // console.log("token: ", token);
      const t4 = getTime();
      console.log("Token time: ", t4);

      if (!token) {
        console.error("Failed to retrieve token");
      }

      // prettier-ignore
      setResults(prevResults => [...prevResults, `Token length ${Object.keys(token).length} chars, ${ getDifTime(t4, t3)}`]);

      // prettier-ignore
      setResults((prevResults) => [...prevResults, `Fetching QAT API data...`]);

      const data = await fetchData(token, genSettingsResult.QATImportALL);
      if (!data) {
        console.error("Failed to retrieve data");
      }
      const t5 = getTime();
      console.log("Fetch Data: ", t5);

      const planningUnitList = data.planningUnitList;
      // const planningUnitList = planningUnits.planningUnitList;

      console.log(
        `Total products found in QAT API = `,
        planningUnitList.length
      );
      // prettier-ignore
      setResults(prevResults => [...prevResults, `${planningUnitList.length} Planning Unit found, ${ getDifTime(t5, t4)}`]);

      // Find the planningUnitIds found in the template array
      const foundPlanningUnits = planningUnitList.filter((unit) => {
        const planningUnitId = unit.planningUnit.planningUnitId;
        return template.some((temp) => temp.PUID === planningUnitId);
      });

      // Find the planningUnitIds not found in the template array
      const missingPlanningUnits = planningUnitList.filter((unit) => {
        const planningUnitId = unit.planningUnit.planningUnitId;
        return !template.some((temp) => temp.PUID === planningUnitId);
      });

      // console.log(missingPlanningUnits);
      console.log(
        `Missing products in data store template = `,
        missingPlanningUnits.length
      );
      // missingPlanningUnits.forEach((item) => {
      //   console.log(
      //     `${item.planningUnit.planningUnitId} - ${item.planningUnit.forecastingUnit.label.label_en}`
      //   );
      // });

      console.log(`Total matched products  = `, foundPlanningUnits.length);

      // Merge the matched planningUnits with template
      const planningUnitsMatchedWithTemplate = [];
      foundPlanningUnits.forEach((unitObj) => {
        const planningUnitId = unitObj.planningUnit.planningUnitId;

        const matchedTemplate = template.find((templateObj) => {
          return templateObj.PUID == planningUnitId;
        });

        if (matchedTemplate) {
          // prettier-ignore
          planningUnitsMatchedWithTemplate.push({...unitObj, template: matchedTemplate});
        }
      });

      // prettier-ignore
      console.log("planningUnitsMatchedWithTemplate: ", planningUnitsMatchedWithTemplate);

      let csvLine = Constants.CSV_HEADER;

      // Create dhis2 object of matched data between planningUnitList and template list
      const dataValues = [];
      let totalCsvLine = 0;
      const viewTable = [];

      // prettier-ignore
      setResults((prevResults) => [...prevResults, `Converting to Data Values....`]);

      planningUnitsMatchedWithTemplate.forEach((obj) => {
        // const planningUnitId = obj.planningUnit.planningUnitId;

        let viewItem = [];

        obj.supplyPlanData.forEach((item) => {
          const transDate = item.transDate;
          const yearMonth = transDate.slice(0, 7).replace(/-/g, "");

          obj.planningUnit.forecastingUnit.label.label_en;

          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.OpeningBalance, item.openingBalance, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.ForecastConsumption, item.actualConsumptionQty ? item.actualConsumptionQty : item.forecastedConsumptionQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.Shipments, item.manualShippedShipmentQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.Received, item.manualReceivedShipmentQty + item.erpReceivedShipmentQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.ShippedArrived, item.manualShippedShipmentQty + item.erpShippedShipmentQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.OnHoldShipments, item.manualOnholdShipmentQty + item.erpOnholdShipmentQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.ExpiredStock, item.expiredStock, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.Ordered, item.manualSubmittedShipmentQty + item.manualApprovedShipmentQty + item.erpSubmittedShipmentQty + item.erpApprovedShipmentQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.Planned, item.manualPlannedShipmentQty + item.erpPlannedShipmentQty, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.Adjustments, item.nationalAdjustment, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.EndingBalance, item.closingBalance, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.AMC, item.amc, orgUnitId);
          // prettier-ignore
          csvLine += getCSV(yearMonth, obj.template.MonthsOfStock, item.mos, orgUnitId);

          totalCsvLine += 13;

          let viewObj = {};

          viewObj.transDate = item.transDate;

          viewObj.planningUnitId = obj.planningUnit.planningUnitId;
          // prettier-ignore
          viewObj.planningUnit = obj.planningUnit.forecastingUnit.label.label_en;
          // prettier-ignore
          viewObj.OpeningBalance = item.openingBalance;
          // prettier-ignore
          viewObj.ForecastConsumption =  item.actualConsumptionQty ? item.actualConsumptionQty : item.forecastedConsumptionQty;
          // prettier-ignore
          viewObj.Shipments = item.manualShippedShipmentQty;
          // prettier-ignore
          viewObj.Received = item.manualReceivedShipmentQty + item.erpReceivedShipmentQty;
          // prettier-ignore
          viewObj.ShippedArrived =  item.manualShippedShipmentQty + item.erpShippedShipmentQty;
          // prettier-ignore
          viewObj.OnHoldShipments =  item.manualOnholdShipmentQty + item.erpOnholdShipmentQty;
          // prettier-ignore
          viewObj.ExpiredStock =  item.expiredStock;
          // prettier-ignore
          viewObj.Ordered =  item.manualSubmittedShipmentQty + item.manualApprovedShipmentQty + item.erpSubmittedShipmentQty + item.erpApprovedShipmentQty;
          // prettier-ignore
          viewObj.Planned = item.manualPlannedShipmentQty + item.erpPlannedShipmentQty;
          // prettier-ignore
          viewObj.Adjustments = item.nationalAdjustment;
          // prettier-ignore
          viewObj.EndingBalance = item.closingBalance;
          // prettier-ignore
          viewObj.AMC = item.amc;
          // prettier-ignore
          viewObj.MonthsOfStock =  item.mos;

          viewItem.push(viewObj);

          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.OpeningBalance, item.openingBalance));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.ForecastConsumption, item.actualConsumptionQty ? item.actualConsumptionQty : item.forecastedConsumptionQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.Shipments, item.manualShippedShipmentQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.Received, item.manualReceivedShipmentQty + item.erpReceivedShipmentQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.ShippedArrived, item.manualShippedShipmentQty + item.erpShippedShipmentQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.OnHoldShipments, item.manualOnholdShipmentQty + item.erpOnholdShipmentQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.ExpiredStock, item.expiredStock));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.Ordered, item.manualSubmittedShipmentQty + item.manualApprovedShipmentQty + item.erpSubmittedShipmentQty + item.erpApprovedShipmentQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.Planned, item.manualPlannedShipmentQty + item.erpPlannedShipmentQty));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.Adjustments, item.nationalAdjustment));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.EndingBalance, item.closingBalance));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.AMC, item.amc));
          // // prettier-ignore
          // dataValues.push(getValue(yearMonth, obj.template.MonthsOfStock, item.mos));
        });
        viewTable.push(viewItem);
      });

      console.log("viewTable: ", viewTable);

      const yearMonth = [];

      viewTable.forEach((row) => {
        yearMonth.push(row.map((item) => item.transDate));
      });

      const yearMonthArr = yearMonth.flat();
      console.log("yearMonthArr: ", yearMonthArr);

      const uniqueArray = [...new Set(yearMonthArr)];

      const sortedDates = uniqueArray.sort((a, b) => new Date(a) - new Date(b));
      console.log("sortedDates: ", sortedDates);

      const ym = sortedDates.map((item) => formatDate(item));
      console.log("ym: ", ym);

      const headerYm = JSON.parse(JSON.stringify(ym));

      const newElements = [
        "Planning Unit Id",
        "Planning Unit",
        "Supply Plan Parameters",
      ];

      // Add the new elements to the beginning of the array
      headerYm.unshift(...newElements);
      console.log("headerYm: ", headerYm);

      setHeaders(headerYm);

      const tableVData = await getViewTable(viewTable, sortedDates);
      console.log("tableVData: ", tableVData);

      const tableDataFlat = tableVData.flat();
      console.log("tableDataFlat: ", tableDataFlat);

      setTableData(tableDataFlat);

      // HAVE TO REMOVE THIS LINE
      // setIsShowTable(true);
      // return;

      // console.log("csvLine: ", csvLine);

      console.log("totalCsvLine: ", totalCsvLine);
      //console.log("dataValues length: ", dataValues.length);

      const t6 = getTime();
      console.log("Creating CSV lines: ", t6);
      // prettier-ignore
      setResults(prevResults => [...prevResults, `${totalCsvLine} data values ready for insert/update, ${ getDifTime(t6, t5)}`]);

      // const vJsonData = {
      //   resource: "dataValueSets",
      //   type: "create",
      //   params: {
      //     //async: true
      //     preheatCache: true,
      //   },
      //   data: {
      //     orgUnit: orgUnitId,
      //     dataValues: dataValues,
      //   },
      // };
      // console.log("vJsonData: ", vJsonData);

      //const sendDataResponse = await sendDataToDhis2(vJsonData);

      // prettier-ignore
      setResults((prevResults) => [...prevResults, `Calling DHIS2 API.....`]);
      const resultCSV = await postData(apiUrl, csvLine);
      console.log("retCSV: ", resultCSV);

      const t7 = getTime();
      console.log("Sending data to dhis2: ", t7);

      if (resultCSV && typeof resultCSV === "object" && resultCSV.length > 0) {
        setResults((prevResults) => [...prevResults, resultCSV]);
      }
      // prettier-ignore
      setResults(prevResults => [...prevResults, `QAT data imported successfully in DHIS2, ${ getDifTime(t7, t6)}`]);

      if (resultCSV.conflicts.length > 0) {
        showCritical({ Msg: JSON.stringify(resultCSV) });
        return;
      }

      if (genSettingsResult.QATImportALL == 1) {
        genSettingsResult.QATImportALL = 0;
        const mutationPromise = engine.mutate(
          qatTemplateUpdateMutation(genSettingsResult)
        );
        const mutationData = await mutationPromise;
        console.log("General-Settings updated: ", mutationData);
      }

      // prettier-ignore
      setResults(prevResults => [...prevResults, `Total elapsed time ${ getDifTime(t7, t1)}`]);

      setIsShowTable(true);

      showSuccess({ Msg: `QAT data imported successfully in DHIS2` });

      console.log(`Total time: ${getDifTime(t7, t1)}`);
    } catch (error) {
      showCritical({ Msg: error.toString() });
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleButtonClick = () => {
    setIsShowTable(false);
    setHeaders([]);
    setTableData([]);
    setResults([]);
    getQatData();
  };

  useEffect(() => {}, []);

  // Define styles
  const tableStyle = {
    borderCollapse: "collapse",
    width: "100%",
  };

  const cellStyle = {
    border: "1px solid black",
    padding: "8px",
    textAlign: "center",
    width: "70px",
  };

  const headerStyle = {
    ...cellStyle,
    position: "sticky",
    top: 0,
    backgroundColor: "#f2f2f2", // Optional: adds a light grey background to the header
    zIndex: 1, // Ensure the header is above other cells
  };

  const leftHeaderStyle = {
    ...cellStyle,
    position: "sticky",
    top: 0,
    backgroundColor: "#f2f2f2", // Optional: adds a light grey background to the header
    zIndex: 1, // Ensure the header is above other cells
    textAlign: "left",
  };

  const wideCellStyle = {
    ...cellStyle,
    width: "200px", // Adjust this value to make the 2nd and 3rd columns wider
    textAlign: "left",
  };

  return (
    <div>
      <h1>Import QAT/S. Plan Data</h1>
      <p>
        Allows import of QAT/S. Plan data by calling QAT API. Ensure you are
        connected to the internet.
      </p>

      <div className="center-container">
        <CustomSpinnerButton
          text="Import QAT/S. Plan Data"
          size="large"
          onClick={handleButtonClick}
          isLoading={isLoading} // Pass the isLoading state
        />
      </div>
      {/* <p style={{ color: "green" }}>{importStatus}</p> */}
      <div style={{ color: "green" }}>
        {results.map((result, index) => (
          <div key={index}>
            {/* <h3>Result {index + 1}</h3> */}
            <pre>
              {result && typeof result === "object"
                ? JSON.stringify(result, null, 2)
                : result.split("\n").map((line, lineIndex) => (
                    <React.Fragment key={lineIndex}>
                      {line}
                      <br />
                    </React.Fragment>
                  ))}
            </pre>
          </div>
        ))}
      </div>
      {isShowTable && (
        <div style={{ overflow: "scroll", width: "1200px", height: "500px" }}>
          <table style={tableStyle}>
            <thead>
              <tr>
                {headers.map((header, index) => (
                  <th
                    key={index}
                    style={
                      index === 1 || index === 2 ? leftHeaderStyle : headerStyle
                    }
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {row.map((cell, cellIndex) => (
                    <td
                      key={cellIndex}
                      style={
                        cellIndex === 1 || cellIndex === 2
                          ? wideCellStyle
                          : cellStyle
                      }
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ImportQATSPlanData;
