import React, { Component } from 'react';
import Dropzone from 'react-dropzone';
import styles from '../Pages.module.css';
import StatusTemplate from './statusTemplate';
import { Menu, MenuItem, Button, Table, TableHead, TableBody, TableRow, TableRowHead, TableCellHead, TableCell, CircularLoader, AlertBar } from '@dhis2/ui-core';
import Constant from '../../helpers/constants';

const LIST_ICON_WARNING = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="30px" height="30px"><path fill="#ffc107" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>
const LIST_ICON_SUCCESS = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="30px" height="30px"><path fill="#28a745" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>

const LIST_ICON_WARNING_BIG_SIZE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="50px" height="50px"><path fill="#ffc107" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>
const LIST_ICON_SUCCESS_BIG_SIZE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="50px" height="50px"><path fill="#28a745" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>

const LIST_ICON_FAILURE_BIG_SIZE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 24 24" width="40px" height="40px"><path fill="#FF0000" d="M16.971 0h-9.942l-7.029 7.029v9.941l7.029 7.03h9.941l7.03-7.029v-9.942l-7.029-7.029zm-1.402 16.945l-3.554-3.521-3.518 3.568-1.418-1.418 3.507-3.566-3.586-3.472 1.418-1.417 3.581 3.458 3.539-3.583 1.431 1.431-3.535 3.568 3.566 3.522-1.431 1.43z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>


class ShowDuplicateProducts extends Component {
  constructor( props ) {
		super( props );
		this.state = {
      loading: false
		}
	}

  componentWillMount(){
    this.setState({loading: this.props.loading});
  }

  componentWillReceiveProps(nextProps){
    if (this.state.loading && this.props.gridDataValues && this.props.gridDataValues.length>0) {
      this.setState({loading: false});
    }
  }

  getTableHeading = (duplicateProducts, type = "duplicate")=>{
    return(
      <TableRowHead dataTest="dhis2-uicore-tablerow">
        <TableCellHead dataTest="dhis2-uicore-tablecellhead">
          SI#
        </TableCellHead>
        {
          Constant.TABLE_HEADING_LIST.filter((item) => item != "MOS").map((col, key)=>{
            return(
              <TableCellHead key={key} dataTest="dhis2-uicore-tablecellhead">
                {col}
              </TableCellHead>
            )
          })
        }
      </TableRowHead>
    )
  }

  getTableList = (products, conflictKeyList, type = "duplicate")=>{
    if (products.length == 0){
      return;
    }

    if (products.length>0) {
        let columnList = ["__EMPTY", "__EMPTY_1", "__EMPTY_2", "__EMPTY_3", "__EMPTY_4", "__EMPTY_5", "__EMPTY_6", "__EMPTY_7", "__EMPTY_8", "__EMPTY_9", "__EMPTY_10", "__EMPTY_11", "__EMPTY_12", "__EMPTY_13", "__EMPTY_14", "__EMPTY_15", "__EMPTY_16"
        ]
        products.map((item, i)=>{
          if (item["__EMPTY"] == "Code") {
            columnList = Object.keys(item);
            from_index = i+3
          }
        })
        if(type == "duplicate"){
          return products.map((item, table_row)=>{
            return(
              <TableRow dataTest="dhis2-uicore-tablerow" >
                <TableCell dataTest="dhis2-uicore-tablecell" >
                  {table_row+1}
                </TableCell>
                {
                  columnList.map((col, col_key)=>{
                    return(
                      <TableCell key={col_key} dataTest="dhis2-uicore-tablecell">
                        { item[col] ? (item[col].key ?   item[col].value : item[col]) : null}
                      </TableCell>
                    )
                  })
                }
              </TableRow>
            )
          })
        }else{
          return products.map((item, table_row)=>{
            return(
              <TableRow dataTest="dhis2-uicore-tablerow" >
                <TableCell dataTest="dhis2-uicore-tablecell" >
                  {table_row+1}
                </TableCell>
                {
                  columnList.map((col, col_key)=>{
                    let keyId = null
                    if(item[col] && item[col].key){
                      keyId = item[col].key.split('-')[0]
                    }
      
                    if(["__EMPTY", "__EMPTY_1"].includes(col)){
                      return(
                        <TableCell key={col_key} dataTest="dhis2-uicore-tablecell" className={styles.cellColor}>
                          { item[col] ? (item[col].key ?   item[col].value : item[col]) : null}
                        </TableCell>
                      )
                    }else{
                      return(
                        <TableCell key={col_key} dataTest="dhis2-uicore-tablecell" className={ (keyId && conflictKeyList.includes(keyId)) ? styles.cellColor : null}>
                          { item[col] ? (item[col].key ?   item[col].value : item[col]) : null}
                        </TableCell>
                      )
                    }
                  })
                }
              </TableRow>
            )
          })
        }
        
    }
  }

  render() {
    const resultStatus = this.props.resultStatus
    let status = null
    if(resultStatus == "SUCCESS"){
      status = "SUCCESS"
    }else if(resultStatus == "WARNING" && (!this.props.conflictStatus)){
      status = "WARNING"
    }else if(resultStatus == "WARNING" && this.props.conflictStatus){
      status = "FAILURE"
    }else if(resultStatus == "ERROR"){
      status = "FAILURE"
    }
    let productCount = null
    let duplicateProducts = null
    let blankProducts = null
    let importMsg = null
    if(this.props.gridDataValues && this.props.gridDataValues.length>0){
      productCount = this.props.gridDataValues.length
    }
    if(this.props.duplicateProducts && this.props.duplicateProducts.length>0){
      duplicateProducts = this.props.gridDataValues.length
    }
    if(this.props.blankOrNegativeRocords && this.props.blankOrNegativeRocords.length>0){
      blankProducts = this.props.blankOrNegativeRocords.length
    }
    importMsg =  "Importing "+productCount+" products..." + (duplicateProducts ? "duplicate "+ (blankProducts ? "and negative/blank" : "") : "negative/blank") +" found!"

    return (
      <>
        <div className={styles.progressPanel} >
          {
            this.state.loading && <center>
              <CircularLoader className={styles.loading_icon}  dataTest="dhis2-uicore-circularloader" large />
            </center>
          }
          <div className={styles.progressTabRow}>
            <div className={styles.progressTabLeftContainer}>
              <h2>Import LAB LMIS Report - Import Progress</h2>
              <p>Step 2 of 2: Import the Excel file data into DHIS2 and calculate AMC/MOS</p>
              <ul className={styles.progressPanelList}>
                {
                  this.props.headingTitle.facilityName &&
                    <li>
                      {LIST_ICON_SUCCESS}
                      Excel template contains data for {this.props.headingTitle.facilityName} - {this.props.headingTitle.monthName} {this.props.headingTitle.year}
                    </li>
                }
                {
                  (this.props.gridDataValues && this.props.gridDataValues.length>0) &&
                  <li>
                    {LIST_ICON_WARNING}
                    {importMsg}
                  </li>
                }
              </ul>
            </div>
            {
              status && 
              <div className={styles.progressTabRightContainer}>
                <div className = {styles.importSuccessBox}>
                {
                  status == "SUCCESS" &&
                  <label>{LIST_ICON_SUCCESS_BIG_SIZE} IMPORT SUCCESS! </label>
                }
                {
                  status == "WARNING" &&
                  <label>{LIST_ICON_WARNING_BIG_SIZE} IMPORT WARNING! </label>
                }
                {
                  status == "FAILURE" &&
                  <label>{LIST_ICON_FAILURE_BIG_SIZE} IMPORT FAILURE! </label>
                }
                <br/> <br/>
                {
                  status == "WARNING" &&
                  <label className={styles.upload_another_template} >Review Import Summary below</label>
                }
                <br/>
                <label>
                  <Button
                    dataTest="dhis2-uicore-button"
                    large
                    name="Primary button"
                    onClick = {this.props.redirectToFirstStep}
                    primary
                    type="button"
                    value="default"
                    className={styles.upload_another_template}
                  >
                    UPLOAD ANOTHER TEMPLATE
                  </Button>
                </label>

                </div>
              </div>
            }
          </div>
          {
            this.props.duplicateProducts && this.props.duplicateProducts.length>0 &&
            <>
              <h2>{this.props.gridHeadingTitle}</h2>
              <div className={styles.progress_table}>
                <Table dataTest="dhis2-uicore-table">
                  <TableHead dataTest="dhis2-uicore-tablehead">
                    {
                      this.getTableHeading(this.props.duplicateProducts, "duplicate")
                    }
                  </TableHead>
                  <TableBody dataTest="dhis2-uicore-tablebody">
                  {
                    this.getTableList(this.props.duplicateProducts, this.props.conflictKeyList, "duplicate")
                  }
                  </TableBody>
                </Table>
              </div>
            </>
          }
          {
            this.props.blankOrNegativeRocords && this.props.blankOrNegativeRocords.length > 0 &&
            <>
              <h2>Products with Negative/Blank</h2>
              <div className={styles.progress_table}>
                <Table dataTest="dhis2-uicore-table">
                  <TableHead dataTest="dhis2-uicore-tablehead">
                    {
                      this.getTableHeading(this.props.blankOrNegativeRocords, "blank")
                    }
                  </TableHead>
                  <TableBody dataTest="dhis2-uicore-tablebody">
                  {
                    this.getTableList(this.props.blankOrNegativeRocords, this.props.conflictKeyList, "blank")
                  }
                  </TableBody>
                </Table>
              </div>
            </>
          }
        </div>
        
      </>
    );
  }
}

export default ShowDuplicateProducts;