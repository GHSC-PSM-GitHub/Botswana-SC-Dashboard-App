import { useConfig } from '@dhis2/app-runtime'
import Constants from '../../helpers/constants';
import { useImportTemplateAppLogs } from '../../actions/auditLog';
import { Divider } from '@dhis2/ui-core';
import styles from '../Pages.module.css';

const ImportTemplateAppLogs = (props) => {
  const { baseUrl, apiVersion } = useConfig();

let today = new Date();
let date = today.getFullYear() + '-' + (String(today.getMonth() + 1)).padStart(2, '0') + '-' + (String(today.getDate())).padStart(2, '0');

  const queryExcelImportAppLogsJson = {
    resource: "dataStore/Excel-Import-App-Logs/" + date,
    type: "create",
    data: {},
  };

  const Url = baseUrl + `/api/dataStore/Excel-Import-App-Logs/`+date
  const { loading, req, data, error } = useImportTemplateAppLogs(Url, queryExcelImportAppLogsJson)

  if(req && req.response){
    if(JSON.parse(req.response).httpStatusCode == 404){
    }else{
      if(props.importTemplateLogs && props.importTemplateLogs.length == 0 &&  Array.isArray(JSON.parse(req.response))){
        props.setImportTemplateLogs(JSON.parse(req.response));
      }
    }
  }

  return (
    <>
    </>
  );
};

export default ImportTemplateAppLogs;