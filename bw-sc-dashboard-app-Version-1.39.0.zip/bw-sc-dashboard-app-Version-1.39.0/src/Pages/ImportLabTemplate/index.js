import React, { Component } from "react";

import SecondStep from "./SecondStep";
import FirstStep from "./FirstStep";
import ImportProgressLabTemplate from "./ImportProgressLabTemplate";
import {
  InsertDataValueSets,
  GetOrgUnitGroups,
  SetCompleteDataSetRegistrations,
  GetCompleteDataSetRegistrations,
  GetLabTemplateSettings,
} from "./labTemplateApi";
import XLSX from "xlsx";
import Constants from "../../helpers/constants";
import {
  GetAppSettingsNew,
  GetOptionSets,
} from "../Settings/settingComponentApi";
import { CalculateAmcMos } from "./Calculation";
import { ExcelImportAppLogsJson } from "../../actions/auditLog";
import ShowDuplicateProducts from "./ShowDuplicateProducts";
import { DataFixCalculation } from "./DataFixCalculation";
import DataFixSecondStep from "./DataFixSecondStep";
import { DeleteDataValues } from "../../helpers/commonTemplateApi";

const orgUnitsQuery = {
  orgUnitGroups: {
    resource: "organisationUnitGroups",
    id: "AxB3vV3yUrN",
    params: {
      fields: "organisationUnits[id,displayName]",
      paging: false,
    },
  },
};

const dataSetRegistrationQuery = {
  result: {
    resource: "completeDataSetRegistrations",
    params: {
      dataSet: "",
      period: "",
      orgUnitGroup: "",
    },
  },
};

const mutationDatasetRegJson = {
  resource: "completeDataSetRegistrations",
  type: "create",
  data: {
    completeDataSetRegistrations: [
      {
        dataSet: "",
        period: "",
        organisationUnit: "",
        completed: true,
      },
    ],
  },
};

const getAppSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.LabKey}`,
  },
};
const getLabTestQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.LabTestKey}`,
  },
};
const getLabEquipmentQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.LabEquipmentKey}`,
  },
};
const getGeneralSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.GeneralKey}`,
  },
};
const getOptionSetsQuery = {
  options: {
    resource: "optionSets",
    id: "",
    params: {
      fields: "id, displayName, options[code,displayName]",
    },
  },
};

const labTemplateQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.LabTemplateKey}`,
  },
};

const getCmsLabTemplateSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.CmsLabTemplateKey}`,
  },
};

let today = new Date();
let date =
  today.getFullYear() +
  "-" +
  String(today.getMonth() + 1).padStart(2, "0") +
  "-" +
  String(today.getDate()).padStart(2, "0");
const mutationExcelImportAppLogsJson = {
  resource: "dataStore/Excel-Import-App-Logs/" + date,
  type: "create",
  data: [],
};

class ImportLabTemplate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultMonth: new Date().getMonth(),
      defaultYear: new Date().getFullYear(),
      getAppSettings: true,
      getOrgUnits: false,
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      loading: false,
      vTemplateData: [],
      saveJsonData: false,
      resGriedData: {},
      error: undefined,
      successMsg: undefined,
      headingTitle: {},
      resultStatus: null,
      conflictKeyList: [],
      gridDataValues: [],
      fileName: null,
      statusBtnIcon: null,
      resInsertData: {},
      selectedFacility: null,
      selectedMonthYear: null,
      uploadedFile: null,
      orgUnits: [],
      setDataSetRegistration: false,
      dataSetRegistrations: [],
      getDataSetRegistrations: false,
      periods: [],
      masterTemplateError: false,
      conflictStatus: false,
      labMutationData: {
        LABMasterTemplate: "",
        LMISWorksheetName: "",
        LMISWorksheetStartRow: "",
        LABOrganisationUnitGroup: "",
        AssetWorksheetName: "",
        AssetWorksheetStartRow: "",
        LABDataset: "",
        LABLegend: "",
      },
      AMCs: [],
      MOSs: [],
      searchFacility: "",
      deleteUploadedFile: false,
      templateEmptyKeys: [],
      importTemplateLogsJson: [],
      user: this.props.user,
      getGeneralSettings: false,
      getAdjustmentOptionSets: false,
      getLossOptionSets: false,
      generalMutationData: {},
      adjustmentOptionSetsData: [],
      lossOptionSetsData: [],
      getLabTemplateData: false,
      afterDeleteUploadedFile: false,
      missingProducts: [],
      showDuplicateProducts: false,
      gridHeadingTitle: null,
      duplicateProducts: [],
      blankOrNegativeRocords: [],
      getCmsLabTemplateSettings: false,
      vTemplateCmsVenData: [],
      vTemplateCmsVenDataList: [],
      labTestDataStore: [],
      labEquipmentDataStore: [],
      vJsonData: {},
      vEnquiryJsonData: {},
      saveEnquiryJsonData: false,
      equipmentSerialUid: Constants.EQUIPMENT_SERIAL_UID,
      dataFixSecondStep: false,
      bShowDataFixCalculation: false,
      dataFixBtnDisabled: false,
      dataFixBtnBack: false,
    };
    this.readExcel = this.readExcel.bind(this);
    this.changePanel = this.changePanel.bind(this);
    this.handleFirstStep = this.handleFirstStep.bind(this);
    this.deleteUploadedFile = this.deleteUploadedFile.bind(this);
    this.handleSecondStep = this.handleSecondStep.bind(this);
    this.generateJson = this.generateJson.bind(this);
    this.closeAlertBar = this.closeAlertBar.bind(this);
    this.closeAlertBarMsg = this.closeAlertBarMsg.bind(this);
    this.resposeSaveJson = this.resposeSaveJson.bind(this);
    this.readDataFromExcel = this.readDataFromExcel.bind(this);
    this.handleChangeFacility = this.handleChangeFacility.bind(this);
    this.redirectToFirstStep = this.redirectToFirstStep.bind(this);
    this.getOrgUnitGroups = this.getOrgUnitGroups.bind(this);
    this.getCompleteDataSet = this.getCompleteDataSet.bind(this);
    this.saveDataSetRegistration = this.saveDataSetRegistration.bind(this);
    this.generatePeriods = this.generatePeriods.bind(this);
    this.setPeriods = this.setPeriods.bind(this);
    this.deleteJsonData = this.deleteJsonData.bind(this);
    this.calculateImportStatus = this.calculateImportStatus.bind(this);
    this.facilityGridData = this.facilityGridData.bind(this);
    this.getAppSettingsResponse = this.getAppSettingsResponse.bind(this);
    this.getLabTemplateSettings = this.getLabTemplateSettings.bind(this);
    this.uploadAmcMosResponse = this.uploadAmcMosResponse.bind(this);
    this.handleSearchFacility = this.handleSearchFacility.bind(this);
    this.getExcelImportAppLogsJson = this.getExcelImportAppLogsJson.bind(this);
    this.handleError = this.handleError.bind(this);
    this.getGeneralSettingsResponse =
      this.getGeneralSettingsResponse.bind(this);
    this.getAdjustmentOptionSetsResponse =
      this.getAdjustmentOptionSetsResponse.bind(this);
    this.getLossOptionSetsResponse = this.getLossOptionSetsResponse.bind(this);
    this.getCmsLabTemplateSettingsResponse =
      this.getCmsLabTemplateSettingsResponse.bind(this);
    this.getLabTestResponse = this.getLabTestResponse.bind(this);
    this.getLabEquipmentResponse = this.getLabEquipmentResponse.bind(this);
    this.handleDataFixFirstStep = this.handleDataFixFirstStep.bind(this);
    this.handleDataFixSecondStep = this.handleDataFixSecondStep.bind(this);
    this.findRowIndexByColumnKeyAndValue =
      this.findRowIndexByColumnKeyAndValue.bind(this);
    this.isValidDate = this.isValidDate.bind(this);
  }

  componentWillMount() {
    this.generatePeriods(this.state.defaultYear, this.state.defaultMonth);
  }
  handleSearchFacility(e) {
    this.setState({ searchFacility: e.value.toLowerCase() });
  }

  handleError(error) {
    this.setState({ error });
  }

  getCmsLabTemplateSettingsResponse(data) {
    if (data && data.dataStore) {
      let vTemplateCmsVenData = [];
      if (data.dataStore.length > 0) {
        let itemKeys = Object.keys(data.dataStore[0]);
        data.dataStore.filter((item) => {
          if (
            (item["Code"] && item["Code"] != "Code") ||
            (item["Code "] && item["Code "] != "Code ")
          ) {
            let flag = false;
            let newItem = {};
            itemKeys.map((itemKey) => {
              if (itemKey.includes("Code") || itemKey.includes("Code ")) {
                newItem["Code"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Unit Price")) {
                newItem["UnitPrice"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Current stock")) {
                newItem["CurrentStock"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Current Price")) {
                newItem["CurrentPrice"] = item[itemKey];
                flag = true;
              }
            });
            if (flag) {
              vTemplateCmsVenData.push(newItem);
            }
          }
        });
      }
      this.setState({
        vTemplateCmsVenData,
        vTemplateCmsVenDataList: data.dataStore,
        getLossOptionSets: true,
        getCmsLabTemplateSettings: false,
      });
    }
  }

  getExcelImportAppLogsJson(called, loading, error, data) {
    if (called && loading && error) {
      this.setState({ fourthStep: false, loading: false, error });
    }
  }

  deleteJsonData() {
    let dataValues = [];

    const period = this.state.selectedMonthYear;
    const orgUnit = this.state.selectedFacility;

    let csvLine = Constants.CSV_HEADER;

    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[1] &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[1].__EMPTY_23 == "Lab Receive Date" &&
      this.state.vTemplateData[2]["__EMPTY_23"]
    ) {
      let receiveDateKey = this.state.vTemplateData[2]["__EMPTY_23"];
      let reportTimelyStatus = this.state.vTemplateData[2].__EMPTY_21;
      let reportLateStatus = this.state.vTemplateData[2].__EMPTY_22;

      if (receiveDateKey && receiveDateKey.includes("-")) {
        // dataValues.push({
        //   dataElement: receiveDateKey.split("-")[0],
        //   categoryOptionCombo: receiveDateKey.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${receiveDateKey.split("-")[0]},${period},${orgUnit},${
          receiveDateKey.split("-")[1]
        },,,,,,,true\n`;
      }
      if (reportTimelyStatus && reportTimelyStatus.includes("-")) {
        // dataValues.push({
        //   dataElement: reportTimelyStatus.split("-")[0],
        //   categoryOptionCombo: reportTimelyStatus.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${reportTimelyStatus.split("-")[0]},${period},${orgUnit},${
          reportTimelyStatus.split("-")[1]
        },,,,,,,true\n`;
      }
      if (reportLateStatus && reportLateStatus.includes("-")) {
        // dataValues.push({
        //   dataElement: reportLateStatus.split("-")[0],
        //   categoryOptionCombo: reportLateStatus.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${reportLateStatus.split("-")[0]},${period},${orgUnit},${
          reportLateStatus.split("-")[1]
        },,,,,,,true\n`;
      }
    }

    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[2].__EMPTY_25 &&
      this.state.vTemplateData[2].__EMPTY_24 &&
      this.state.vTemplateData[2].__EMPTY_26 &&
      this.state.vTemplateData[2].__EMPTY_27
    ) {
      let totalLossKey = this.state.vTemplateData[2].__EMPTY_25;
      let totalBalanceKey = this.state.vTemplateData[2].__EMPTY_24;
      let countAllProductKey = this.state.vTemplateData[2].__EMPTY_26;
      let countNonZeroKey = this.state.vTemplateData[2].__EMPTY_27;

      if (
        totalLossKey &&
        totalBalanceKey &&
        countAllProductKey &&
        countNonZeroKey
      ) {
        // dataValues.push({
        //   dataElement: totalLossKey.split("-")[0],
        //   categoryOptionCombo: totalLossKey.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${totalLossKey.split("-")[0]},${period},${orgUnit},${
          totalLossKey.split("-")[1]
        },,,,,,,true\n`;
        // dataValues.push({
        //   dataElement: totalBalanceKey.split("-")[0],
        //   categoryOptionCombo: totalBalanceKey.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${totalBalanceKey.split("-")[0]},${period},${orgUnit},${
          totalBalanceKey.split("-")[1]
        },,,,,,,true\n`;
        // dataValues.push({
        //   dataElement: countAllProductKey.split("-")[0],
        //   categoryOptionCombo: countAllProductKey.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${countAllProductKey.split("-")[0]},${period},${orgUnit},${
          countAllProductKey.split("-")[1]
        },,,,,,,true\n`;
        // dataValues.push({
        //   dataElement: countNonZeroKey.split("-")[0],
        //   categoryOptionCombo: countNonZeroKey.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${countNonZeroKey.split("-")[0]},${period},${orgUnit},${
          countNonZeroKey.split("-")[1]
        },,,,,,,true\n`;
      }
    }

    let vTemplateData = this.state.vTemplateData.filter((item) => {
      if (
        ![
          "Laboratory Monthly Logistics Reporting Form",
          "Name of Facility:",
          "Product Code",
        ].includes(item["__EMPTY"]) &&
        item["__EMPTY"]
      ) {
        return item;
      }
    });
    let columnList = [];
    if (vTemplateData && vTemplateData.length > 0) {
      columnList = Object.keys(vTemplateData[0]);
    }

    // console.log('vTemplateData: ', vTemplateData);

    vTemplateData.map((logTemplate) => {
      columnList.map((col) => {
        if (
          logTemplate[col] &&
          logTemplate[col].toString().split("-").length > 1
        ) {
          const de = logTemplate[col].split("-")[0];
          const cc = logTemplate[col].split("-")[1];

          if (col == "__EMPTY_14" || col == "__EMPTY_16") {
            // dataValues.push({
            //   dataElement: logTemplate[col].split("-")[0],
            //   categoryOptionCombo: logTemplate[col].split("-")[1],
            //   value: 0,
            // });
            csvLine += `${de},${period},${orgUnit},${cc},,0,,,,,\n`;
          } else {
            if (
              !(
                col === "__EMPTY_23" ||
                col === "__EMPTY_24" ||
                col === "__EMPTY_32" ||
                col === "__EMPTY_33"
              )
            ) {
              // dataValues.push({
              //   dataElement: logTemplate[col].split("-")[0],
              //   categoryOptionCombo: logTemplate[col].split("-")[1],
              //   deleted: true,
              // });
              csvLine += `${de},${period},${orgUnit},${cc},,,,,,,true\n`;
            }
          }
        }
      });
    });

    let equipmentDataValues = [];
    let equipmentSerialUid = this.state.equipmentSerialUid;
    let labEquipmentDataStore = this.state.labEquipmentDataStore;
    let labTestDataStore = this.state.labTestDataStore;
    labEquipmentDataStore.map((equipment) => {
      equipmentSerialUid.map((uid) => {
        equipmentDataValues.push({
          dataElement: equipment.SerialNo,
          categoryOptionCombo: uid,
          deleted: true,
        });
        // equipmentDataValues.push({
        //   dataElement: equipment.NextService,
        //   categoryOptionCombo: uid,
        //   deleted: true,
        csvLine += `${equipment.NextService},${period},${orgUnit},${uid},,,,,,,true\n`;
        // });
        // equipmentDataValues.push({
        //   dataElement: equipment.LastServiceDate,
        //   categoryOptionCombo: uid,
        //   deleted: true,
        // });
        csvLine += `${equipment.LastServiceDate},${period},${orgUnit},${uid},,,,,,,true\n`;
        // equipmentDataValues.push({
        //   dataElement: equipment.EquipisFunctional,
        //   categoryOptionCombo: uid,
        //   deleted: true,
        // });
        csvLine += `${equipment.EquipisFunctional},${period},${orgUnit},${uid},,,,,,,true\n`;
        // equipmentDataValues.push({
        //   dataElement: equipment.EquipisNoneFunctional,
        //   categoryOptionCombo: uid,
        //   deleted: true,
        // });
        csvLine += `${equipment.EquipisNoneFunctional},${period},${orgUnit},${uid},,,,,,,true\n`;
        // equipmentDataValues.push({
        //   dataElement: equipment.NoOfDaysEquipNotFunctioning,
        //   categoryOptionCombo: uid,
        //   deleted: true,
        // });
        csvLine += `${equipment.NoOfDaysEquipNotFunctioning},${period},${orgUnit},${uid},,,,,,,true\n`;
      });

      labTestDataStore.map((labTest) => {
        // equipmentDataValues.push({
        //   dataElement: equipment.UID,
        //   categoryOptionCombo: labTest.Controls,
        //   deleted: true,
        // });
        csvLine += `${equipment.UID},${period},${orgUnit},${labTest.Controls},,,,,,,true\n`;
        // equipmentDataValues.push({
        //   dataElement: equipment.UID,
        //   categoryOptionCombo: labTest.Failures,
        //   deleted: true,
        // });
        csvLine += `${equipment.UID},${period},${orgUnit},${labTest.Failures},,,,,,,true\n`;
        // equipmentDataValues.push({
        //   dataElement: equipment.UID,
        //   categoryOptionCombo: labTest.ValidTests,
        //   deleted: true,
        // });
        csvLine += `${equipment.UID},${period},${orgUnit},${labTest.ValidTests},,,,,,,true\n`;
      });
    });

    // let mutation = {
    //   resource: "dataValueSets",
    //   type: "create",
    //   data: {
    //     period: this.state.selectedMonthYear,
    //     orgUnit: this.state.selectedFacility,
    //     dataValues: dataValues.concat(equipmentDataValues),
    //   },
    // };

    // return mutation;
    return csvLine;
  }

  facilityGridData() {
    let searchFacility = this.state.searchFacility;
    let orgUnits = this.state.orgUnits.filter((orgUnit) => {
      if (
        orgUnit.id != "default" &&
        orgUnit.displayName.toLowerCase().includes(searchFacility)
      ) {
        return orgUnit;
      }
    });
    let dataSetRegistrations = this.state.dataSetRegistrations;
    let GridData = orgUnits.map((orgUnit) => {
      let newOrgUnit = {
        period: "",
        dataSet: "",
        organisationUnit: "",
        attributeOptionCombo: "",
        date: "",
        storedBy: "",
        completed: false,
        id: orgUnit.id,
        displayName: orgUnit.displayName,
      };

      dataSetRegistrations.map((dataSet) => {
        if (orgUnit.id == dataSet.organisationUnit) {
          newOrgUnit["period"] = dataSet.period;
          newOrgUnit["dataSet"] = dataSet.dataSet;
          newOrgUnit["organisationUnit"] = dataSet.organisationUnit;
          newOrgUnit["attributeOptionCombo"] = dataSet.attributeOptionCombo;
          newOrgUnit["date"] = dataSet.date;
          newOrgUnit["storedBy"] = dataSet.storedBy;
          newOrgUnit["completed"] = dataSet.completed;
        }
      });
      return newOrgUnit;
    });
    return GridData;
  }

  calculateImportStatus() {
    if (this.state.orgUnits.length > 1) {
      let facilityCount = this.state.orgUnits.filter(
        (orgUnit) => orgUnit.id != "default"
      ).length;
      let importStatusCount = 0;
      if (
        this.state.dataSetRegistrations &&
        this.state.dataSetRegistrations.length
      ) {
        importStatusCount = this.state.dataSetRegistrations.filter(
          (dataSet) => dataSet.completed === true
        ).length;
      }
      let percentage = 0;
      try {
        percentage = ((importStatusCount / facilityCount) * 100).toFixed(1);
      } catch {
        percentage = 0;
      }
      return (
        percentage +
        "% (" +
        importStatusCount +
        "/" +
        facilityCount +
        " Facilities)"
      );
    }
  }

  getOrgUnitGroups(res) {
    res.unshift({ id: "default", displayName: "Select LAB Organisation Unit" });
    this.setState({
      getOrgUnits: false,
      orgUnits: res,
    });
  }

  redirectToFirstStep() {
    this.setState({
      firstStep: true,
      secondStep: false,
      dataFixSecondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      resultStatus: null,
      fileName: null,
      selectedFacility: this.state.labMutationData.LABOrganisationUnitGroup,
      uploadedFile: null,
      getOrgUnits: true,
      getDataSetRegistrations: true,
      dataSetRegistrations: [],
      AMCs: [],
      MOSs: [],
      showDuplicateProducts: false,
      gridHeadingTitle: null,
      loading: false,
      duplicateProducts: [],
      blankOrNegativeRocords: [],
    });
  }

  handleFirstStep(selectedOrgUnit) {
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      secondStep: true,
      selectedFacility: selectedOrgUnit.id,
    });
  }
  handleDataFixFirstStep(selectedOrgUnit) {
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      dataFixSecondStep: true,
      selectedFacility: selectedOrgUnit.id,
    });
  }
  deleteUploadedFile(selectedOrgUnit) {
    this.setState({
      loading: true,
      getDataSetRegistrations: true,
      deleteUploadedFile: true,
      selectedFacility: selectedOrgUnit.id,
    });
  }

  handleSecondStep() {
    if (this.state.selectedFacility == "default") {
      let error = "Please select a facility";
      this.setState({ error });
      return true;
    }
    if (this.state.uploadedFile == null) {
      let error = "Please upload the Excel file you want to import";
      this.setState({ error });
      return true;
    }
    this.readDataFromExcel();
    this.setState({
      loading: true,
    });
  }

  handleDataFixSecondStep() {
    console.log("handleDataFixSecondStep");
    if (this.state.selectedFacility == "default") {
      let error = "Please select a facility";
      this.setState({ error });
      return true;
    }
    this.setState({
      loading: true,
      bShowDataFixCalculation: true,
      dataFixBtnDisabled: true,
      dataFixBtnBack: true,
    });
  }

  handleChangeFacility(e, name) {
    if (name == "selectFacility") {
      this.setState({ selectedFacility: e.selected, error: null });
    } else {
      this.setState({
        selectedMonthYear: e.selected,
        error: null,
        getDataSetRegistrations: true,
        dataSetRegistrations: [],
      });
    }
  }
  resposeSaveJson(called, loading, error) {
    if (loading && called && error) {
      this.setState({ error });
    }
  }

  saveDataSetRegistration(response) {
    this.setState({
      getDataSetRegistrations: true,
      setDataSetRegistration: false,
      deleteUploadedFile: false,
      afterDeleteUploadedFile: false,
      loading: false,
    });
  }

  getCompleteDataSet(response) {
    this.setState({ getDataSetRegistrations: false });
    if (
      response &&
      response.result &&
      response.result.completeDataSetRegistrations
    ) {
      this.setState({
        dataSetRegistrations: response.result.completeDataSetRegistrations,
      });
    }
  }

  closeAlertBar() {
    this.setState({ error: null });
  }

  closeAlertBarMsg() {
    this.setState({ successMsg: null });
  }

  validate() {
    let flag = true;
    let error = null;

    if (this.state.uploadedFile == null) {
      flag = false;
      error = "Please upload the Excel file you want to import";
    }

    if (this.state.selectedFacility == "default") {
      flag = false;
      error = "Please select a facility";
    }
    if (flag == false) {
      this.setState({ error });
    }
    return flag;
  }

  validateFirstStep() {
    let flag = true;
    if (this.state.masterTemplateError) {
      this.setState({
        error:
          "Template file " +
          this.state.labMutationData.LABMasterTemplate +
          " does not exist",
      });
      flag = false;
    }
    return flag;
  }

  changePanel() {
    if (this.validate() == false) {
      return true;
    }
    if (this.state.secondStep) {
      this.setState({
        secondStep: !this.state.secondStep,
        items: [],
        resultStatus: null,
        fileName: null,
        selectedFacility: this.state.labMutationData.LABOrganisationUnitGroup,
        selectedMonthYear: null,
        uploadedFile: null,
      });
    } else {
      this.setState({
        loading: true,
      });
      this.readDataFromExcel();
    }
  }

  readExcel(file) {
    this.setState({
      uploadedFile: file,
      fileName: file.name,
      error: null,
    });
  }

  // findRowIndexByColumnKeyAndValue(data, columnKey, value) {
  //   for (let i = 0; i < data.length; i++) {
  //     if (data[i][columnKey] && data[i][columnKey].trim() === value.trim()) {
  //       return i; // Return the index if a match is found
  //     }
  //   }
  //   return -1; // Return -1 if no match is found
  // }

  findRowIndexByColumnKeyAndValue(data, columnKey, value) {
    for (let i = 0; i < data.length; i++) {
      const cellValue = data[i][columnKey];

      // Check if cellValue exists and if it's a string, trim and compare
      if (typeof cellValue === "string" && cellValue.trim() === value.trim()) {
        return i;
      }

      // If cellValue is not a string (e.g., number, null, etc.), convert to string and compare
      if (cellValue != null && cellValue.toString().trim() === value.trim()) {
        return i;
      }
    }
    return -1; // Return -1 if no match is found
  }

  isValidDate(dateValue) {
    // Check if the value is a valid date (number)
    return !isNaN(Date.parse(dateValue));
  }

  readDataFromExcel() {
    // Array of month names to map the month number to the corresponding name
    // prettier-ignore
    const months = [
      "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
      "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER",
    ];
    // Create a new Promise to handle the asynchronous file reading process
    const promise = new Promise((resolve, reject) => {
      let file = this.state.uploadedFile; // Get the uploaded file from component state
      let selectedMonthYear = this.state.selectedMonthYear; // Get the selected month and year from state

      const fileReader = new FileReader(); // Create a FileReader to read the uploaded file

      fileReader.readAsArrayBuffer(file); // Read the file as an array buffer

      // Extract the year from selectedMonthYear
      let year = selectedMonthYear.substring(0, 4);

      // Get the format for the worksheet name from state (Lab Mutation Data)
      let workSheetFormat = this.state.labMutationData.LMISWorksheetName;

      // Count the occurrences of 'Y' in the worksheet format
      var yCount = 0;
      for (var position = 0; position < workSheetFormat.length; position++) {
        if (workSheetFormat.charAt(position).toUpperCase() == "Y") {
          yCount += 1;
        }
      }

      // If there are not exactly 4 'Y's, shorten the year to the last 2 digits
      if (yCount != 4) {
        year = year.substring(2);
      }

      // Count the occurrences of 'M' in the worksheet format
      var mCount = 0;
      for (var position = 0; position < workSheetFormat.length; position++) {
        if (workSheetFormat.charAt(position).toUpperCase() == "M") {
          mCount += 1;
        }
      }

      // Get the month name in the appropriate length based on 'M' count
      let monthName = months[
        parseInt(selectedMonthYear.substring(4, 6)) - 1
      ].substring(0, mCount);

      // Construct the sheet name by replacing placeholders with actual month and year
      let sheetName = workSheetFormat
        .replace("{MMM}", monthName)
        .replace("{MM}", monthName)
        .replace("{YYYY}", year)
        .replace("{YY}", year)
        .toUpperCase();

      let _this = this;

      // Define what happens when file reading is completed
      fileReader.onload = (e) => {
        const bufferArray = e.target.result; // Get the file contents as a buffer array

        let wb = null; // Initialize workbook variable
        let sheetNames = null; // Initialize sheet names array

        // Try reading the workbook using the buffer
        try {
          wb = XLSX.read(bufferArray, { type: "buffer" });
        } catch (error) {
          // If file is password-protected, set an error state
          this.setState({
            error: "Password protected files are not allowed",
            loading: false,
          });
        }

        // If workbook is read successfully, get the sheet names and convert to uppercase
        if (wb) {
          sheetNames = wb.SheetNames.map((sheet) => sheet.toUpperCase());
        }

        let wsname = null; // Worksheet name initialization

        // Check if the expected sheet name exists in the file
        if (sheetName && sheetNames && sheetNames.indexOf(sheetName) != -1) {
          wsname = wb.SheetNames[sheetNames.indexOf(sheetName)]; // Get the worksheet name

          const ws = wb.Sheets[wsname]; // Get the worksheet

          // Define custom headers for parsing the worksheet data
          // prettier-ignore
          const customHeaders = [
            "__EMPTY", "__EMPTY_1", "__EMPTY_2", "__EMPTY_3", "__EMPTY_4", "__EMPTY_5", 
            "__EMPTY_6", "__EMPTY_7", "__EMPTY_8", "__EMPTY_9", "__EMPTY_10", "__EMPTY_11",
            "__EMPTY_12", "__EMPTY_13", "__EMPTY_14", "__EMPTY_15", "__EMPTY_16", "__EMPTY_17",
            "__EMPTY_18", "__EMPTY_19", "__EMPTY_20", "__EMPTY_21", "__EMPTY_22", "__EMPTY_23",
            "__EMPTY_24", "__EMPTY_25", "__EMPTY_26", "__EMPTY_27", "__EMPTY_28", "__EMPTY_29", 
            "__EMPTY_30", "__EMPTY_31", "__EMPTY_32", "__EMPTY_33"
          ];

          // Convert the worksheet data into JSON format
          const data = XLSX.utils.sheet_to_json(ws, {
            range: 1, // Start reading from the second row
            header: customHeaders, // Use custom headers
          });

          resolve(data); // Resolve the promise with the parsed data
        } else {
          // If the expected sheet name is not found, set an error state
          this.setState({
            error:
              "File does not contain " +
              sheetName +
              " worksheet. Unable to proceed",
            loading: false,
          });
        }
      };

      // Handle file read errors by rejecting the promise
      fileReader.onerror = (error) => {
        reject(error);
      };
    });

    // Process the data after promise resolves
    promise.then((items) => {
      console.log("items raw json: ", items);
      let equipmentData = []; // Array to hold equipment-related data

      // Initialize a headingTitle object for facility name, month, and year
      let headingTitle = {
        facilityName: "Facility Name",
        monthName: "Month",
        year: "Year",
      };

      // Searching by __EMPTY column and value "Name of Facility:"
      let nameOfFacilityIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY",
        "Name of Facility:"
      );
      console.log("Name of Facility Index:", nameOfFacilityIndex);


      // Show message if "Name of Facility:" is not found
      if (nameOfFacilityIndex === -1) {
        this.setState({
          error: '"Name of Facility:" text not found or not in exact position"',
          loading: false,
        });
        return;
      }


      // Check if there is data at row 3, columns 3 and 8 (these columns contain facility name and date info)
      if (
        items &&
        items.length &&
        items[nameOfFacilityIndex].__EMPTY_3 &&
        items[nameOfFacilityIndex].__EMPTY_8
      ) {
        let baseDate = new Date("1900-01-01"); // Initialize the base date for Excel's date format

        // Calculate the date based on Excel's date system (add days from base date)
        baseDate.setDate(
          baseDate.getDate() +
            (parseInt(items[nameOfFacilityIndex].__EMPTY_8) - 2)
        );

        // Update the headingTitle with the parsed facility name, month, and year
        headingTitle = {
          facilityName: items[2].__EMPTY_3,
          monthName: months[baseDate.getMonth()],
          year: baseDate.getFullYear(),
        };
      }

      // Searching by __EMPTY_6 column and value "Reporting Period:"
      let reportingPeriodIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY_6",
        "Reporting Period: "
      );
      console.log("Reporting Period Index:", reportingPeriodIndex);

      // Show message if "Reporting Period: " not found
      if (reportingPeriodIndex === -1) {
        this.setState({
          error:
            '"Reporting Period: " text not found or not in exact position',
          loading: false,
        });
        return;
      }

      const empty3Value = items[nameOfFacilityIndex]["__EMPTY_3"];
      const empty8Value = items[reportingPeriodIndex]["__EMPTY_8"];

      // Check for __EMPTY_3 value
      if (!empty3Value) {
        this.setState({
          error: "Facility name not found or not in exact position",
          loading: false,
        });
        return;
      }

      // Check for __EMPTY_8 value and validate date
      if (!empty8Value || !this.isValidDate(empty8Value)) {
        this.setState({
          error: "Reporting Period not found or not in exact position",
          loading: false,
        });
        return;
      }

       // Searching by __EMPTY column and value "Equipment (Select which equipment is at your facility)"
       let equipmentSelectIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY",
        "Equipment (Select which equipment is at your facility)"
      );
      console.log("Equipment (Select which equipment is at your facility)", equipmentSelectIndex);

      // Show message if "Equipment (Select which equipment is at your facility)" not found
      if (equipmentSelectIndex === -1) {
        this.setState({
          error:
            '"Equipment (Select which equipment is at your facility)" text not found or not in exact position',
          loading: false,
        });
        return;
      }

       // Searching by __EMPTY column and value "Section"
       let sectionIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY",
        "Section"
      );
      console.log("Section", sectionIndex);

      // Show message if "Section" not found
      if (sectionIndex === -1) {
        this.setState({
          error:
            '"Section" text not found or not in exact position',
          loading: false,
        });
        return;
      }

       // Searching by __EMPTY_2 column and value "Equipment"
       let equipmentIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY_2",
        "Equipment"
      );
      console.log("Equipment Index:", equipmentIndex);

      // Show message if "Equipment" not found
      if (equipmentIndex === -1) {
        this.setState({
          error:
            '"Equipment" text not found or not in exact position',
          loading: false,
        });
        return;
      }

      // Searching by __EMPTY_6 column and value "Reporting Period:"
      let dateIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY_3",
        "Date:"
      );
      console.log("Date Index in bottom:", dateIndex);

      // Show message if "RDate:" not found
      if (dateIndex === -1) {
        this.setState({
          error: '"Date: " text not found or not in exact position',
          loading: false,
        });
        return;
      }

      const empty5Value = items[dateIndex]["__EMPTY_5"];
      // Check for __EMPTY_3 value and validate date
      if (!empty5Value || !this.isValidDate(empty5Value)) {
        this.setState({
          error: "Date not found or not in exact position",
          loading: false,
        });
        return;
      }

      // Searching by __EMPTY column and value "Product Code"
      let productCodeIndex = this.findRowIndexByColumnKeyAndValue(
        items,
        "__EMPTY",
        "Product Code"
      );
      console.log("Product Code Index:", productCodeIndex);

      // Show message if "Name of Facility:" is not found
      if (productCodeIndex === -1) {
        this.setState({
          error: '"Product Code" text not found or not in exact position',
          loading: false,
        });
        return;
      }
      

      // Define the starting row number for the relevant data (default is 6)
      let start_row_number = productCodeIndex + 3;

      // if (this.state.labMutationData.LMISWorksheetStartRow) {
      //   // Parse the starting row number from the worksheet start row setting
      //   start_row_number = parseInt(
      //     this.state.labMutationData.LMISWorksheetStartRow.replace(/\D/g, "")
      //   );
      // }

      let flag = true; // Flag to track when to start collecting equipment data

      let receiveDateValue = ""; // Variable to store the received date

  
      console.log('start_row_number: ', start_row_number); 

      // Remove rows before Item Code Start
      items = items.slice(start_row_number);

      // console.log("items 999999: ", items);

      
      // Filter the items to collect only the relevant data
      items = items.filter((item) => {
        // If "Equipment" is found in the "__EMPTY" column, stop processing rows for this section
        if (item["__EMPTY"] && item["__EMPTY"].includes("Equipment")) {
          flag = false;
        }
        // If the row contains a valid data entry (excluding "Code" and flagged rows)
        if (item["__EMPTY"] && item["__EMPTY"] != "Code" && flag) {
          // console.log("item 2222222: ", item);
          return item;
        } else {
          // Check for date rows and calculate the received date from Excel format
          if (
            item["__EMPTY"] &&
            item["__EMPTY_3"] &&
            item["__EMPTY_5"] &&
            item["__EMPTY"].includes("Date") &&
            item["__EMPTY_3"].includes("Date")
          ) {
            let baseDate = new Date("1900-01-01");
            baseDate.setDate(
              baseDate.getDate() + (parseInt(item["__EMPTY_5"]) - 2)
            );
            receiveDateValue =
              baseDate.getFullYear() +
              "-" +
              String(baseDate.getMonth() + 1).padStart(2, "0") +
              "-" +
              String(baseDate.getDate()).padStart(2, "0");
          } else {
            // If the row contains equipment data, add it to the equipmentData array
            if (
              item["__EMPTY"] &&
              item["__EMPTY_2"] &&
              item["__EMPTY_3"] &&
              item["__EMPTY_4"] &&
              flag == false
            ) {
              equipmentData.push(item);
            }
          }
        }
      });



      // If no data is available after filtering, set an error state
      if (items.length == 0) {
        this.setState({ error: "Data not available in file", loading: false });
        return true;
      }

      // Set the state with the heading title and items
      this.setState({
        headingTitle,
        items,
      });

      // Generate JSON data from the filtered items and equipment data
      this.generateJson(items, equipmentData, receiveDateValue);
    });
  }

  generateJson(items, equipmentData, receiveDateValue) {
    // let vTemplateData = this.state.vTemplateData.slice(start_row_number, this.state.vTemplateData.length);
    if (!receiveDateValue) {
      this.setState({
        loading: false,
        error: "'Receive Date is missing in uploaded file",
      });
      return true;
    }
    let receiveDate = {
      dataElement: "",
      categoryOptionCombo: "",
      value: receiveDateValue,
    };

    let timelyStatus = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    let lateStatus = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };
    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[1] &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[1].__EMPTY_23 == "Lab Receive Date" &&
      this.state.vTemplateData[2]["__EMPTY_23"]
    ) {
      let receiveDateKey = this.state.vTemplateData[2]["__EMPTY_23"];
      let reportTimelyStatus = this.state.vTemplateData[2].__EMPTY_21;
      let reportLateStatus = this.state.vTemplateData[2].__EMPTY_22;

      if (receiveDateKey && receiveDateKey.includes("-")) {
        receiveDate["dataElement"] = receiveDateKey.split("-")[0];
        receiveDate["categoryOptionCombo"] = receiveDateKey.split("-")[1];

        let year = receiveDateValue.split("-")[0];
        let month = receiveDateValue.split("-")[1];
        let day = receiveDateValue.split("-")[2];

        let receiveDt = new Date(year, month, day);

        let nextMonthYear = this.getNextPeriod(this.state.selectedMonthYear);

        let nxtYear = parseInt(nextMonthYear.substring(0, 4));
        let nxtMonth = parseInt(nextMonthYear.substring(4));

        let lastSubmissionDt = new Date(nxtYear, nxtMonth, 10);

        timelyStatus["dataElement"] = reportTimelyStatus.split("-")[0];
        timelyStatus["categoryOptionCombo"] = reportTimelyStatus.split("-")[1];

        lateStatus["dataElement"] = reportLateStatus.split("-")[0];
        lateStatus["categoryOptionCombo"] = reportLateStatus.split("-")[1];

        const one = 1;
        const zero = 0;

        if (receiveDt <= lastSubmissionDt) {
          timelyStatus["value"] = one.toFixed(1);
          lateStatus["value"] = zero.toFixed(1);
        } else {
          timelyStatus["value"] = zero.toFixed(1);
          lateStatus["value"] = one.toFixed(1);
        }
      }
    }

    let totalLossKey = null;
    let totalBalanceKey = null;
    let countAllProductKey = null;
    let countNonZeroKey = null;
    let totalLossValue = [];
    let totalBalanceValue = [];
    let countAllProductValue = null;
    let countNonZeroValue = null;

    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[2].__EMPTY_25 &&
      this.state.vTemplateData[2].__EMPTY_24 &&
      this.state.vTemplateData[2].__EMPTY_26 &&
      this.state.vTemplateData[2].__EMPTY_27
    ) {
      totalLossKey = this.state.vTemplateData[2].__EMPTY_25;
      totalBalanceKey = this.state.vTemplateData[2].__EMPTY_24;
      countAllProductKey = this.state.vTemplateData[2].__EMPTY_26;
      countNonZeroKey = this.state.vTemplateData[2].__EMPTY_27;

      items.map((item) => {
        let currentPrice = this.state.vTemplateCmsVenData.find(
          (vtemplateItem) => vtemplateItem["Code"] == item["__EMPTY"]
        );
        if (
          currentPrice &&
          (currentPrice["CurrentPrice"] || currentPrice["CurrentPrice"] == 0)
        ) {
          totalLossValue.push(
            parseFloat(item["__EMPTY_7"]) *
              parseFloat(currentPrice["CurrentPrice"])
          );
          totalBalanceValue.push(
            parseFloat(item["__EMPTY_9"]) *
              parseFloat(currentPrice["CurrentPrice"])
          );
        }
      });

      totalLossValue = Math.round(totalLossValue.reduce((a, b) => a + b, 0));

      totalBalanceValue = Math.round(
        totalBalanceValue.reduce((a, b) => a + b, 0)
      );

      countAllProductValue = items.length;

      countNonZeroValue = items.filter(
        (logItem) => logItem["__EMPTY_9"] != 0
      ).length;
    }

    let vTemplateData = this.state.vTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );

    let columnList = [
      "__EMPTY_4",
      "__EMPTY_5",
      "__EMPTY_6",
      "__EMPTY_7",
      "__EMPTY_8",
      "__EMPTY_9",
      "__EMPTY_10",
      "__EMPTY_11",
      "__EMPTY_12",
      "__EMPTY_13",
      "__EMPTY_14",
      "__EMPTY_15",
      "__EMPTY_16",
    ];

    // "__EMPTY": "Product Code",
    // "__EMPTY_2": "Item Description",
    // "__EMPTY_3": "Unit of Issue",
    // "__EMPTY_4": "Opening Stock",
    // "__EMPTY_5": "Quantity Received",
    // "__EMPTY_6": "Quantity Used",
    // "__EMPTY_7": "Losses ",
    // "__EMPTY_8": "Adjustments",
    // "__EMPTY_9": "Closing Stock"
    // "__EMPTY_10": "Quantity Expiring in 3 Months",
    // "__EMPTY_11": "No. of Days Stocked Out",
    // "__EMPTY_12": "Requisition Quantity ",
    // "__EMPTY_13": "Remarks",
    // "__EMPTY_14": "Loss Type",
    // "__EMPTY_15": "AMC",
    // "__EMPTY_16": "Adjustment Type",
    // "__EMPTY_21": "Price",
    // "__EMPTY_22": "MOS",
    // "__EMPTY_23": "Quantity Issued PreMonth",
    // "__EMPTY_24": "Quantity Issued PrePreMonth",
    // "__EMPTY_25": "Stockout",
    // "__EMPTY_26": "Emergency",
    // "__EMPTY_27": "Understock",
    // "__EMPTY_28": "Adequate",
    // "__EMPTY_29": "Overstock",
    // "__EMPTY_30": "Closing Zero Stock",
    // "__EMPTY_31": "Non-Use",
    // "__EMPTY_32": "No. of Days Stocked Out PreMonth",
    // "__EMPTY_33": "No. of Days Stocked Out PrePreMonth",

    let dataValues = [];
    let gridDataValues = [];
    let templateEmptyKeys = [];
    let _this = this;

    if (
      totalLossKey &&
      totalBalanceKey &&
      countAllProductKey &&
      countNonZeroKey
    ) {
      dataValues.push({
        dataElement: totalLossKey.split("-")[0],
        categoryOptionCombo: totalLossKey.split("-")[1],
        value: totalLossValue,
      });
      dataValues.push({
        dataElement: totalBalanceKey.split("-")[0],
        categoryOptionCombo: totalBalanceKey.split("-")[1],
        value: totalBalanceValue,
      });
      dataValues.push({
        dataElement: countAllProductKey.split("-")[0],
        categoryOptionCombo: countAllProductKey.split("-")[1],
        value: countAllProductValue,
      });
      dataValues.push({
        dataElement: countNonZeroKey.split("-")[0],
        categoryOptionCombo: countNonZeroKey.split("-")[1],
        value: countNonZeroValue,
      });
    }
    items.map((item) => {
      let flag = true;
      vTemplateData.map((vTemplate) => {
        if (vTemplate["__EMPTY"] == item["__EMPTY"]) {
          flag = false;
          let newItem = {};
          newItem["__EMPTY"] = item["__EMPTY"];
          // newItem["__EMPTY_1"] = item["__EMPTY_1"]
          newItem["__EMPTY_2"] = item["__EMPTY_2"];
          newItem["__EMPTY_3"] = item["__EMPTY_3"];
          // newItem["__EMPTY_4"] = item["__EMPTY_4"]
          columnList.map((col) => {
            if (col == "__EMPTY_15") {
              if (item[col]) {
                item[col] = Math.round(item[col]);
              }
            }
            newItem[col] = item[col];
            if (
              typeof vTemplate[col] == "string" &&
              vTemplate[col].split("-").length > 1
            ) {
              if (col == "__EMPTY_16") {
                if (item[col] || item[col] === 0) {
                  let adjustmentType = item[col].trim();
                  let adjustmentValue = 0;
                  let option = {};
                  if (
                    _this.state.adjustmentOptionSetsData &&
                    _this.state.adjustmentOptionSetsData.length > 0
                  ) {
                    option = _this.state.adjustmentOptionSetsData.find(
                      (option) =>
                        option.displayName
                          .toLowerCase()
                          .includes(adjustmentType.toLowerCase())
                    );
                  }
                  if (option && option.code) {
                    adjustmentValue = parseInt(option.code);
                  } else {
                    adjustmentValue = item[col].toString().trim();
                  }
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: adjustmentValue,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                } else {
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: 0,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                }
              } else if (col == "__EMPTY_14") {
                if (item[col] || item[col] === 0) {
                  let lossType = item[col].trim();
                  let lossValue = 0;
                  let option = {};
                  if (
                    _this.state.lossOptionSetsData &&
                    _this.state.lossOptionSetsData.length > 0
                  ) {
                    option = _this.state.lossOptionSetsData.find((option) =>
                      option.displayName
                        .toLowerCase()
                        .includes(lossType.toLowerCase())
                    );
                  }
                  if (option && option.code) {
                    lossValue = parseInt(option.code);
                  } else {
                    lossValue = item[col].toString().trim();
                  }
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: lossValue,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                } else {
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: 0,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                }
              } else {
                if (col == "__EMPTY_13" && item[col] < 0) {
                  item[col] = 0;
                }
                if (item[col] || item[col] === 0) {
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: item[col],
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                } else {
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    deleted: true,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                }
              }
            }
          });
          gridDataValues.push(newItem);
        }
      });
      if (flag) {
        let newItem = {};
        newItem["__EMPTY"] = item["__EMPTY"];
        // newItem["__EMPTY_1"] = item["__EMPTY_1"]
        newItem["__EMPTY_2"] = item["__EMPTY_2"];
        newItem["__EMPTY_3"] = item["__EMPTY_3"];
        newItem["__EMPTY_4"] = item["__EMPTY_4"];
        columnList.map((col) => {
          if (col == "__EMPTY_15") {
            if (item[col]) {
              item[col] = Math.round(item[col]);
            }
          }
          newItem[col] = item[col];
        });
        templateEmptyKeys.push(newItem.__EMPTY);
        gridDataValues.push(newItem);
      }
    });
    dataValues.push(receiveDate);
    dataValues.push(timelyStatus);
    dataValues.push(lateStatus);

    // equipmentData
    let labTestDataStore = this.state.labTestDataStore;
    let labEquipmentDataStore = this.state.labEquipmentDataStore;
    let equipmentArr = [];

    equipmentData.map((equipment) => {
      let isAlreadyExist = false;
      let isequipmentNameSame = false;
      equipmentArr.find((equip) => {
        if (equip["serialNumber"] == equipment["__EMPTY_3"]) {
          isAlreadyExist = true;
        } else if (equip["equipmentName"] == equipment["__EMPTY_2"]) {
          isequipmentNameSame = true;
        }
      });
      if (isAlreadyExist) {
        equipmentArr = equipmentArr.map((equipmentObj) => {
          if (equipmentObj["serialNumber"] == equipment["__EMPTY_3"]) {
            let tests = equipmentObj["tests"];
            let testRecord = labTestDataStore.find((testItem) => {
              if (testItem["Test"].trim() == equipment["__EMPTY_4"].trim()) {
                return testItem;
              }
            });
            if (testRecord && testRecord["Controls"]) {
              let testObj = {
                name: equipment["__EMPTY_4"],
                value: {
                  Controls: {
                    code: testRecord["Controls"],
                    value: equipment["__EMPTY_6"],
                  },
                  Failures: {
                    code: testRecord["Failures"],
                    value: equipment["__EMPTY_7"],
                  },
                  ValidTests: {
                    code: testRecord["ValidTests"],
                    value: equipment["__EMPTY_5"],
                  },
                },
              };
              tests.push(testObj);
            }
            equipmentObj["tests"] = tests;
          }
          return equipmentObj;
        });
      } else {
        if (isequipmentNameSame) {
          equipmentArr = equipmentArr.map((equipmentObj) => {
            let tests = equipmentObj["tests"];
            let testRecord = labTestDataStore.find((testItem) => {
              if (testItem["Test"].trim() == equipment["__EMPTY_4"].trim()) {
                return testItem;
              }
            });

            if (testRecord && testRecord["Controls"]) {
              tests = tests.map((test) => {
                if (test.name == testRecord.Test) {
                  test["value"]["Controls"]["value"] =
                    test["value"]["Controls"]["value"] + equipment["__EMPTY_6"];
                  test["value"]["Failures"]["value"] =
                    test["value"]["Failures"]["value"] + equipment["__EMPTY_7"];
                  test["value"]["ValidTests"]["value"] =
                    test["value"]["ValidTests"]["value"] +
                    equipment["__EMPTY_5"];
                }
                return test;
              });
            }
            equipmentObj["tests"] = tests;
            return equipmentObj;
          });
        } else {
          let equipmentObj = {};
          let uId_value = null;
          uId_value = labEquipmentDataStore.find(
            (labEquipment) =>
              labEquipment["Equipment"].trim() == equipment["__EMPTY_2"].trim()
          );
          if (uId_value && uId_value["UID"]) {
            equipmentObj["section"] = equipment["__EMPTY"];
            equipmentObj["UID"] = uId_value["UID"];
            equipmentObj["equipmentName"] = equipment["__EMPTY_2"];
            equipmentObj["serialNumber"] = equipment["__EMPTY_3"];
            equipmentObj["tests"] = [];
            let testRecord = labTestDataStore.find((testItem) => {
              if (testItem["Test"].trim() == equipment["__EMPTY_4"].trim()) {
                return testItem;
              }
            });
            if (testRecord && testRecord["Controls"]) {
              let testObj = {
                name: equipment["__EMPTY_4"],
                value: {
                  Controls: {
                    code: testRecord["Controls"],
                    value: equipment["__EMPTY_6"],
                  },
                  Failures: {
                    code: testRecord["Failures"],
                    value: equipment["__EMPTY_7"],
                  },
                  ValidTests: {
                    code: testRecord["ValidTests"],
                    value: equipment["__EMPTY_5"],
                  },
                },
              };
              equipmentObj["tests"].push(testObj);
            }
            equipmentArr.push(equipmentObj);
          }
        }
      }
    });

    let equipmentDataValues = [];
    equipmentArr.map((equipmentItem) => {
      equipmentItem.tests.map((test) => {
        let controlsData = {};
        let failuresData = {};
        let validTestsData = {};
        controlsData["dataElement"] = equipmentItem["UID"];
        controlsData["categoryOptionCombo"] = test.value.Controls.code;
        controlsData["value"] = test.value.Controls.value;

        failuresData["dataElement"] = equipmentItem["UID"];
        failuresData["categoryOptionCombo"] = test.value.Failures.code;
        failuresData["value"] = test.value.Failures.value;

        validTestsData["dataElement"] = equipmentItem["UID"];
        validTestsData["categoryOptionCombo"] = test.value.ValidTests.code;
        validTestsData["value"] = test.value.ValidTests.value;

        equipmentDataValues.push(controlsData);
        equipmentDataValues.push(failuresData);
        equipmentDataValues.push(validTestsData);
      });
    });

    // Lab equipment template import (Functional Data)
    let equipmentSerialUid = this.state.equipmentSerialUid;
    let equipmentFunctionalDataValues = [];
    let equipmentFunctionalArr = [];
    equipmentData.map((equipment, index) => {
      let isAlreadyNotExist = true;
      let serialUidIndex = 0;
      equipmentFunctionalArr.find((equip) => {
        if (equip["equipmentName"] == equipment["__EMPTY_2"]) {
          if (equip["serialNumber"] == equipment["__EMPTY_3"]) {
            isAlreadyNotExist = false;
          } else {
            serialUidIndex = serialUidIndex + 1;
          }
        }
      });
      if (isAlreadyNotExist) {
        let equipmentObj = {};
        let uId_value = null;
        uId_value = labEquipmentDataStore.find(
          (labEquipment) =>
            labEquipment["Equipment"].trim() == equipment["__EMPTY_2"].trim()
        );
        if (uId_value && uId_value["UID"]) {
          equipmentObj["equipmentName"] = equipment["__EMPTY_2"];
          equipmentObj["serialNumber"] = equipment["__EMPTY_3"];
          equipmentFunctionalArr.push(equipmentObj);

          let equipmentIsFunctional = "0.0";
          if (
            equipment["__EMPTY_9"] &&
            equipment["__EMPTY_9"].trim().toLowerCase() == "yes"
          ) {
            equipmentIsFunctional = "1.0";
          }

          let lastServiceDateValue = null;
          let nextServiceValue = null;

          if (
            equipment["__EMPTY_10"] &&
            typeof equipment["__EMPTY_10"] == "number"
          ) {
            let baseDate = new Date("1900-01-01");
            baseDate.setDate(
              baseDate.getDate() + (parseInt(equipment["__EMPTY_10"]) - 2)
            );
            lastServiceDateValue =
              baseDate.getFullYear() +
              "-" +
              String(baseDate.getMonth() + 1).padStart(2, "0") +
              "-" +
              String(baseDate.getDate()).padStart(2, "0");
          }

          if (
            equipment["__EMPTY_11"] &&
            typeof equipment["__EMPTY_11"] == "number"
          ) {
            let baseDate = new Date("1900-01-01");
            baseDate.setDate(
              baseDate.getDate() + (parseInt(equipment["__EMPTY_11"]) - 2)
            );
            nextServiceValue =
              baseDate.getFullYear() +
              "-" +
              String(baseDate.getMonth() + 1).padStart(2, "0") +
              "-" +
              String(baseDate.getDate()).padStart(2, "0");
          }

          let serialNumberObj = {
            dataElement: uId_value["SerialNo"],
            categoryOptionCombo: equipmentSerialUid[serialUidIndex],
            value: equipment["__EMPTY_3"],
          };

          let numberOfDaysEquipNotFunctioning = {
            dataElement: uId_value["NoOfDaysEquipNotFunctioning"],
            categoryOptionCombo: equipmentSerialUid[serialUidIndex],
          };

          if (equipment["__EMPTY_8"] || equipment["__EMPTY_8"] === 0) {
            numberOfDaysEquipNotFunctioning["value"] = equipment["__EMPTY_8"];
          } else {
            numberOfDaysEquipNotFunctioning["deleted"] = true;
          }

          let equipisFunctional = {
            dataElement: uId_value["EquipisFunctional"],
            categoryOptionCombo: equipmentSerialUid[serialUidIndex],
            value: equipmentIsFunctional,
          };

          let equipisNoneFunctional = {
            dataElement: uId_value["EquipisNoneFunctional"],
            categoryOptionCombo: equipmentSerialUid[serialUidIndex],
            value: equipmentIsFunctional == 1 ? "0.0" : "1.0",
          };
          let lastServiceDate = {
            dataElement: uId_value["LastServiceDate"],
            categoryOptionCombo: equipmentSerialUid[serialUidIndex],
            value: lastServiceDateValue,
          };
          let nextService = {
            dataElement: uId_value["NextService"],
            categoryOptionCombo: equipmentSerialUid[serialUidIndex],
            value: nextServiceValue,
          };

          equipmentFunctionalDataValues.push(serialNumberObj);
          equipmentFunctionalDataValues.push(numberOfDaysEquipNotFunctioning);
          equipmentFunctionalDataValues.push(equipisFunctional);
          equipmentFunctionalDataValues.push(equipisNoneFunctional);
          equipmentFunctionalDataValues.push(lastServiceDate);
          equipmentFunctionalDataValues.push(nextService);
        }
      }
    });

    let vEnquiryJsonData = {
      resource: "dataValueSets",
      type: "create",
      data: {
        period: this.state.selectedMonthYear,
        orgUnit: this.state.selectedFacility,
        dataValues: equipmentDataValues.concat(equipmentFunctionalDataValues),
      },
    };

    this.setState({ vEnquiryJsonData });
    if (dataValues.length > 0 && gridDataValues.length > 0) {
      // for found blank/negative products
      let checkColumns = [
        "__EMPTY_4",
        "__EMPTY_5",
        "__EMPTY_6",
        "__EMPTY_7",
        "__EMPTY_8",
        "__EMPTY_9",
        "__EMPTY_11",
        "__EMPTY_15",
      ];
      let blankOrNegativeRocords = gridDataValues.filter((item) => {
        let flag = false;
        checkColumns.map((col) => {
          if (
            item[col] &&
            typeof item[col] == "object" &&
            (item[col].value == undefined ||
              (col != "__EMPTY_8" &&
                item[col].value &&
                Math.sign(item[col].value) == -1))
          ) {
            flag = true;
          }
        });
        if (flag) {
          return item;
        }
      });

      // for found duplicate products
      let dataValuesCode = gridDataValues.map((item) => item["__EMPTY"]);
      let counts = {};
      let duplicateRecords = [];
      for (let i = 0; i < dataValuesCode.length; i++) {
        if (counts[dataValuesCode[i]]) {
          counts[dataValuesCode[i]] += 1;
        } else {
          counts[dataValuesCode[i]] = 1;
        }
      }
      for (let prop in counts) {
        if (counts[prop] >= 2) {
          duplicateRecords.push(prop);
        }
      }
      if (duplicateRecords.length == 0 && blankOrNegativeRocords.length == 0) {
        let vJsonData = {
          resource: "dataValueSets",
          type: "create",
          data: {
            period: this.state.selectedMonthYear,
            orgUnit: this.state.selectedFacility,
            dataValues: dataValues,
          },
        };

        console.log("vJsonData: ", vJsonData);

        this.setState({
          templateEmptyKeys,
          // gridDataValues,
          gridDataValues: gridDataValues.filter(
            (item) =>
              !(item["__EMPTY"] && templateEmptyKeys.includes(item["__EMPTY"]))
          ),
          missingProducts: gridDataValues.filter(
            (item) =>
              item["__EMPTY"] && templateEmptyKeys.includes(item["__EMPTY"])
          ),
          vJsonData,
          saveJsonData: true,
        });
      } else {
        this.setState({
          templateEmptyKeys,
          gridDataValues,
          blankOrNegativeRocords,
          duplicateProducts: gridDataValues.filter((item) =>
            duplicateRecords.includes(item["__EMPTY"])
          ),
          showDuplicateProducts: true,
          conflictKeyList: duplicateRecords,
          conflictStatus: true,
          gridHeadingTitle: "Duplicate Products",
          firstStep: false,
          secondStep: false,
          loading: false,
        });
      }
    } else {
      this.setState({
        error: "Template file key's didn't match with uploaded file",
        loading: false,
      });
    }
  }

  generatePeriods(defaultYear, defaultMonth) {
    if (defaultMonth == 0) {
      defaultYear = defaultYear - 1;
      defaultMonth = 12;
    }
    let months = Constants.MONTH_NAME;
    let periods = [];
    let currentyear = new Date().getFullYear();
    if (currentyear !== defaultYear) {
      defaultMonth = 12;
    }
    for (let i = defaultMonth - 1; i >= 0; i--) {
      let option = {};
      option["name"] = months[i] + " " + defaultYear;
      option["id"] = defaultYear + String(i + 1).padStart(2, "0");
      periods.push(option);
    }
    if (this.state.deleteUploadedFile) {
      this.setState({
        periods,
        dataSetRegistrations: [],
      });
    } else {
      this.setState({
        periods,
        selectedMonthYear: periods[0].id,
        dataSetRegistrations: [],
      });
    }
  }

  setPeriods(year) {
    if (year == "previous") {
      this.setState({
        defaultYear: this.state.defaultYear - 1,
        getDataSetRegistrations: true,
      });
      this.generatePeriods(this.state.defaultYear - 1, this.state.defaultMonth);
    } else {
      let currentyear = new Date().getFullYear();
      if (currentyear !== this.state.defaultYear) {
        this.setState({
          defaultYear: this.state.defaultYear + 1,
          getDataSetRegistrations: true,
        });
        this.generatePeriods(
          this.state.defaultYear + 1,
          this.state.defaultMonth
        );
      }
    }
  }

  getAdjustmentOptionSetsResponse(data) {
    if (data && data.options) {
      this.setState({
        getAdjustmentOptionSets: false,
        adjustmentOptionSetsData: data.options.options,
        // getLossOptionSets: true
        getCmsLabTemplateSettings: true,
      });
    }
  }

  getLossOptionSetsResponse(data) {
    if (data && data.options) {
      this.setState({
        getLossOptionSets: false,
        lossOptionSetsData: data.options.options,
        getOrgUnits: true,
        getDataSetRegistrations: true,
      });
    }
  }

  getGeneralSettingsResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        generalMutationData: data.dataStore,
        getGeneralSettings: false,
        // getAdjustmentOptionSets: true
        getLabTemplateData: true,
      });
    }
  }

  getAppSettingsResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        labMutationData: data.dataStore,
        selectedFacility: data.dataStore.LABOrganisationUnitGroup,
        getAppSettings: false,
        getLabTest: true,
      });
    }
  }

  getLabTestResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        labTestDataStore: data.dataStore,
        getLabTest: false,
        getLabEquipment: true,
      });
    }
  }

  getLabEquipmentResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        labEquipmentDataStore: data.dataStore,
        getLabEquipment: false,
        getGeneralSettings: true,
      });
    }
  }

  getLabTemplateSettings(data) {
    if (data && data.dataStore) {
      this.setState({
        vTemplateData: data.dataStore,
        getAdjustmentOptionSets: true,
        getLabTemplateData: false,
      });
    } else {
      this.setState({
        loading: false,
        error: "Lab Template JSON missing!",
      });
    }
  }

  uploadAmcMosResponse = (response, AMCs, MOSs) => {
    if (response.conflicts.length > 0) {
      alert(
        "Uploading AMC and MOS has coflicts: " +
          JSON.stringify(response.conflicts)
      );
      this.setState({
        loading: false,
        error: "Uploading AMC and MOS has coflicts",
      });
    } else {
      this.setState({
        fourthStep: true,
        thirdStep: false,
        loading: false,
        AMCs,
        MOSs,
      });
    }
  };

  dataFixUploadAmcMosResponse = (response, AMCs, MOSs) => {
    console.log("response: ", response);
    if (response.conflicts.length > 0) {
      this.setState({
        loading: false,
        bShowDataFixCalculation: false,
        error: JSON.stringify(response.conflicts),
      });
    } else {
      this.setState({
        loading: false,
        bShowDataFixCalculation: false,
        successMsg: "Data fixation completed",
        dataFixBtnDisabled: false,
        dataFixBtnBack: false,
      });
    }
  };

  getNextPeriod = (ym) => {
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    if (month == 12) {
      month = 1;
      year = year + 1;
    } else {
      month = month + 1;
    }

    ym = year + month.toString().padStart(2, "0");

    return ym;
  };

  render() {
    return (
      <>
        {this.state.getAppSettings && (
          <GetAppSettingsNew
            query={getAppSettingsQuery}
            onResponse={this.getAppSettingsResponse}
          />
        )}
        {this.state.getLabTest && (
          <GetAppSettingsNew
            query={getLabTestQuery}
            onResponse={this.getLabTestResponse}
          />
        )}
        {this.state.getLabEquipment && (
          <GetAppSettingsNew
            query={getLabEquipmentQuery}
            onResponse={this.getLabEquipmentResponse}
          />
        )}
        {this.state.getGeneralSettings && (
          <GetAppSettingsNew
            query={getGeneralSettingsQuery}
            onResponse={this.getGeneralSettingsResponse}
          />
        )}
        {this.state.getLabTemplateData && (
          <GetLabTemplateSettings
            query={labTemplateQuery}
            onResponse={this.getLabTemplateSettings}
          />
        )}
        {this.state.getCmsLabTemplateSettings && (
          <GetAppSettingsNew
            query={getCmsLabTemplateSettingsQuery}
            onResponse={this.getCmsLabTemplateSettingsResponse}
          />
        )}
        {this.state.getAdjustmentOptionSets && (
          <GetOptionSets
            query={getOptionSetsQuery}
            optionSetId={this.state.generalMutationData.AdjustmentOptionSet}
            onResponse={this.getAdjustmentOptionSetsResponse}
          />
        )}
        {this.state.getLossOptionSets && (
          <GetOptionSets
            query={getOptionSetsQuery}
            optionSetId={this.state.generalMutationData.LossOptionSet}
            onResponse={this.getLossOptionSetsResponse}
          />
        )}
        {this.state.fourthStep && (
          <ExcelImportAppLogsJson
            onComplete={(result) => {
              this.setState({
                fourthStep: false,
                fifthStep: true,
                loading: false,
              });
            }}
            query={mutationExcelImportAppLogsJson}
            importTemplateLogsJson={this.state.importTemplateLogsJson}
            onResponse={this.getExcelImportAppLogsJson}
          />
        )}
        {this.state.saveJsonData && (
          <InsertDataValueSets
            onComplete={(result) => {
              let conflictKeyList = [];
              let statusBtnIcon = null;
              let conflictStatus = false;
              if (result.conflicts && result.conflicts.length > 0) {
                conflictStatus = true;
              }
              result.conflicts.map((conflict) => {
                if (conflict.value) {
                  conflictKeyList.push(conflict.object.trim());
                }
              });
              let selectedFacility = this.state.orgUnits.find(
                (item) => item.id === this.state.selectedFacility
              );
              let importTemplateLogsJson = this.props.importTemplateLogs || [];
              importTemplateLogsJson.push({
                User: this.state.user.displayName,
                DateTime: new Date().toISOString(),
                FileName: this.state.fileName,
                FacilityName: selectedFacility
                  ? selectedFacility.displayName
                  : "",
                MonthYear: this.state.selectedMonthYear,
                Status: {
                  Message:
                    conflictKeyList.length == 0
                      ? "Import process completed successfully"
                      : "Import process completed with error",
                  conflicts: result.conflicts,
                },
              });
              this.setState({
                importTemplateLogsJson,
                conflictStatus,
                statusBtnIcon,
                conflictKeyList,
                saveJsonData: false,
                resultStatus: result.status,
                resInsertData: result,
                // firstStep: false,
                // secondStep: false,
                // thirdStep: true,
                // setDataSetRegistration: true,
                saveEnquiryJsonData: true,
              });
            }}
            vJsonData={this.state.vJsonData}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {this.state.saveEnquiryJsonData && (
          <InsertDataValueSets
            onComplete={(result) => {
              this.setState({
                saveEnquiryJsonData: false,
                firstStep: false,
                secondStep: false,
                thirdStep: true,
                setDataSetRegistration: true,
              });
            }}
            vJsonData={this.state.vEnquiryJsonData}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {/* {this.state.deleteUploadedFile && (
          <InsertDataValueSets
            onComplete={(result) => {
              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: false,
                afterDeleteUploadedFile: true,
              });
            }}
            vJsonData={this.deleteJsonData()}
            resposeSaveJson={this.resposeSaveJson}
          />
        )} */}
        {this.state.deleteUploadedFile && (
          <DeleteDataValues
            onComplete={(result) => {
              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: false,
                afterDeleteUploadedFile: true,
              });
            }}
            vJsonData={this.deleteJsonData()}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {this.state.afterDeleteUploadedFile && (
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson={mutationDatasetRegJson}
            orgUnitId={this.state.selectedFacility}
            period={this.state.selectedMonthYear}
            completed={false}
            labMutationData={this.state.labMutationData}
            saveDataSetRegistration={this.saveDataSetRegistration}
          />
        )}
        {this.state.firstStep && (
          <FirstStep
            deleteUploadedFile={this.deleteUploadedFile}
            searchFacility={this.state.searchFacility}
            handleSearchFacility={this.handleSearchFacility}
            handleFirstStep={this.handleFirstStep}
            readExcel={this.readExcel}
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            dataSetRegistrations={this.state.dataSetRegistrations}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
            calculateImportStatus={this.calculateImportStatus}
            facilityGridData={this.facilityGridData}
            handleDataFixFirstStep={this.handleDataFixFirstStep}
          />
        )}
        {this.state.firstStep && this.state.getOrgUnits && (
          <GetOrgUnitGroups
            response={this.getOrgUnitGroups}
            orgUnitsQuery={orgUnitsQuery}
            labMutationData={this.state.labMutationData}
            selectedFacility={this.state.selectedFacility}
            handleError={this.handleError}
            stateError={this.state.error}
          />
        )}
        {this.state.firstStep && this.state.getDataSetRegistrations && (
          <GetCompleteDataSetRegistrations
            dataSetRegistrationQuery={dataSetRegistrationQuery}
            selectedMonthYear={this.state.selectedMonthYear}
            labMutationData={this.state.labMutationData}
            response={this.getCompleteDataSet}
            handleError={this.handleError}
            stateError={this.state.error}
          />
        )}
        {this.state.setDataSetRegistration && (
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson={mutationDatasetRegJson}
            orgUnitId={this.state.selectedFacility}
            period={this.state.selectedMonthYear}
            completed={true}
            labMutationData={this.state.labMutationData}
            saveDataSetRegistration={this.saveDataSetRegistration}
          />
        )}
        {(this.state.secondStep ||
          this.state.thirdStep ||
          this.state.fourthStep) && (
          <SecondStep
            handleSecondStep={this.handleSecondStep}
            readExcel={this.readExcel}
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
          />
        )}
        {this.state.thirdStep && this.state.resultStatus && (
          <CalculateAmcMos
            items={this.state.items}
            vTemplateData={this.state.vTemplateData}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            labMutationData={this.state.labMutationData}
            uploadAmcMosResponse={this.uploadAmcMosResponse}
          />
        )}
        {this.state.fifthStep && (
          <ImportProgressLabTemplate
            changePanel={this.changePanel}
            items={this.state.items}
            vJsonData={this.state.vJsonData}
            loading={this.state.loading}
            headingTitle={this.state.headingTitle}
            resInsertData={this.state.resInsertData}
            resultStatus={this.state.resultStatus}
            conflictStatus={this.state.conflictStatus}
            conflictKeyList={this.state.conflictKeyList}
            gridDataValues={this.state.gridDataValues}
            missingProducts={this.state.missingProducts}
            templateEmptyKeys={this.state.templateEmptyKeys}
            fileName={this.state.fileName}
            statusBtnIcon={this.state.statusBtnIcon}
            redirectToFirstStep={this.redirectToFirstStep}
            AMCs={this.state.AMCs}
            MOSs={this.state.MOSs}
          />
        )}
        {this.state.showDuplicateProducts && (
          <ShowDuplicateProducts
            duplicateProducts={this.state.duplicateProducts}
            blankOrNegativeRocords={this.state.blankOrNegativeRocords}
            showDuplicateProducts={this.state.showDuplicateProducts}
            redirectToFirstStep={this.redirectToFirstStep}
            gridHeadingTitle={this.state.gridHeadingTitle}
            gridDataValues={this.state.gridDataValues}
            changePanel={this.changePanel}
            resultStatus="ERROR"
            loading={this.state.loading}
            headingTitle={this.state.headingTitle}
            conflictStatus={this.state.conflictStatus}
            conflictKeyList={this.state.conflictKeyList}
            templateEmptyKeys={this.state.templateEmptyKeys}
            fileName={this.state.fileName}
          />
        )}
        {this.state.dataFixSecondStep && (
          <DataFixSecondStep
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            successMsg={this.state.successMsg}
            closeAlertBarMsg={this.closeAlertBarMsg}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
            handleDataFixSecondStep={this.handleDataFixSecondStep}
            redirectToFirstStep={this.redirectToFirstStep}
            dataFixBtnDisabled={this.state.dataFixBtnDisabled}
            dataFixBtnBack={this.state.dataFixBtnBack}
          />
        )}
        {this.state.bShowDataFixCalculation && (
          <DataFixCalculation
            items={this.state.items}
            vTemplateData={this.state.vTemplateData}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            labMutationData={this.state.labMutationData}
            dataFixUploadAmcMosResponse={this.dataFixUploadAmcMosResponse}
          />
        )}
      </>
    );
  }
}

export default ImportLabTemplate;
