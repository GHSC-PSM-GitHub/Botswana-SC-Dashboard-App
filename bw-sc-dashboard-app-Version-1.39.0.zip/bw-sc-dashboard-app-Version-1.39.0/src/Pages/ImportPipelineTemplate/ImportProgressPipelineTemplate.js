import React, { Component } from 'react';
import Dropzone from 'react-dropzone';
import styles from '../Pages.module.css';
import StatusTemplate from './statusTemplate';
import { Menu, MenuItem, Button, Table, TableHead, TableBody, TableRow, TableRowHead, TableCellHead, TableCell, CircularLoader, AlertBar } from '@dhis2/ui-core';
import Constant from '../../helpers/constants';

const LIST_ICON_WARNING = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="30px" height="30px"><path fill="#ffc107" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>
const LIST_ICON_SUCCESS = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="30px" height="30px"><path fill="#28a745" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>

const LIST_ICON_FAILURE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 24 24" width="25px" height="25px"><path fill="#FF0000" d="M16.971 0h-9.942l-7.029 7.029v9.941l7.029 7.03h9.941l7.03-7.029v-9.942l-7.029-7.029zm-1.402 16.945l-3.554-3.521-3.518 3.568-1.418-1.418 3.507-3.566-3.586-3.472 1.418-1.417 3.581 3.458 3.539-3.583 1.431 1.431-3.535 3.568 3.566 3.522-1.431 1.43z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>

const LIST_ICON_WARNING_BIG_SIZE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="50px" height="50px"><path fill="#ffc107" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>
const LIST_ICON_SUCCESS_BIG_SIZE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 48 48" width="50px" height="50px"><path fill="#28a745" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>

const LIST_ICON_FAILURE_BIG_SIZE = <Button
  dataTest="dhis2-uicore-button"
  icon={<svg viewBox="0 0 24 24" width="40px" height="40px"><path fill="#FF0000" d="M16.971 0h-9.942l-7.029 7.029v9.941l7.029 7.03h9.941l7.03-7.029v-9.942l-7.029-7.029zm-1.402 16.945l-3.554-3.521-3.518 3.568-1.418-1.418 3.507-3.566-3.586-3.472 1.418-1.417 3.581 3.458 3.539-3.583 1.431 1.431-3.535 3.568 3.566 3.522-1.431 1.43z"/></svg>}
  name="Icon button"
  type="button"
  value="default"
  className={styles.list_icon_btn}
/>


class ImportProgressPipelineTemplate extends Component {
  constructor( props ) {
		super( props );
		this.state = {
      loading: true
		}
	}

  componentWillMount(){
    this.setState({loading: this.props.loading});
  }

  componentWillReceiveProps(nextProps){
    if (this.state.loading && this.props.items && this.props.items.length && this.props.gridDataValues.length>0 && this.props.AMCs.length>0 && this.props.MOSs.length>0 && this.props.resInsertData && this.props.resultStatus) {
      this.setState({loading: false});
    }

  }

  getTableHeading = (items)=>{
    let table_headings = Object.keys(items[0])
    return(
      <TableRowHead dataTest="dhis2-uicore-tablerow">
        <TableCellHead dataTest="dhis2-uicore-tablecellhead">
          SI#
        </TableCellHead>
        {
          table_headings.map((col, key)=>{
            return(
              <TableCellHead key={key} dataTest="dhis2-uicore-tablecellhead">
                {col}
              </TableCellHead>
            )
          })
        }
      </TableRowHead>
    )
  }

  getTableList = (items, conflictKeyList, templateEmptyKeys)=>{
    if (items.length == 0){
      return;
    }
    let keys = Object.keys(items[0])
    if (items.length>0) {
      return items.map((item, table_row)=>{
        return(
          <TableRow key={table_row} dataTest="dhis2-uicore-tablerow" >
            <TableCell dataTest="dhis2-uicore-tablecell">
              {table_row + 1}
            </TableCell>
            {
              keys.map((col, col_key)=>{
                  return(
                    <TableCell key={col_key} dataTest="dhis2-uicore-tablecell">
                      { item[col] ? item[col] : null}
                    </TableCell>
                  )
              })
            }
          </TableRow>
        )
      })
    }
  }

  render() {
    const resultStatus = this.props.resultStatus
    return (
      <>
        <div className={styles.progressPanel} >
          {
            this.state.loading && <center>
              <CircularLoader className={styles.loading_icon}  dataTest="dhis2-uicore-circularloader" large />
            </center>
          }
          <div className={styles.progressTabRow}>
            <div className={styles.progressTabLeftContainer}>
              <h2>Import QAT/S. Plan Data - Import Progress</h2>
              <p>Step 2 of 2: Import the Excel file data into DHIS2</p>
              <ul className={styles.progressPanelList}>
                {
                  this.props.headingTitle.facilityName &&
                    <li>
                      {LIST_ICON_SUCCESS}
                      Excel template contains data for {this.props.headingTitle.facilityName} - {this.props.headingTitle.monthName} {this.props.headingTitle.year}
                    </li>
                }
                {
                  (this.props.gridDataValues && this.props.gridDataValues.length>0 && this.props.templateEmptyKeys.length == 0) && resultStatus != "ERROR" &&
                  <li>
                    {LIST_ICON_SUCCESS}
                    Importing {this.props.productCount} products
                  </li>
                }
                {
                  (this.props.gridDataValues && this.props.gridDataValues.length>0 && this.props.templateEmptyKeys.length>0) && resultStatus != "ERROR" &&
                  <li>
                    {LIST_ICON_WARNING}
                    Importing {(this.props.gridDataValues && this.props.gridDataValues.length) ? this.props.gridDataValues.length : "XXX"} products, {this.props.gridDataValues.length - this.props.templateEmptyKeys.length} imported!
                  </li>
                }
                {
                  resultStatus && resultStatus != "ERROR" &&
                  <li>
                    {resultStatus == "WARNING" ? LIST_ICON_WARNING : (resultStatus == "SUCCESS" ? LIST_ICON_SUCCESS : null)}
                    Import completed with {resultStatus == "WARNING" ? "warning" : (resultStatus == "SUCCESS" ? "success" : null)}!
                  </li>
                }
                {
                  resultStatus == "ERROR" &&
                  <li>
                    {LIST_ICON_FAILURE}
                    Import not completed
                  </li>
                }
                {/* {
                  resultStatus && resultStatus != "ERROR" &&
                  <li>
                  {
                    (this.props.AMCs && this.props.AMCs.length>0 && this.props.MOSs && this.props.MOSs.length>0) ? LIST_ICON_SUCCESS : LIST_ICON_WARNING
                  }
                    Calculating AMC/MOS
                  </li>
                } */}
              </ul>
            </div>
            {
              resultStatus && 
              <div className={styles.progressTabRightContainer}>
                <div className = {styles.importSuccessBox}>
                {
                  resultStatus == "SUCCESS" && (!this.props.conflictStatus) &&
                  <label>{LIST_ICON_SUCCESS_BIG_SIZE} IMPORT SUCCESS! </label>
                }
                {
                  resultStatus == "WARNING" && (!this.props.conflictStatus) &&
                  <label>{LIST_ICON_WARNING_BIG_SIZE} IMPORT FAILURE! </label>
                }
                {
                  resultStatus == "WARNING" && this.props.conflictStatus &&
                  <label>{LIST_ICON_FAILURE_BIG_SIZE} IMPORT FAILURE! </label>
                }
                {
                  resultStatus == "ERROR" &&
                  <label>{LIST_ICON_FAILURE_BIG_SIZE} IMPORT FAILURE! </label>
                }
                <br/> <br/>
                {
                  resultStatus == "WARNING" &&
                  <label className={styles.upload_another_template} >Review Import Summary below </label>
                }
                <br/>
                <label>
                  <Button
                    dataTest="dhis2-uicore-button"
                    large
                    name="Primary button"
                    onClick = {this.props.redirectToFirstStep}
                    primary
                    type="button"
                    value="default"
                    className={styles.upload_another_template}
                  >
                    UPLOAD ANOTHER TEMPLATE
                  </Button>
                </label>

                </div>
              </div>
            }
          </div>
          <div className={styles.progress_table}>
            <Table dataTest="dhis2-uicore-table">
              <TableHead dataTest="dhis2-uicore-tablehead">
                {
                  this.getTableHeading(this.props.gridDataValues)
                }
              </TableHead>
              <TableBody dataTest="dhis2-uicore-tablebody">
              {
                this.getTableList(this.props.gridDataValues, this.props.conflictKeyList, this.props.templateEmptyKeys)
              }
              </TableBody>
            </Table>
          </div>
          <StatusTemplate
            resInsertData = {this.props.resInsertData}
            resultStatus = {this.props.resultStatus}
            fileName = {this.props.fileName}
          />
        </div>
      </>
    );
  }
}

export default ImportProgressPipelineTemplate;