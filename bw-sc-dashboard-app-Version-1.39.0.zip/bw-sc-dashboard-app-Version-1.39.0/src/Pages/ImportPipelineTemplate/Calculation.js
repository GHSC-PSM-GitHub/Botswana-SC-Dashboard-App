import { useEffect } from 'react'
import { useDataEngine } from '@dhis2/app-runtime'

const LEGENDS_MAP = ["Stockout", "Potential Stockout", "Understock", "Satisfactory", "Risk of Expiry"];

const CalculateAmcMos = (props) => {
  
    const engine = useDataEngine()

    const query = {
        "dataValueSets": {
            "resource": "dataValueSets",
            "params": {
                "dataSet": props.pipelineMutationData.PipelineDataset,
                "period": props.selectedMonthYear,
                "orgUnit": props.selectedFacility,
                "includeDeleted": true
            }

        }
    }

    const mutationJson = {
        "resource": "dataValueSets",
        "type": "create",
        "data": {        
            "dataValues": []
        }
    }
    
    const queryLegendSetsById = {
        "legendsSets": {
          "resource": "legendSets",
          "id": props.pipelineMutationData.PipelineLegend,
          "params":{
              "fields": "id, displayName, legends[id,displayName, startValue, endValue]"
          }
        }
    }

    let itemsExcelTemplate = [];
    let legends = [];

    const AMCs = []; 
    const MOSs = []; 
   
    const getTemplateExcelElements = () => {
      const vTemplateData = props.vTemplateData.filter((item)=>(       
        item["__EMPTY"] &&
          item["__EMPTY_4"] &&
          item["__EMPTY_4"].length == 23
      
      ))
  
      const items = props.items;
     
      const itemsByCode = {};
  
      items.map( (item) => {                   
        itemsByCode[item['__EMPTY']] = item;        
      }) 

      vTemplateData.map( ( vTemplate, index ) => {
        
  
        let code = vTemplate['__EMPTY'];

        if( itemsByCode[code] != undefined ){  
            if(code == itemsByCode[code]['__EMPTY']){
    
                itemsExcelTemplate[index] = {
                  ItemCode: vTemplate["__EMPTY"],
                  ConsumptionUID: vTemplate["__EMPTY_6"],
                  ClosingUID: vTemplate["__EMPTY_9"],
                  AmcUID: vTemplate["__EMPTY_15"],
                  MosUID: vTemplate["__EMPTY_22"],
                  PreMonthUID: vTemplate["__EMPTY_23"],
                  PrePreMonthUID: vTemplate["__EMPTY_24"],

                  //Stockout
                  StockoutUID: vTemplate["__EMPTY_25"],
                  //Emergency
                  Potential_StockoutUID: vTemplate["__EMPTY_26"],
                  //Understock
                  UnderstockUID: vTemplate["__EMPTY_27"],
                  //Adequate
                  SatisfactoryUID: vTemplate["__EMPTY_28"],
                  //Overstock
                  Risk_of_ExpiryUID: vTemplate["__EMPTY_29"],

                  Closing_Zero_Stock: vTemplate["__EMPTY_30"],

                  Consumption: itemsByCode[code]["__EMPTY_7"],
                  Closing: itemsByCode[code]["__EMPTY_11"],
                };
    
            }
        }
  
        }
      )
     
      getLegends();      
          
    }

    const getCrossMatchedData = (data) => {

      let dValuesByEID = {};
      if(data && data.dataValueSets && data.dataValueSets.dataValues){
        data.dataValueSets.dataValues.map((d)=>{
          dValuesByEID[ d.dataElement + '-' + d.categoryOptionCombo ] = {                   
            dataElement: d.dataElement,
            categoryOptionCombo: d.categoryOptionCombo,
            value: d.value
          };
        });
      }
      const items = []
          
      itemsExcelTemplate.map((uids, index)=>{
        let consumption_eid = '';
        let closing_eid = '';
        let amc_eid = '';
        let mos_eid = '';
        let premonth_eid = '';
        let prepremonth_eid = '';

        let stockout_eid = '';
        let potential_stockout_eid = '';
        let understock_eid = '';
        let satisfactory_eid = '';
        let risk_of_expiry_eid = ''
        let closing_zero_stock_eid = "";

        let consumption_cc = '';
        let closing_cc = '';
        let amc_cc = '';
        let mos_cc = '';
        let premonth_cc = '';
        let prepremonth_cc = '';

        let stockout_cc = '';
        let potential_stockout_cc = '';
        let understock_cc = ''
        let satisfactory_cc = '';
        let risk_of_expiry_cc = ''
        let closing_zero_stock_cc = "";

        let consumption_value = 0;
        let closing_value = 0;
        let amc_value = 0;
        let mos_value = 0;
        let premonth_value = 0;
        let prepremonth_value = 0;

        let stockout_value = 0;
        let potential_stockout_value = 0;
        let understock_value = 0
        let satisfactory_value = 0;
        let risk_of_expiry_value = 0;
        let closing_zero_stock_value = 0;
         
        if(dValuesByEID[uids.ConsumptionUID] != undefined){
          consumption_eid = dValuesByEID[uids.ConsumptionUID].dataElement;               
          consumption_cc = dValuesByEID[uids.ConsumptionUID].categoryOptionCombo;               
          consumption_value = dValuesByEID[uids.ConsumptionUID].value;               
        }

        if(dValuesByEID[uids.ClosingUID] != undefined){
          closing_eid = dValuesByEID[uids.ClosingUID].dataElement;               
          closing_cc = dValuesByEID[uids.ClosingUID].categoryOptionCombo;
          closing_value = dValuesByEID[uids.ClosingUID].value;               
        }

        if(uids.AmcUID != undefined){
          amc_eid = uids.AmcUID.split("-")[0];               
          amc_cc = uids.AmcUID.split("-")[1];
          amc_value = 0;                         
        }

        if(uids.MosUID != undefined){
          mos_eid = uids.MosUID.split("-")[0];               
          mos_cc = uids.MosUID.split("-")[1];
          mos_value = 0.0;               
        }

        

        if(uids.PreMonthUID != undefined){                     
          if(dValuesByEID[uids.PreMonthUID] != undefined){
            premonth_eid = dValuesByEID[uids.PreMonthUID].dataElement; 
            premonth_cc = dValuesByEID[uids.PreMonthUID].categoryOptionCombo;
            premonth_value = dValuesByEID[uids.PreMonthUID].value;               
          } else {       
            premonth_eid = uids.PreMonthUID.split("-")[0];               
            premonth_cc = uids.PreMonthUID.split("-")[1];
            premonth_value = 0;  
          }             
        }

        if(uids.PrePreMonthUID != undefined){
            if(dValuesByEID[uids.PrePreMonthUID] != undefined){
                prepremonth_eid = dValuesByEID[uids.PrePreMonthUID].dataElement; 
                prepremonth_cc = dValuesByEID[uids.PrePreMonthUID].categoryOptionCombo;
                prepremonth_value = dValuesByEID[uids.PrePreMonthUID].value;               
            } else {       
                prepremonth_eid = uids.PrePreMonthUID.split("-")[0];               
                prepremonth_cc = uids.PrePreMonthUID.split("-")[1];
                prepremonth_value = 0; 
          }              
        }

        if(uids.StockoutUID != undefined){
          stockout_eid = uids.StockoutUID.split("-")[0];               
          stockout_cc = uids.StockoutUID.split("-")[1];
          stockout_value = 0;               
        }

        if(uids.Potential_StockoutUID != undefined){
          potential_stockout_eid = uids.Potential_StockoutUID.split("-")[0];               
          potential_stockout_cc = uids.Potential_StockoutUID.split("-")[1];
          potential_stockout_value = 0;               
        }

        if(uids.UnderstockUID != undefined){
          understock_eid = uids.UnderstockUID.split("-")[0];               
          understock_cc = uids.UnderstockUID.split("-")[1];
          understock_value = 0;               
        }

        if(uids.SatisfactoryUID != undefined){
          satisfactory_eid = uids.SatisfactoryUID.split("-")[0];               
          satisfactory_cc = uids.SatisfactoryUID.split("-")[1];
          satisfactory_value = 0;               
        }

        if(uids.Risk_of_ExpiryUID != undefined){
          risk_of_expiry_eid = uids.Risk_of_ExpiryUID.split("-")[0];               
          risk_of_expiry_cc = uids.Risk_of_ExpiryUID.split("-")[1];
          risk_of_expiry_value = 0;               
        }

        if (uids.Closing_Zero_Stock != undefined) {
          closing_zero_stock_eid = uids.Closing_Zero_Stock.split("-")[0];
          closing_zero_stock_cc = uids.Closing_Zero_Stock.split("-")[1];

          if (closing_value == 0) {
            closing_zero_stock_value = 1;
          } else {
            closing_zero_stock_value = 0;
          }
        }
        
        items[index] = {
          ItemCode: uids.ItemCode,
          Consumption_InExcel: uids.Consumption ,
          Closing_InExcel: uids.Closing ,
          Consumption_InDataset: { eid: consumption_eid, cc: consumption_cc, value: consumption_value },
          Closing_InDataset: { eid: closing_eid, cc: closing_eid, value: closing_value },
          Amc_InDataset: { eid: amc_eid, cc: amc_cc, value: amc_value },          
          MOS_InDataset: { eid: mos_eid, cc: mos_cc, value: mos_value },
          PreMonth_InDataset: { eid: premonth_eid, cc: premonth_cc, value: premonth_value },
          PrePreMonth_InDataset: { eid: prepremonth_eid, cc: prepremonth_cc, value: prepremonth_value },         
          Closing_Zero_Stock_InExcel: { eid: closing_zero_stock_eid, cc: closing_zero_stock_cc, value: closing_zero_stock_value },
          
          Legends:{
            Stockout: { eid: stockout_eid, cc: stockout_cc, value: stockout_value }, 
            "Potential Stockout": { eid: potential_stockout_eid, cc: potential_stockout_cc, value: potential_stockout_value }, 
            Understock: { eid: understock_eid, cc: understock_cc, value: understock_value }, 
            Satisfactory: { eid: satisfactory_eid, cc: satisfactory_cc, value: satisfactory_value }, 
            "Risk of Expiry": { eid: risk_of_expiry_eid, cc: risk_of_expiry_cc, value: risk_of_expiry_value }, 
          }


        }
      })

     
      const newItems = createAmcMos(items)
      
      uploadAmcMos(newItems);
      
    }


    const getLegends = () => {

      engine.query(queryLegendSetsById, {

        onComplete: res => {

          legends = res.legendsSets.legends.sort(GetSortOrder("startValue"));
          
          // // remove first element 'Non-use'        
          // legends.shift();

          getDataValues();
          
        },

        onError: error => {
                        
        }

      })

    }
    
    const getDataValues = () => {

      engine.query(query, {

        onComplete: data => {
          
          getCrossMatchedData(data)
          
        },

        onError: error => {
                        
        }

      })

    }

    const getNextPeriod = (ym) => {        
      //ym = "202103";
      let year = parseInt(ym.substring(0, 4));
      let month = parseInt(ym.substring(4));

      if ( month == 12 ){
        month = 1;
        year = year + 1;
      } else {
        month = month + 1;
      }

      ym = year + month.toString().padStart(2, '0');
      
      return ym;

    }


    const createAmcMos = (items) => {

        let idx = 0;
        const newItems = [];

        let idxAmc = 0;
        let idxMos = 0;
       
        items.map( ( item ) => {

          let divisor = 0;
          let newItem = {};
          let sum_3months = 0;
          let amc = 0;
          let mos = 0
        
          // Aggregating (PrePre + Pre + Current month) distributions
          if( !(item.PrePreMonth_InDataset.value == 0 || item.PrePreMonth_InDataset.value == undefined) ){
            divisor++;
            sum_3months = sum_3months + parseInt( item.PrePreMonth_InDataset.value );
            
          }

          if( !(item.PreMonth_InDataset.value == 0 || item.PreMonth_InDataset.value == undefined) ){
            divisor++;
            sum_3months = sum_3months + parseInt(item.PreMonth_InDataset.value);
            
          }

          if( !(item.Consumption_InDataset.value == 0 || item.Consumption_InDataset.value == undefined) ){
            divisor++; 
            sum_3months = sum_3months + parseInt(item.Consumption_InDataset.value);             
          }
         
          // creating AMC
          amc = Math.round( divisor > 0 ? sum_3months / divisor : 0 );
          
          // creating MOS
          mos = (amc > 0 ? parseInt(item.Closing_InDataset.value) / amc : 0) ;

          mos = isNaN(mos) ? 0 : mos;
                    
          // creating dataValues for AMC
          newItem = {dataElement: item.Amc_InDataset.eid,
            categoryOptionCombo: item.Amc_InDataset.cc,
            period: props.selectedMonthYear,
            orgUnit: props.selectedFacility,
            value: amc
          };         
          newItems[idx++] = newItem;
         
          mos = mos.toFixed(2);

          AMCs[idxAmc++] = {
            ItemCode: item.ItemCode,
            AMC: amc,
          }

          

          MOSs[idxMos++] = {
            
            ItemCode: item.ItemCode,
            MOS: mos,
          }
          
                  
          // creating dataValues for MOS
          newItem = {dataElement: item.MOS_InDataset.eid,
            categoryOptionCombo: item.MOS_InDataset.cc,
            period: props.selectedMonthYear,
            orgUnit: props.selectedFacility,
            value: mos};
          newItems[idx++] = newItem;

           // creating dataValues for Closing Zero Stock
          newItem = {
            dataElement: item.Closing_Zero_Stock_InExcel.eid,
            categoryOptionCombo: item.Closing_Zero_Stock_InExcel.cc,
            period: props.selectedMonthYear,
            orgUnit: props.selectedFacility,
            value: item.Closing_Zero_Stock_InExcel.value,
          };
          newItems[idx++] = newItem;
          
           // creating dataValues for [Quantity Issued PreMonth] of next month          
           newItem = {dataElement: item.PreMonth_InDataset.eid,            
            categoryOptionCombo: item.PreMonth_InDataset.cc,
            period: getNextPeriod( props.selectedMonthYear ),
            orgUnit: props.selectedFacility,
            value: item.Consumption_InDataset.value == undefined ? 0 : item.Consumption_InDataset.value
          };              
          newItems[idx++] = newItem;
          
          // creating dataValues for [Quantity Issued PrePreMonth] of next month          
          newItem = {dataElement: item.PrePreMonth_InDataset.eid,            
            categoryOptionCombo: item.PrePreMonth_InDataset.cc,
            period: getNextPeriod( props.selectedMonthYear ),
            orgUnit: props.selectedFacility,
            value: item.PreMonth_InDataset.value == undefined ? 0 : item.PreMonth_InDataset.value
          };            
          newItems[idx++] = newItem;
          
          let status = ''

          mos = parseFloat(mos);

          legends.map((l, index) => {
            if (amc == 0) {
    
              status = { ...item.Legends[LEGENDS_MAP[0]], legend: LEGENDS_MAP[0] };
    
              newItem = {
                dataElement: status.eid,
                categoryOptionCombo: status.cc,
                period: props.selectedMonthYear,
                orgUnit: props.selectedFacility,
                value: 1
              };
              newItems[idx++] = newItem;
    
              Object.keys(item.Legends)
                .map((key) => {
                  if (status.legend != key) {
                    // console.log('item: ', item);
                    // console.log('status.legend: ', status.legend);
                    // console.log('key: ', key);
                    //creting dataValues 0 for others legends in the same row
                    newItem = {
                      dataElement: item.Legends[key].eid,
                      categoryOptionCombo: item.Legends[key].cc,
                      period: props.selectedMonthYear,
                      orgUnit: props.selectedFacility,
                      value: 0
                    };
                    newItems[idx++] = newItem;
                    //console.log('newItem: ', newItem);
                  }
                });
    
            }
            else if (mos >= l.startValue && mos < l.endValue) {
              console.log('index: ', index);
              console.log('mos: ', mos);
              console.log('l.startValue: ', l.startValue);
              console.log('l.endValue: ', l.endValue);
    
              console.log('LEGENDS_MAP[index]: ', LEGENDS_MAP[index]);
    
              status = { ...item.Legends[LEGENDS_MAP[index]], legend: LEGENDS_MAP[index] };
              console.log('status: ', status);
    
              // creating dataValues for exact matched legend
              newItem = {
                dataElement: status.eid,
                categoryOptionCombo: status.cc,
                period: props.selectedMonthYear,
                orgUnit: props.selectedFacility,
                value: 1
              };
              newItems[idx++] = newItem;
    
              // console.log('newItem 1: ', newItem);
    
              Object.keys(item.Legends)
                .map((key) => {
                  if (status.legend != key) {
                    // console.log('item: ', item);
                    // console.log('status.legend: ', status.legend);
                    // console.log('key: ', key);
                    //creting dataValues 0 for others legends in the same row
                    newItem = {
                      dataElement: item.Legends[key].eid,
                      categoryOptionCombo: item.Legends[key].cc,
                      period: props.selectedMonthYear,
                      orgUnit: props.selectedFacility,
                      value: 0
                    };
                    newItems[idx++] = newItem;
                    //console.log('newItem: ', newItem);
                  }
                });
    
            }
          });
        })

        return newItems;
        
    }


    const GetSortOrder = ()  => {    
      return function(a, b) {               
          if (a.startValue > b.startValue) {    
              return 1;    
          } else if (a.startValue < b.startValue) {    
              return -1;    
          }    
          return 0;    
      }    
  }
    

    const uploadAmcMos = (dataValues) => {
                      
      mutationJson.data.dataValues = dataValues;
      
      engine.mutate(mutationJson, {

        onComplete: res => {              
          props.uploadAmcMosResponse(res, AMCs, MOSs);
        },

        onError: error => {
                                  
        }

      })

    }
    
    useEffect(() => {

      getTemplateExcelElements();
        
    }, [])

    return <></>;
};

export { CalculateAmcMos }