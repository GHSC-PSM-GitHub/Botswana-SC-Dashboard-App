import React, { Component } from 'react';
import { Button } from '@dhis2/ui-core';
import Dropzone from 'react-dropzone';
import SecondStep from './SecondStep';
import FirstStep from './FirstStep';
import ImportProgressPipelineTemplate from './ImportProgressPipelineTemplate';
import StatusTemplate from './statusTemplate';
import { InsertDataValueSets, FetchDataValueSets, GetOrgUnitGroups, SetCompleteDataSetRegistrations, GetCompleteDataSetRegistrations, GetPipelineTemplateSettings } from './pipelineTemplateApi';
import XLSX from 'xlsx';
import Constants from '../../helpers/constants';
import { GetAppSettings, SetAppSettings, GetAppSettingsNew, SetAppSettingsNew, GetOptionSets } from '../Settings/settingComponentApi';
import { CalculateAmcMos } from './Calculation';
import {ExcelImportAppLogsJson} from "../../actions/auditLog";


const orgUnitsQuery = {
	orgUnitGroups: {
		resource: 'organisationUnitGroups',
		id: 'AxB3vV3yUrN',
		params: {
			fields: "organisationUnits[id,displayName]",
			paging: false
		}
	}
}

const dataSetRegistrationQuery = {
  result: {
    resource: "completeDataSetRegistrations",
    params: {
      dataSet:"",
      period:"",
      orgUnitGroup:""
    }
  }
}

const mutationDatasetRegJson = {
  resource: "completeDataSetRegistrations",
  type: "create",
  data:{
    completeDataSetRegistrations:[{
      dataSet:"",
      period:"",
      organisationUnit:"",
      completed:true
    }]}
}

const getAppSettingsQuery = {
	"dataStore": {
			"resource": `dataStore/${Constants.namespace}/${Constants.PipelineKey}`
	}
}
const getGeneralSettingsQuery = {
	"dataStore": {
			"resource": `dataStore/${Constants.namespace}/${Constants.GeneralKey}`
	}
}
const getOptionSetsQuery = {
	"options": {
	  "resource": "optionSets",
	  "id": "",
	  "params":{
		  "fields": "id, displayName, options[code,displayName]"
	  }
	}
}

const pipelineTemplateQuery = {
  "dataStore": {
      "resource": `dataStore/${Constants.namespace}/${Constants.PipelineTemplateKey}`
  }
}

let today = new Date();
let date = today.getFullYear() + '-' + (String(today.getMonth() + 1)).padStart(2, '0') + '-' + (String(today.getDate())).padStart(2, '0');
const mutationExcelImportAppLogsJson = {
  resource: "dataStore/Excel-Import-App-Logs/" + date,
  type: "create",
  data: [],
};

class ImportPipelineTemplate extends Component {
  constructor( props ) {
		super( props );
		this.state = {
      defaultMonth: new Date().getMonth(),
      defaultYear: new Date().getFullYear(),
      getAppSettings: true,
      getOrgUnits: false,
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      loading: false,
      vTemplateData: [],
      saveJsonData: false,
      resGriedData: {},
      error: undefined,
      headingTitle: {},
      resultStatus: null,
      conflictKeyList: [],
      gridDataValues: [],
      fileName: null,
      statusBtnIcon: null,
      resInsertData: {},
      selectedFacility: null,
      selectedMonthYear: null,
      uploadedFile: null,
      orgUnits: [],
      setDataSetRegistration: false,
      dataSetRegistrations: [],
      getDataSetRegistrations: false,
      periods: [],
      masterTemplateError: false,
      conflictStatus: false,
      pipelineMutationData: {
				PipelineMasterTemplate:"",
				PipelineWorksheetName:"",
				PipelineWorksheetStartRow:"",
				PipelineOrganisationUnitGroup:"",
				PipelineDataset: "",
				PipelineLegend: ""
			},
      AMCs: [],
      MOSs: [],
      searchFacility: "",
      deleteUploadedFile: false,
      templateEmptyKeys: [],
      importTemplateLogsJson: [],
      user: this.props.user,
      getGeneralSettings: false,
      getAdjustmentOptionSets: false,
      getLossOptionSets: false,
      generalMutationData: {},
      adjustmentOptionSetsData: [],
      lossOptionSetsData: [],
      getPipelineTemplateData: false,
      afterDeleteUploadedFile: false,
      productCount: null
    }
    this.readExcel = this.readExcel.bind(this);
    this.changePanel = this.changePanel.bind(this);
    this.handleFirstStep = this.handleFirstStep.bind(this);
    this.deleteUploadedFile = this.deleteUploadedFile.bind(this);
    this.handleSecondStep = this.handleSecondStep.bind(this);
    this.generateJson = this.generateJson.bind(this);
    this.closeAlertBar = this.closeAlertBar.bind(this);
    this.resposeSaveJson = this.resposeSaveJson.bind(this);
    this.readDataFromExcel = this.readDataFromExcel.bind(this);
    this.handleChangeFacility = this.handleChangeFacility.bind(this);
    this.redirectToFirstStep = this.redirectToFirstStep.bind(this);
    this.getOrgUnitGroups = this.getOrgUnitGroups.bind(this);
    this.getCompleteDataSet = this.getCompleteDataSet.bind(this);
    this.saveDataSetRegistration = this.saveDataSetRegistration.bind(this);
    this.generatePeriods = this.generatePeriods.bind(this);
    this.setPeriods = this.setPeriods.bind(this);
    this.deleteJsonData = this.deleteJsonData.bind(this);
    this.calculateImportStatus = this.calculateImportStatus.bind(this);
    this.facilityGridData = this.facilityGridData.bind(this);
    this.getAppSettingsResponse = this.getAppSettingsResponse.bind(this);
    this.getPipelineTemplateSettings = this.getPipelineTemplateSettings.bind(this);
    this.uploadAmcMosResponse = this.uploadAmcMosResponse.bind(this);
    this.handleSearchFacility = this.handleSearchFacility.bind(this);
    this.getExcelImportAppLogsJson = this.getExcelImportAppLogsJson.bind(this);
    this.handleError = this.handleError.bind(this);
    this.getGeneralSettingsResponse = this.getGeneralSettingsResponse.bind(this);
    this.getAdjustmentOptionSetsResponse = this.getAdjustmentOptionSetsResponse.bind(this);
    this.getLossOptionSetsResponse = this.getLossOptionSetsResponse.bind(this);
	}

  componentWillMount(){
    this.generatePeriods(this.state.defaultYear, this.state.defaultMonth);
  }
  handleSearchFacility(e){
    this.setState({searchFacility: e.value.toLowerCase()});
  }

  handleError(error){
    this.setState({error});
  }

  getExcelImportAppLogsJson(called, loading, error, data){
   if(called && loading && error){
      this.setState({fourthStep: false, loading: false, error});
    }
  }

  deleteJsonData(){    
    let vTemplateData = this.state.vTemplateData.filter((item)=>{
      if(!["Pipelineoratory Monthly Logistics Reporting Form", "Name of Facility:", "Product Code"].includes(item["__EMPTY"]) && item["__EMPTY"]){
        return item
      }
    })
    let columnList = []
    if(vTemplateData && vTemplateData.length>0){
      columnList = Object.keys(vTemplateData[0]);
    }

    let dataValues = []
    vTemplateData.map((logTemplate)=>{
      columnList.map((col)=>{
        if(logTemplate[col] && logTemplate[col].toString().split('-').length > 1){
          if(col == "__EMPTY_16"){
            dataValues.push({
              "dataElement": logTemplate[col].split('-')[0],
              "categoryOptionCombo": logTemplate[col].split('-')[1],
              "value": 0
            })
          }else{
            dataValues.push({
              "dataElement": logTemplate[col].split('-')[0],
              "categoryOptionCombo": logTemplate[col].split('-')[1],
              "deleted": true
            })
          }
        }
      })
    })

    let mutation = {
      "resource": "dataValueSets",
      "type": "create",
      "data": {
        "period": this.state.selectedMonthYear,
        "orgUnit": this.state.selectedFacility,
        "dataValues": dataValues
      }
    }
    
    return mutation
  }

  facilityGridData(){
    let searchFacility = this.state.searchFacility
    let orgUnits =  this.state.orgUnits.filter((orgUnit)=>{
      if(orgUnit.id !='default' && orgUnit.displayName.toLowerCase().includes(searchFacility)){
        return orgUnit
      }
    })
    let dataSetRegistrations = this.state.dataSetRegistrations;    
    let GridData = orgUnits.map((orgUnit)=>{
      let newOrgUnit = {
        period: "",
        dataSet: "",
        organisationUnit: "",
        attributeOptionCombo: "",
        date: "",
        storedBy: "",
        completed: false,
        id: orgUnit.id,
        displayName: orgUnit.displayName,
      }

      dataSetRegistrations.map((dataSet)=>{
         if(orgUnit.id == dataSet.organisationUnit){
            newOrgUnit["period"] = dataSet.period
            newOrgUnit["dataSet"] = dataSet.dataSet
            newOrgUnit["organisationUnit"] = dataSet.organisationUnit
            newOrgUnit["attributeOptionCombo"] = dataSet.attributeOptionCombo
            newOrgUnit["date"] = dataSet.date
            newOrgUnit["storedBy"] = dataSet.storedBy
            newOrgUnit["completed"] = dataSet.completed
         }
      })
      return newOrgUnit
    })
    return GridData
  }

  calculateImportStatus(){
    if(this.state.orgUnits.length>1){
      let facilityCount = this.state.orgUnits.filter((orgUnit)=>orgUnit.id !='default').length
      let importStatusCount = 0
      if(this.state.dataSetRegistrations && this.state.dataSetRegistrations.length){
        importStatusCount = this.state.dataSetRegistrations.filter((dataSet)=> dataSet.completed === true).length
      }
      let percentage = 0
      try{
        percentage = ((importStatusCount/facilityCount)*100).toFixed(1)
      }catch{
        percentage = 0
      }
      return percentage+"% ("+importStatusCount+"/"+facilityCount+ " Facilities)"
    }
  }

  getOrgUnitGroups(res){
    res.unshift({id: "default", displayName: "Select Pipeline Organisation Unit"})
    this.setState({
      getOrgUnits: false,
      orgUnits:res
    });
  }

  redirectToFirstStep(){
    this.setState({
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      resultStatus: null,
      fileName: null,
      selectedFacility: this.state.pipelineMutationData.PipelineOrganisationUnitGroup,
      uploadedFile: null,
      getOrgUnits: true,
      getDataSetRegistrations: true,
      dataSetRegistrations: [],
      AMCs: [],
      MOSs: []
    })
  }

  handleFirstStep(selectedOrgUnit){
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      secondStep:true,
      selectedFacility: selectedOrgUnit.id
    })
  }
  deleteUploadedFile(selectedOrgUnit){
    
    this.setState({
      loading: true,
      getDataSetRegistrations: true,
      // deleteUploadedFile: true,
      afterDeleteUploadedFile: true,
      selectedFacility: selectedOrgUnit.id
    })
  }

  handleSecondStep(){
    if(this.state.selectedFacility == "default"){
      let error = "Please select a facility"
      this.setState({error});
      return true
    } 
    if(this.state.uploadedFile == null){
      let error = "Please upload the Excel file you want to import"
      this.setState({error});
      return true
    }
    this.readDataFromExcel()
    this.setState({
      loading: true
    })
  }

  handleChangeFacility(e, name){
    if(name=="selectFacility"){
      this.setState({selectedFacility: e.selected, error: null});
    }else{
      this.setState({
        selectedMonthYear: e.selected,
        error: null,
        getDataSetRegistrations: true,
        dataSetRegistrations: []
      });
    }
    
  }
  resposeSaveJson(called, loading, error){
    if(loading && called && error){
      this.setState({error});
    }
  }

  saveDataSetRegistration(response){
    this.setState({
      getDataSetRegistrations: true,
      setDataSetRegistration: false,
      deleteUploadedFile: false,
      afterDeleteUploadedFile: false,
      loading: false
    })
  }

  getCompleteDataSet(response){
    this.setState({getDataSetRegistrations: false});
    if(response && response.result && response.result.completeDataSetRegistrations){
      this.setState({dataSetRegistrations: response.result.completeDataSetRegistrations});
    }
  }

  closeAlertBar(){
    this.setState({error: null});
  }

  validate(){
    let flag = true
    let error = null

    if(this.state.uploadedFile == null){
      flag = false
      error = "Please upload the Excel file you want to import"
    }

    if(this.state.selectedFacility == "default"){
      flag = false
      error = "Please select a facility"
    }
    if(flag == false){
      this.setState({error});
    }
    return flag;
  }

  validateFirstStep(){
    let flag = true
    if(this.state.masterTemplateError){
      this.setState({error: "Template file "+this.state.pipelineMutationData.PipelineMasterTemplate+" does not exist"});
      flag = false
    }
    return flag;
  }

  changePanel(){
    if (this.validate()==false) {
      return true
    }
    if (this.state.secondStep) {
      this.setState({
        secondStep: !this.state.secondStep,
        items: [],
        resultStatus: null,
        fileName: null,
        selectedFacility: this.state.pipelineMutationData.PipelineOrganisationUnitGroup,
        selectedMonthYear: null,
        uploadedFile: null
      });
    }else{
      this.readDataFromExcel()
      this.setState({
        loading: true
      });
    }
  }

  readExcel(file){
    this.setState({
      uploadedFile: file,
      fileName: file.name,
      error: null
    });
  }
  readDataFromExcel(){
    const promise = new Promise((resolve, reject) => {
      let file = this.state.uploadedFile;
      let selectedMonthYear = this.state.selectedMonthYear;
      const fileReader = new FileReader();
      fileReader.readAsArrayBuffer(file);
      let months = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"]

      let year = selectedMonthYear.substring(0, 4); 
      let workSheetFormat = this.state.pipelineMutationData.PipelineWorksheetName
      var yCount = 0;      
      for (var position = 0; position < workSheetFormat.length; position++) 
      {
        if ((workSheetFormat.charAt(position)).toUpperCase() == 'Y')
          {
          yCount += 1;
          }
      }
      if(yCount!=4){
        year = year.substring(2)
      }

      var mCount = 0;
      for (var position = 0; position < workSheetFormat.length; position++) 
      {
        if ((workSheetFormat.charAt(position)).toUpperCase() == 'M')
          {
          mCount += 1;
          }
      }
      let monthName = (months[parseInt(selectedMonthYear.substring(4, 6))-1]).substring(0,mCount)
      let sheetName = workSheetFormat.replace('{MMM}',monthName).replace('{MM}',monthName).replace('{YYYY}',year).replace('{YY}',year).toUpperCase();
      let _this = this;      
      fileReader.onload = (e) => {
        const bufferArray = e.target.result;
        let wb = null
        let sheetNames = null
        try{
          wb = XLSX.read(bufferArray, { type: "buffer" });
        }catch(error){
          this.setState({
            error: "Password protected files are not allowed",
            loading: false
          })
        }
        if(wb){
          sheetNames = wb.SheetNames.map((sheet)=> sheet.toUpperCase())
        }
        let wsname = null
        if(sheetName && sheetNames && sheetNames.indexOf(sheetName) != -1){
          wsname = wb.SheetNames[sheetNames.indexOf(sheetName)]          
          const ws = wb.Sheets[wsname];
          const data = XLSX.utils.sheet_to_json(ws, {defval: "" });                    
          resolve(data);
        }else{
          this.setState({
            error: "File does not contain "+sheetName+" worksheet. Unable to proceed",
            loading: false
          });
        }
      };

      fileReader.onerror = (error) => {
        reject(error);
      };
    });

    promise.then((items) => {
      if (items.length==0) {
        this.setState({error: "Data not available in file", loading: false});
        return true
      }

      this.setState({
        items
      })      
      this.generateJson(items);
    });
  }

  generateJson(items){
    let dataValues = []
    let objectKeys = Object.keys(items[0]);
    let monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    let columnMonths = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec", "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]

    items = items.map((item)=> {
      let flag = false
      let newItem = {}
      objectKeys.map((key, index)=>{
        if(index<3){
          newItem[key] = item[key]
        }
        if(key && key.split("-").length==2 && key.split("-")[1]){
          let keyName = key.split("-")[1]
          if(columnMonths.includes(keyName.toLowerCase())){
            newItem[key] = item[key]
          }
        }
      })
      return newItem
    })
    let gridDataValues = items;
    this.state.vTemplateData.map((templateItem)=>{
      items.map((item)=>{
        if((templateItem["Product Code"] == item["Product Code"]) && (templateItem["Supply Plan parameters"] == item["Supply Plan parameters"])){
          let months = Object.keys(item).filter((month) => !["Product Code", "Product Description", "Supply Plan parameters"].includes(month))
          months.map((month)=>{
             let selectedMonth =  monthNames.filter((monthName) => (month.toLowerCase()).includes(monthName.toLowerCase()))[0]
             let monthValue = ""
             if(monthNames.indexOf(selectedMonth) != -1){
               monthValue = String(monthNames.indexOf(selectedMonth)+1).padStart(2, '0')
             }
             let currentyear = new Date().getFullYear().toString()
             let yearValue = currentyear.substring(0, 2) + String(parseInt(month.match(/\d+/),10))
             
             if((item[month] && item[month] != "") || (item[month] == "0")){
               if(item[month] == "0"){
                item[month] = "0.0"
               }
              dataValues.push({
                "period": yearValue+monthValue,
                "dataElement": templateItem.UID.split('-')[0],
                "categoryOptionCombo": templateItem.UID.split('-')[1],
                "value": item[month]
              })
             } else {               
              dataValues.push({
                "period": yearValue+monthValue,
                "dataElement": templateItem.UID.split('-')[0],
                "categoryOptionCombo": templateItem.UID.split('-')[1],
                "deleted": true
              })
             }
          })
        }
      })
    })
    if(dataValues.length>0 && gridDataValues.length>0){
      let vJsonData = {
        "resource": "dataValueSets",
        "type": "create",
        "data": {
          "orgUnit": this.state.selectedFacility,
          "dataValues": dataValues
        }
      }
      let productCodes = [];
      gridDataValues.map((item)=>{
        if(!productCodes.includes(item["Product Code"])){
            productCodes.push(item["Product Code"])
        }
      })

      this.setState({
        gridDataValues,
        productCount: productCodes.length,
        vJsonData,
        saveJsonData: true,
      });
    }else{
      this.setState({error: "Template file key's didn't match with uploaded file", loading: false});
    }
  }

  generatePeriods(defaultYear, defaultMonth){
    if (defaultMonth == 0) {
      defaultYear = defaultYear-1;
      defaultMonth=12;
    }
    let months = Constants.MONTH_NAME
    let periods = [];
    let currentyear = new Date().getFullYear();
    if((currentyear !== defaultYear)){
      defaultMonth = 12;
    }
    for(let i = (defaultMonth-1); i >= 0; i-- ){
      let option = {}
      option["name"] = months[i] +" "+ defaultYear
      option["id"] = defaultYear+String((i+1)).padStart(2, '0')
      periods.push(option);
    }
    if(this.state.deleteUploadedFile){
      this.setState({
        periods,
        dataSetRegistrations: []
      })
    }else{
      this.setState({
        periods,
        selectedMonthYear: periods[0].id,
        dataSetRegistrations: []
      })
    }
    
  }

  setPeriods(year){
    if(year=="previous"){
      this.setState({
        defaultYear: this.state.defaultYear - 1,
        getDataSetRegistrations: true,
      });
      this.generatePeriods(this.state.defaultYear - 1, this.state.defaultMonth)
    }else{
      let currentyear = new Date().getFullYear();
      if(currentyear !== this.state.defaultYear){
        this.setState({
          defaultYear: this.state.defaultYear + 1,
          getDataSetRegistrations: true,
        });
        this.generatePeriods(this.state.defaultYear + 1, this.state.defaultMonth)
      }
    }
  }

  getAdjustmentOptionSetsResponse(data){
    if(data && data.options){
      this.setState({
        getAdjustmentOptionSets: false,
        adjustmentOptionSetsData: data.options.options,
        getLossOptionSets: true
      })
    }
  }

  getLossOptionSetsResponse(data){
    if(data && data.options){
      this.setState({
        getLossOptionSets: false,
        lossOptionSetsData: data.options.options,
        getOrgUnits: true,
        getDataSetRegistrations: true,
      })
    }
  }

  getGeneralSettingsResponse(data){
    if(data && data.dataStore){
      this.setState({
        generalMutationData: data.dataStore,
        getGeneralSettings: false,
        // getAdjustmentOptionSets: true
        getPipelineTemplateData: true
      })
    }
  }

  getAppSettingsResponse(data){
    if( data && data.dataStore){
      this.setState({
        pipelineMutationData: data.dataStore,
        selectedFacility: data.dataStore.PipelineOrganisationUnitGroup,
        getAppSettings: false,
        getGeneralSettings: true
      })
    }
  }
  
  getPipelineTemplateSettings(data){    
    if( data && data.dataStore){
      this.setState({
        vTemplateData: data.dataStore,
        getAdjustmentOptionSets: true,
        getPipelineTemplateData: false
      })
    }else{
      this.setState({
        loading:false,
        error: "Pipeline Template JSON missing!"
      })
    }
  }

  uploadAmcMosResponse = (response, AMCs, MOSs) => {
    if( response.conflicts.length > 0 ){
        alert('Uploading AMC and MOS has coflicts: ' + JSON.stringify(response.conflicts));
        this.setState({loading: false, error: "Uploading AMC and MOS has coflicts"});
    }else{
      this.setState({
        fourthStep: true,
        thirdStep: false,
        loading: false,
        AMCs,
        MOSs
      });
    }
  }

  getNextPeriod = (ym) => {        
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    if ( month == 12 ){
      month = 1;
      year = year + 1;
    } else {
      month = month + 1;
    }

    ym = year + month.toString().padStart(2, '0');
    
    return ym;

  }

  render() {
    return (
      <>
        {
          this.state.getAppSettings &&
          <GetAppSettingsNew query = {getAppSettingsQuery} onResponse = {this.getAppSettingsResponse}/>
        }
        {
          this.state.getGeneralSettings &&
          <GetAppSettingsNew query = {getGeneralSettingsQuery} onResponse = {this.getGeneralSettingsResponse}/>
        }
        {
          this.state.getPipelineTemplateData &&
          <GetPipelineTemplateSettings query = {pipelineTemplateQuery} onResponse = {this.getPipelineTemplateSettings}
          />
        }
        {
          this.state.getAdjustmentOptionSets &&
          <GetOptionSets
            query = {getOptionSetsQuery}
            optionSetId = {this.state.generalMutationData.AdjustmentOptionSet}
            onResponse = {this.getAdjustmentOptionSetsResponse}
          />
        }
        {
          this.state.getLossOptionSets &&
          <GetOptionSets
            query = {getOptionSetsQuery}
            optionSetId = {this.state.generalMutationData.LossOptionSet}
            onResponse = {this.getLossOptionSetsResponse}
          />
        }
        {
          this.state.fourthStep &&
          <ExcelImportAppLogsJson
            onComplete={result => {
              this.setState({
                fourthStep: false,
                fifthStep: true,
                loading: false
              })
            }}
            query = {mutationExcelImportAppLogsJson}
            importTemplateLogsJson = {this.state.importTemplateLogsJson}
            onResponse = {this.getExcelImportAppLogsJson}
          />
        }
        {
          this.state.saveJsonData && <InsertDataValueSets
            onComplete={result => {
              
              let conflictKeyList = []
              let statusBtnIcon = null
              let conflictStatus = false
              if(result.conflicts && result.conflicts.length>0){
                conflictStatus = true
              }
              result.conflicts.map((conflict)=>{
                if(conflict.value){
                  conflictKeyList.push(conflict.object.trim());
                }
              })
              let selectedFacility = this.state.orgUnits.find(item => item.id === this.state.selectedFacility)
              let importTemplateLogsJson = this.props.importTemplateLogs || []
              importTemplateLogsJson.push({
                User: this.state.user.displayName,
                DateTime: new Date().toISOString(),
                FileName:this.state.fileName,
                FacilityName: selectedFacility ? selectedFacility.displayName : '',
                MonthYear: this.state.selectedMonthYear,
                Status: {
                  Message: conflictKeyList.length==0 ? "Import process completed successfully" : "Import process completed with error",
                  conflicts: result.conflicts,
                },
              })
              this.setState({
                importTemplateLogsJson,
                conflictStatus,
                statusBtnIcon,
                conflictKeyList,
                saveJsonData: false,
                resultStatus: result.status,
                resInsertData: result,
                firstStep: false,
                secondStep: false,
                thirdStep: true,
                setDataSetRegistration: true
              })
            }}
            vJsonData = { this.state.vJsonData }
            resposeSaveJson = {this.resposeSaveJson}
          />
        }
        {
          this.state.deleteUploadedFile && <InsertDataValueSets
            onComplete={result => {
              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: false,
                afterDeleteUploadedFile: true,
              })
            }}
            vJsonData = { this.deleteJsonData()}
            resposeSaveJson = {this.resposeSaveJson}
          />
        }
        {
          this.state.afterDeleteUploadedFile &&
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson = {mutationDatasetRegJson}
            orgUnitId = {this.state.selectedFacility}
            period = {this.state.selectedMonthYear}
            completed = {false}
            pipelineMutationData = {this.state.pipelineMutationData}
            saveDataSetRegistration = {this.saveDataSetRegistration}
          />
        }
        {
          this.state.firstStep &&
          <FirstStep
            deleteUploadedFile = {this.deleteUploadedFile}
            searchFacility = {this.state.searchFacility}
            handleSearchFacility = {this.handleSearchFacility}
            handleFirstStep = {this.handleFirstStep}
            readExcel={this.readExcel}
            loading = {this.state.loading}
            error = {this.state.error}
            closeAlertBar = {this.closeAlertBar}
            handleChangeFacility = {this.handleChangeFacility}
            selectedFacility = {this.state.selectedFacility}
            selectedMonthYear = {this.state.selectedMonthYear}
            orgUnits = {this.state.orgUnits}
            dataSetRegistrations = {this.state.dataSetRegistrations}
            defaultMonth = {this.state.defaultMonth}
            defaultYear = {this.state.defaultYear}
            periods = {this.state.periods}
            setPeriods = {this.setPeriods}
            calculateImportStatus = {this.calculateImportStatus}
            facilityGridData = {this.facilityGridData}
          />
        }
        {
          this.state.firstStep && this.state.getOrgUnits &&
          <GetOrgUnitGroups
            response = {this.getOrgUnitGroups}
            orgUnitsQuery = {orgUnitsQuery}
            pipelineMutationData = {this.state.pipelineMutationData}
            selectedFacility = {this.state.selectedFacility}
            handleError = {this.handleError}
            stateError = {this.state.error}
          />
        }
        {
          this.state.firstStep && this.state.getDataSetRegistrations &&
          <GetCompleteDataSetRegistrations
            dataSetRegistrationQuery = {dataSetRegistrationQuery}
            selectedMonthYear = {this.state.selectedMonthYear}
            pipelineMutationData = {this.state.pipelineMutationData}
            response = {this.getCompleteDataSet}
            handleError = {this.handleError}
            stateError = {this.state.error}
          />
        }
        {
          this.state.setDataSetRegistration &&
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson = {mutationDatasetRegJson}
            orgUnitId = {this.state.selectedFacility}
            period = {this.state.selectedMonthYear}
            completed = {true}
            pipelineMutationData = {this.state.pipelineMutationData}
            saveDataSetRegistration = {this.saveDataSetRegistration}
          />
        }
        {
          (this.state.secondStep || this.state.thirdStep || this.state.fourthStep) &&
          <SecondStep
            handleSecondStep = {this.handleSecondStep}            
            readExcel={this.readExcel}
            loading = {this.state.loading}
            error = {this.state.error}
            closeAlertBar = {this.closeAlertBar}
            handleChangeFacility = {this.handleChangeFacility}
            selectedFacility = {this.state.selectedFacility}
            selectedMonthYear = {this.state.selectedMonthYear}
            orgUnits = {this.state.orgUnits}
            defaultMonth = {this.state.defaultMonth}
            defaultYear = {this.state.defaultYear}
            periods = {this.state.periods}
            setPeriods = {this.setPeriods}
          />
        }
        {
          this.state.thirdStep && this.state.resultStatus && <CalculateAmcMos 
          items = { this.state.items } 
          vTemplateData = { this.state.vTemplateData }
          selectedFacility = { this.state.selectedFacility }
          selectedMonthYear = { this.state.selectedMonthYear }
          pipelineMutationData = {this.state.pipelineMutationData}
          uploadAmcMosResponse = { this.uploadAmcMosResponse }
          />
        }
        {
          this.state.fifthStep && <ImportProgressPipelineTemplate
            changePanel = {this.changePanel}
            items = {this.state.items}
            vJsonData = {this.state.vJsonData}
            loading = {this.state.loading}
            headingTitle = {this.state.headingTitle} 
            resInsertData = {this.state.resInsertData}
            resultStatus = {this.state.resultStatus}
            conflictStatus = {this.state.conflictStatus}
            conflictKeyList = {this.state.conflictKeyList}
            gridDataValues = {this.state.gridDataValues}
            productCount = {this.state.productCount}
            templateEmptyKeys = {this.state.templateEmptyKeys}
            fileName = {this.state.fileName}
            statusBtnIcon = {this.state.statusBtnIcon}
            redirectToFirstStep = {this.redirectToFirstStep}
            AMCs = {this.state.AMCs}
            MOSs = {this.state.MOSs}
          />
        }
        
      </>
    );
  }
}

export default ImportPipelineTemplate;
