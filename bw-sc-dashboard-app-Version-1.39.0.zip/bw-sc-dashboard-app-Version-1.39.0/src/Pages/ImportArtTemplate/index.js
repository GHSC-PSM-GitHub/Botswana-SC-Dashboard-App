import React, { Component } from "react";
import { Button } from "@dhis2/ui-core";
import Dropzone from "react-dropzone";
import SecondStep from "./SecondStep";
import FirstStep from "./FirstStep";
import ImportProgressArtTemplate from "./ImportProgressArtTemplate";
import ShowDuplicateProducts from "./ShowDuplicateProducts";
import StatusTemplate from "./statusTemplate";
import {
  InsertDataValueSets,
  FetchDataValueSets,
  GetOrgUnitGroups,
  SetCompleteDataSetRegistrations,
  GetCompleteDataSetRegistrations,
  GetArtTemplateSettings,
} from "./artTemplateApi";
import XLSX from "xlsx";
import Constants from "../../helpers/constants";
import {
  GetAppSettings,
  SetAppSettings,
  GetAppSettingsNew,
  SetAppSettingsNew,
  GetOptionSets,
} from "../Settings/settingComponentApi";
import { CalculateAmcMos } from "./Calculation";
import { ExcelImportAppLogsJson } from "../../actions/auditLog";
import ArvViewEntryEdit from "./ArvViewEntryEdit";

let lastSelectedOrgUnit;

const orgUnitsQuery = {
  orgUnitGroups: {
    resource: "organisationUnitGroups",
    id: "AxB3vV3yUrN",
    params: {
      fields: "organisationUnits[id,displayName,attributeValues]",
      paging: false,
    },
  },
};

const dataSetRegistrationQuery = {
  result: {
    resource: "completeDataSetRegistrations",
    params: {
      dataSet: "",
      period: "",
      orgUnitGroup: "",
    },
  },
};

const mutationDatasetRegJson = {
  resource: "completeDataSetRegistrations",
  type: "create",
  data: {
    completeDataSetRegistrations: [
      {
        dataSet: "",
        period: "",
        organisationUnit: "",
        completed: true,
      },
    ],
  },
};

const getAppSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.ArtKey}`,
  },
};

const getGeneralSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.GeneralKey}`,
  },
};

const getOptionSetsQuery = {
  options: {
    resource: "optionSets",
    id: "",
    params: {
      fields: "id, displayName, options[code,displayName]",
    },
  },
};

const artLogTemplateQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.ArtLogTemplateKey}`,
  },
};

const artRegTemplateQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.ArtRegTemplateKey}`,
  },
};

const getCmsVenTemplateSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.CmsVenTemplateKey}`,
  },
};

const regColumnList = [
  "Number of Patients as of Last Month",
  "No. of Attritions from the Last Month",
  "Number of Patients in the Current Month",
  "No. of New Patients in the Current Month",
];

let today = new Date();
let date =
  today.getFullYear() +
  "-" +
  String(today.getMonth() + 1).padStart(2, "0") +
  "-" +
  String(today.getDate()).padStart(2, "0");
const mutationExcelImportAppLogsJson = {
  resource: "dataStore/Excel-Import-App-Logs/" + date,
  type: "create",
  data: [],
};

class ImportArtTemplate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultMonth: new Date().getMonth(),
      defaultYear: new Date().getFullYear(),
      getAppSettings: true,
      getOrgUnits: false,
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      showArvViewEntryEdit: false,
      logItems: [],
      regItems: [],
      loading: false,
      logTemplateData: [],
      regTemplateData: [],
      saveJsonData: false,
      resGriedData: {},
      error: undefined,
      headingTitle: {},
      resultStatus: null,
      conflictKeyList: [],
      logGridDataValues: [],
      missingProducts: [],
      duplicateProducts: [],
      blankOrNegativeRocords: [],
      fileName: null,
      statusBtnIcon: null,
      resInsertData: {},
      selectedFacility: null,
      selectedMonthYear: null,
      uploadedFile: null,
      orgUnits: [],
      setDataSetRegistration: false,
      dataSetRegistrations: [],
      getDataSetRegistrations: false,
      periods: [],
      masterTemplateError: false,
      conflictStatus: false,
      artMutationData: {
        ARTMasterTemplate: "",
        LMISWorksheetName: "",
        LMISWorksheetStartRow: "",
        RegimenWorksheetName: "",
        RegimenWorksheetStartRow: "",
        ARTOrganisationUnitGroup: "",
        ARTDataset: "",
        ARTLegend: "",
      },
      AMCs: [],
      MOSs: [],
      searchFacility: "",
      deleteUploadedFile: false,
      regTemplateEmptyKeys: [],
      importTemplateLogsJson: [],
      user: this.props.user,
      logJsonData: {},
      regSaveJsonData: false,
      getGeneralSettings: false,
      generalMutationData: {},
      getOptionSets: false,
      optionSetsData: [],
      getArtLogTemplateData: false,
      getArtRegTemplateData: false,
      afterDeleteUploadedFile: false,
      showDuplicateProducts: false,
      gridHeadingTitle: null,
      getCmsVenTemplateSettings: false,
      vTemplateCmsVenData: [],
      vTemplateCmsVenDataList: [],
    };
    this.readExcel = this.readExcel.bind(this);
    this.changePanel = this.changePanel.bind(this);
    this.handleFirstStep = this.handleFirstStep.bind(this);
    this.deleteUploadedFile = this.deleteUploadedFile.bind(this);
    this.handleSecondStep = this.handleSecondStep.bind(this);
    this.generateJson = this.generateJson.bind(this);
    this.closeAlertBar = this.closeAlertBar.bind(this);
    this.resposeSaveJson = this.resposeSaveJson.bind(this);
    this.readDataFromExcel = this.readDataFromExcel.bind(this);
    this.handleChangeFacility = this.handleChangeFacility.bind(this);
    this.redirectToFirstStep = this.redirectToFirstStep.bind(this);
    this.getOrgUnitGroups = this.getOrgUnitGroups.bind(this);
    this.getCompleteDataSet = this.getCompleteDataSet.bind(this);
    this.saveDataSetRegistration = this.saveDataSetRegistration.bind(this);
    this.generatePeriods = this.generatePeriods.bind(this);
    this.setPeriods = this.setPeriods.bind(this);
    this.calculateImportStatus = this.calculateImportStatus.bind(this);
    this.facilityGridData = this.facilityGridData.bind(this);
    this.getAppSettingsResponse = this.getAppSettingsResponse.bind(this);
    this.getGeneralSettingsResponse =
      this.getGeneralSettingsResponse.bind(this);
    this.uploadAmcMosResponse = this.uploadAmcMosResponse.bind(this);
    this.handleSearchFacility = this.handleSearchFacility.bind(this);
    this.getExcelImportAppLogsJson = this.getExcelImportAppLogsJson.bind(this);
    this.handleError = this.handleError.bind(this);
    this.getNextPeriod = this.getNextPeriod.bind(this);
    this.getOptionSetsResponse = this.getOptionSetsResponse.bind(this);
    this.getArtLogTemplateSettings = this.getArtLogTemplateSettings.bind(this);
    this.getArtRegTemplateSettings = this.getArtRegTemplateSettings.bind(this);
    this.deleteJsonData = this.deleteJsonData.bind(this);
    this.getCmsVenTemplateSettingsResponse =
      this.getCmsVenTemplateSettingsResponse.bind(this);
    this.entryOrEdit = this.entryOrEdit.bind(this);
    this.backToFacilitylist = this.backToFacilitylist.bind(this);
    this.checkColumnsValue = this.checkColumnsValue.bind(this);
  }

  componentWillMount() {
    this.generatePeriods(this.state.defaultYear, this.state.defaultMonth);
  }
  handleSearchFacility(e) {
    this.setState({ searchFacility: e.value.toLowerCase() });
  }

  handleError(error) {
    this.setState({ error });
  }

  getExcelImportAppLogsJson(called, loading, error, data) {
    if (called && loading && error) {
      this.setState({ fourthStep: false, loading: false, error });
    }
  }

  deleteJsonData() {
    //console.log('deleteJsonData regTemplateData: ', this.state.regTemplateData);

    let logDataValues = [];

    if (
      this.state.logTemplateData &&
      this.state.logTemplateData[2] &&
      this.state.logTemplateData[2].__EMPTY_8 == "Date Received"
    ) {
      let receiveDateKey = this.state.logTemplateData[2].__EMPTY_9;
      let reportTimelyStatus = this.state.logTemplateData[2].__EMPTY_21;
      let reportLateStatus = this.state.logTemplateData[2].__EMPTY_22;

      if (receiveDateKey) {
        logDataValues.push({
          dataElement: receiveDateKey.split("-")[0],
          categoryOptionCombo: receiveDateKey.split("-")[1],
          deleted: true,
        });
      }

      if (reportTimelyStatus) {
        logDataValues.push({
          dataElement: reportTimelyStatus.split("-")[0],
          categoryOptionCombo: reportTimelyStatus.split("-")[1],
          deleted: true,
        });
      }

      if (reportLateStatus) {
        logDataValues.push({
          dataElement: reportLateStatus.split("-")[0],
          categoryOptionCombo: reportLateStatus.split("-")[1],
          deleted: true,
        });
      }
    }

    if (
      this.state.logTemplateData &&
      this.state.logTemplateData[2] &&
      this.state.logTemplateData[2].__EMPTY_23 &&
      this.state.logTemplateData[2].__EMPTY_24 &&
      this.state.logTemplateData[2].__EMPTY_25 &&
      this.state.logTemplateData[2].__EMPTY_26
    ) {
      let totalLossKey = this.state.logTemplateData[2].__EMPTY_23;
      let totalBalanceKey = this.state.logTemplateData[2].__EMPTY_24;
      let countAllProductKey = this.state.logTemplateData[2].__EMPTY_25;
      let countNonZeroKey = this.state.logTemplateData[2].__EMPTY_26;

      logDataValues.push({
        dataElement: totalLossKey.split("-")[0],
        categoryOptionCombo: totalLossKey.split("-")[1],
        deleted: true,
      });
      logDataValues.push({
        dataElement: totalBalanceKey.split("-")[0],
        categoryOptionCombo: totalBalanceKey.split("-")[1],
        deleted: true,
      });
      logDataValues.push({
        dataElement: countAllProductKey.split("-")[0],
        categoryOptionCombo: countAllProductKey.split("-")[1],
        deleted: true,
      });
      logDataValues.push({
        dataElement: countNonZeroKey.split("-")[0],
        categoryOptionCombo: countNonZeroKey.split("-")[1],
        deleted: true,
      });
    }

    let logTemplateData = this.state.logTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );
    let columnList = [];
    if (logTemplateData && logTemplateData.length > 0) {
      columnList = Object.keys(logTemplateData[0]);
    }

    logTemplateData.map((logTemplate) => {
      columnList.map((col) => {
        if (
          logTemplate[col] &&
          logTemplate[col].toString().split("-").length > 1
        ) {
          if (col == "__EMPTY_17") {
            logDataValues.push({
              dataElement: logTemplate[col].split("-")[0],
              categoryOptionCombo: logTemplate[col].split("-")[1],
              value: 0,
            });
          } else {
            if (
              !(
                col === "__EMPTY_23" ||
                col === "__EMPTY_24" ||
                col === "__EMPTY_32" ||
                col === "__EMPTY_33"
              )
            ) {
              logDataValues.push({
                dataElement: logTemplate[col].split("-")[0],
                categoryOptionCombo: logTemplate[col].split("-")[1],
                deleted: true,
              });
            }
          }
        }
      });
    });

    // Deleting Regimes when click on Delete button
    const lenOfUID = 23;
    this.state.regTemplateData.forEach((o) => {
      let de_co = "";
      let de = "";
      let co = "";

      if (
        o["Number of Patients as of Last Month"].length === lenOfUID &&
        o["No. of New Patients in the Current Month"].length === lenOfUID &&
        o["No. of Attritions from the Last Month"].length === lenOfUID &&
        o["Number of Patients in the Current Month"].length === lenOfUID
      ) {
        de_co = o["Number of Patients as of Last Month"];
        de = de_co.split("-")[0];
        co = de_co.split("-")[1];
        logDataValues.push({
          dataElement: de,
          categoryOptionCombo: co,
          deleted: true,
        });

        de_co = o["No. of New Patients in the Current Month"];
        de = de_co.split("-")[0];
        co = de_co.split("-")[1];
        logDataValues.push({
          dataElement: de,
          categoryOptionCombo: co,
          deleted: true,
        });

        de_co = o["No. of Attritions from the Last Month"];
        de = de_co.split("-")[0];
        co = de_co.split("-")[1];
        logDataValues.push({
          dataElement: de,
          categoryOptionCombo: co,
          deleted: true,
        });

        de_co = o["Number of Patients in the Current Month"];
        de = de_co.split("-")[0];
        co = de_co.split("-")[1];
        logDataValues.push({
          dataElement: de,
          categoryOptionCombo: co,
          deleted: true,
        });
      }
    });
    // ==END==

    let mutation = {
      resource: "dataValueSets",
      type: "create",
      data: {
        period: this.state.selectedMonthYear,
        orgUnit: this.state.selectedFacility,
        dataValues: logDataValues,
      },
    };

    return mutation;
  }

  facilityGridData() {
    let searchFacility = this.state.searchFacility;
    let orgUnits = this.state.orgUnits.filter((orgUnit) => {
      if (
        orgUnit.id != "default" &&
        orgUnit.displayName.toLowerCase().includes(searchFacility)
      ) {
        return orgUnit;
      }
    });
    let dataSetRegistrations = this.state.dataSetRegistrations;

    let GridData = orgUnits.map((orgUnit) => {
      // Checking user has permission to enter data using dhis2 app
      let allowDataEntryInApp = false;
      if (
        orgUnit &&
        orgUnit.attributeValues &&
        orgUnit.attributeValues.length > 0
      ) {
        if (orgUnit.attributeValues[0].value === "true") {
          allowDataEntryInApp = true;
        }
      }

      let newOrgUnit = {
        period: "",
        dataSet: "",
        organisationUnit: "",
        attributeOptionCombo: "",
        date: "",
        storedBy: "",
        completed: false,
        id: orgUnit.id,
        displayName: orgUnit.displayName,
        allowDataEntryInApp: allowDataEntryInApp,
      };

      dataSetRegistrations.map((dataSet) => {
        if (orgUnit.id == dataSet.organisationUnit) {
          newOrgUnit["period"] = dataSet.period;
          newOrgUnit["dataSet"] = dataSet.dataSet;
          newOrgUnit["organisationUnit"] = dataSet.organisationUnit;
          newOrgUnit["attributeOptionCombo"] = dataSet.attributeOptionCombo;
          newOrgUnit["date"] = dataSet.date;
          newOrgUnit["storedBy"] = dataSet.storedBy;
          newOrgUnit["completed"] = dataSet.completed;
        }
      });
      return newOrgUnit;
    });
    return GridData;
  }

  calculateImportStatus() {
    if (this.state.orgUnits.length > 1) {
      let facilityCount = this.state.orgUnits.filter(
        (orgUnit) => orgUnit.id != "default"
      ).length;
      let importStatusCount = 0;
      if (
        this.state.dataSetRegistrations &&
        this.state.dataSetRegistrations.length
      ) {
        importStatusCount = this.state.dataSetRegistrations.filter(
          (dataSet) => dataSet.completed === true
        ).length;
      }
      let percentage = 0;
      try {
        percentage = ((importStatusCount / facilityCount) * 100).toFixed(1);
      } catch {
        percentage = 0;
      }
      return (
        percentage +
        "% (" +
        importStatusCount +
        "/" +
        facilityCount +
        " Facilities)"
      );
    }
  }

  getOrgUnitGroups(res) {
    res.unshift({ id: "default", displayName: "Select ARV Organisation Unit" });
    this.setState({
      getOrgUnits: false,
      orgUnits: res,
    });
  }

  redirectToFirstStep() {
    this.setState({
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      showArvViewEntryEdit: false,
      logItems: [],
      resultStatus: null,
      fileName: null,
      selectedFacility: this.state.artMutationData.ARTOrganisationUnitGroup,
      uploadedFile: null,
      getOrgUnits: true,
      getDataSetRegistrations: true,
      dataSetRegistrations: [],
      AMCs: [],
      MOSs: [],
      showDuplicateProducts: false,
      gridHeadingTitle: null,
      loading: false,
    });
  }

  handleFirstStep(selectedOrgUnit) {
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      secondStep: true,
      selectedFacility: selectedOrgUnit.id,
    });
  }
  deleteUploadedFile(selectedOrgUnit) {
    this.setState({
      getDataSetRegistrations: true,
      deleteUploadedFile: true,
      selectedFacility: selectedOrgUnit.id,
      loading: true,
    });
  }

  entryOrEdit(selectedOrgUnit, bCompleted) {
    console.log("selectedOrgUnit: ", selectedOrgUnit);
    lastSelectedOrgUnit = selectedOrgUnit;
    this.setState({
      firstStep: false,
      // secondStep: false,
      // thirdStep: false,
      // fourthStep: false,
      // fifthStep: false,
      showArvViewEntryEdit: true,
      loading: true,
      completed: bCompleted,
    });
  }

  backToFacilitylist(selectedOrgUnit) {
    this.setState({
      firstStep: true,
      getOrgUnits: true,
      getDataSetRegistrations: true,
      showArvViewEntryEdit: false,
      loading: false,
    });
  }

  handleSecondStep() {
    if (this.state.selectedFacility == "default") {
      let error = "Please select a facility";
      this.setState({ error });
      return true;
    }
    if (this.state.uploadedFile == null) {
      let error = "Please upload the Excel file you want to import";
      this.setState({ error });
      return true;
    }
    this.readDataFromExcel();
    this.setState({
      loading: true,
    });
  }

  handleChangeFacility(e, name) {
    if (name == "selectFacility") {
      this.setState({ selectedFacility: e.selected, error: null });
    } else {
      this.setState({
        selectedMonthYear: e.selected,
        error: null,
        getDataSetRegistrations: true,
        dataSetRegistrations: [],
      });
    }
  }
  resposeSaveJson(called, loading, error) {
    if (loading && called && error) {
      this.setState({ error });
    }
  }

  saveDataSetRegistration(response) {
    this.setState({
      getDataSetRegistrations: true,
      setDataSetRegistration: false,
      deleteUploadedFile: false,
      afterDeleteUploadedFile: false,
      loading: false,
    });
  }

  getCompleteDataSet(response) {
    this.setState({ getDataSetRegistrations: false });
    if (
      response &&
      response.result &&
      response.result.completeDataSetRegistrations
    ) {
      this.setState({
        dataSetRegistrations: response.result.completeDataSetRegistrations,
      });
    }
  }

  closeAlertBar() {
    this.setState({ error: null });
  }

  validate() {
    let flag = true;
    let error = null;

    if (this.state.uploadedFile == null) {
      flag = false;
      error = "Please upload the Excel file you want to import";
    }

    if (this.state.selectedFacility == "default") {
      flag = false;
      error = "Please select a facility";
    }
    if (flag == false) {
      this.setState({ error });
    }
    return flag;
  }

  validateFirstStep() {
    let flag = true;
    if (this.state.masterTemplateError) {
      this.setState({
        error:
          "Template file " +
          this.state.artMutationData.ARTMasterTemplate +
          " does not exist",
      });
      flag = false;
    }
    return flag;
  }

  changePanel() {
    if (this.validate() == false) {
      return true;
    }
    if (this.state.secondStep) {
      this.setState({
        secondStep: !this.state.secondStep,
        logItems: [],
        resultStatus: null,
        fileName: null,
        selectedFacility: this.state.artMutationData.ARTOrganisationUnitGroup,
        selectedMonthYear: null,
        uploadedFile: null,
      });
    } else {
      this.readDataFromExcel();
      this.setState({
        loading: true,
      });
    }
  }

  readExcel(file) {
    this.setState({
      uploadedFile: file,
      fileName: file.name,
      error: null,
    });
  }

  // findColumnValue = (sheetName, items, columnNumber, searchText) => {
  //   const columnKey = `COLUMN_${columnNumber}`;

  //   const foundItem = items.find(
  //     (item) => item.hasOwnProperty(columnKey) && item[columnKey] === searchText
  //   );

  //   if (!foundItem) {
  //     this.setState({
  //       loading: false,
  //       error: `"${searchText}" not found in column ${columnNumber} in ${sheetName}`,
  //     });
  //     return true;
  //   }

  //   return foundItem;
  // };

  // checkColumnsValue = (items, columns, tabName) => {
  //   try {
  //     columns.forEach((col) => {
  //       const { columnNumber, searchText } = col;
  //       const columnKey = `COLUMN_${columnNumber}`;

  //       const foundItem = items.find(
  //         (item) =>
  //           item.hasOwnProperty(columnKey) && item[columnKey] === searchText
  //       );

  //       if (!foundItem) {
  //         throw new Error(
  //           `"${searchText}" not found in column ${columnNumber} in ${tabName}`
  //         );
  //       }
  //     });
  //     return true; // If all checks pass
  //   } catch (error) {
  //     this.setState({
  //       loading: false,
  //       error: error.message,
  //     });
  //     return false;
  //   }
  // };

  checkColumnsValue = (items, columns, tabName) => {
    try {
      columns.forEach(({ columnText, columnNumber }) => {
        const foundItem = items.find(
          (item) =>
            item.hasOwnProperty(columnText) && item[columnText] === columnText
        );

        if (!foundItem) {
          throw new Error(
            `"${columnText}" not found in the ${columnNumber} column in in ${tabName}`
          );
        }
      });
      return true; // If all checks pass
    } catch (error) {
      this.setState({
        loading: false,
        error: error.message,
      });
      return false;
    }
  };

  readDataFromExcel() {
    const promise = new Promise((resolve, reject) => {
      let file = this.state.uploadedFile;
      let selectedMonthYear = this.state.selectedMonthYear;
      const fileReader = new FileReader();
      fileReader.readAsArrayBuffer(file);
      let months = [
        "JANUARY",
        "FEBRUARY",
        "MARCH",
        "APRIL",
        "MAY",
        "JUNE",
        "JULY",
        "AUGUST",
        "SEPTEMBER",
        "OCTOBER",
        "NOVEMBER",
        "DECEMBER",
      ];

      let LmisYear = selectedMonthYear.substring(0, 4);
      let LMISWorksheet = this.state.artMutationData.LMISWorksheetName;
      var LmisYearCount = 0;
      for (var position = 0; position < LMISWorksheet.length; position++) {
        if (LMISWorksheet.charAt(position).toUpperCase() == "Y") {
          LmisYearCount += 1;
        }
      }
      if (LmisYearCount != 4) {
        LmisYear = LmisYear.substring(2);
      }

      var LmisMonthCount = 0;
      for (var position = 0; position < LMISWorksheet.length; position++) {
        if (LMISWorksheet.charAt(position).toUpperCase() == "M") {
          LmisMonthCount += 1;
        }
      }
      let LmisMonthName = months[
        parseInt(selectedMonthYear.substring(4, 6)) - 1
      ].substring(0, LmisMonthCount);
      let logSheetName = LMISWorksheet.replace("{MMM}", LmisMonthName)
        .replace("{MM}", LmisMonthName)
        .replace("{YYYY}", LmisYear)
        .replace("{YY}", LmisYear)
        .toUpperCase();

      let RegimenYear = selectedMonthYear.substring(0, 4);
      let RegimenWorksheet = this.state.artMutationData.RegimenWorksheetName;
      var RegimenYearCount = 0;
      for (var position = 0; position < RegimenWorksheet.length; position++) {
        if (RegimenWorksheet.charAt(position).toUpperCase() == "Y") {
          RegimenYearCount += 1;
        }
      }
      if (RegimenYearCount != 4) {
        RegimenYear = RegimenYear.substring(2);
      }

      var RegimenMonthCount = 0;
      for (var position = 0; position < RegimenWorksheet.length; position++) {
        if (RegimenWorksheet.charAt(position).toUpperCase() == "M") {
          RegimenMonthCount += 1;
        }
      }
      let RegimenMonthName = months[
        parseInt(selectedMonthYear.substring(4, 6)) - 1
      ].substring(0, RegimenMonthCount);
      let regSheetName = RegimenWorksheet.replace("{MMM}", RegimenMonthName)
        .replace("{MM}", RegimenMonthName)
        .replace("{YYYY}", RegimenYear)
        .replace("{YY}", RegimenYear)
        .toUpperCase();

      let _this = this;
      fileReader.onload = (e) => {
        const bufferArray = e.target.result;
        let wb = null;
        try {
          wb = XLSX.read(bufferArray, { type: "buffer" });
        } catch (error) {
          this.setState({
            error: "Password protected files are not allowed",
            loading: false,
          });
        }
        if (wb) {
          const sheetNames = wb.SheetNames.map((sheet) => sheet.toUpperCase());
          let data = {};
          if (logSheetName && sheetNames.indexOf(logSheetName) != -1) {
            let wsname = wb.SheetNames[sheetNames.indexOf(logSheetName)];
            const ws = wb.Sheets[wsname];

            const customHeaders = [
              "__EMPTY",
              "__EMPTY_1",
              "__EMPTY_2",
              "__EMPTY_3",
              "__EMPTY_4",
              "__EMPTY_5",
              "__EMPTY_6",
              "__EMPTY_7",
              "__EMPTY_8",
              "__EMPTY_9",
              "__EMPTY_10",
              "__EMPTY_11",
              "__EMPTY_12",
              "__EMPTY_13",
              "__EMPTY_14",
              "__EMPTY_15",
              "__EMPTY_16",
              "__EMPTY_17",
              "__EMPTY_18",
              "__EMPTY_19",
              "__EMPTY_20",
              "__EMPTY_21",
              "__EMPTY_22",
              "__EMPTY_23",
              "__EMPTY_24",
              "__EMPTY_25",
              "__EMPTY_26",
              "__EMPTY_27",
              "__EMPTY_28",
              "__EMPTY_29",
              "__EMPTY_30",
              "__EMPTY_31",
              "__EMPTY_32",
              "__EMPTY_33",
            ];

            data["log"] = XLSX.utils.sheet_to_json(ws, {
              range: 1,
              header: customHeaders,
            });

            // resolve(data);
          } else {
            this.setState({
              error:
                "File does not contain " +
                logSheetName +
                " worksheet. Unable to proceed",
              loading: false,
            });
          }

          if (regSheetName && sheetNames.indexOf(regSheetName) != -1) {
            const customHeadersReg = [
              "#",
              "Adult Regimen",
              "Therapy Line",
              "Number of Patients as of Last Month",
              "No. of New Patients in the Current Month",
              "No. of Attritions from the Last Month",
              "Number of Patients in the Current Month",
            ];

            let wsname = wb.SheetNames[sheetNames.indexOf(regSheetName)];
            const ws = wb.Sheets[wsname];
            data["reg"] = XLSX.utils.sheet_to_json(ws, {
              header: customHeadersReg,
            });
            // resolve(data);
          } else {
            this.setState({
              error:
                "File does not contain " +
                regSheetName +
                " worksheet. Unable to proceed",
              loading: false,
            });
          }
          resolve(data);
        }
      };

      fileReader.onerror = (error) => {
        this.setState({
          loading: false,
          error: error.message,
        });
        reject(error);
      };
    });

    promise.then((data) => {
      let logItems = data["log"];

      // We don't want to give regimen patient module to the client, so the following line is commented and a empty array new line added for the time being.

      let regItems = data["reg"];
      let headingTitle = {
        facilityName: "Facility Name",
        monthName: "Month",
        year: "Year",
      };

      if (
        logItems &&
        logItems.length &&
        logItems[1].__EMPTY_2 &&
        logItems[2].__EMPTY_12
      ) {
        headingTitle = {
          facilityName: logItems[1].__EMPTY_2,
          monthName: logItems[2].__EMPTY_12,
          year: logItems[2].__EMPTY_13,
        };
      }

      // let start_row_number = 6
      // if(this.state.artMutationData.LMISWorksheetStartRow){
      //   start_row_number = parseInt(this.state.artMutationData.LMISWorksheetStartRow.replace(/\D/g,''))
      // }
      let receiveDateValue = "";

      console.log("logItems: ", logItems);

      const facilityNameObject = logItems.find(
        (item) => item.__EMPTY_1 === "Facility Name"
      );

      if (!facilityNameObject) {
        this.setState({
          loading: false,
          error: "Facility Name text is missing in uploaded file",
        });
        return true;
      }

      const facilityName = facilityNameObject
        ? facilityNameObject.__EMPTY_2
        : "";

      if (!facilityName) {
        this.setState({
          loading: false,
          error: "Facility Name value is missing in uploaded file",
        });
        return true;
      }

      const dateReceivedObject = logItems.find(
        (item) => item.__EMPTY_8 === "Date Received"
      );
      if (!dateReceivedObject) {
        this.setState({
          loading: false,
          error: "Date Received text is missing in uploaded file",
        });
        return true;
      }
      const dateReceived = dateReceivedObject
        ? dateReceivedObject.__EMPTY_9
        : "Not found";
      if (!dateReceived) {
        this.setState({
          loading: false,
          error: "Date Received value is missing in uploaded file",
        });
        return true;
      }

      const year = dateReceivedObject
        ? dateReceivedObject.__EMPTY_14
        : "Not found";
      if (!year) {
        this.setState({
          loading: false,
          error: "Year value is missing in uploaded file",
        });
        return true;
      }

      const monthName = dateReceivedObject
        ? dateReceivedObject.__EMPTY_12
        : "Not found";
      if (!monthName) {
        this.setState({
          loading: false,
          error: "Month Name value is missing in uploaded file",
        });
        return true;
      }

      console.log("facilityName: ", facilityName);
      console.log("Date Received:", dateReceived);
      console.log("year: ", year);
      console.log("monthName: ", monthName);

      if (
        logItems &&
        logItems.length &&
        logItems[2] &&
        /^\d+$/.test(dateReceived)
      ) {
        let baseDate = new Date("1900-01-01");
        baseDate.setDate(baseDate.getDate() + (parseInt(dateReceived) - 2));
        receiveDateValue =
          baseDate.getFullYear() +
          "-" +
          String(baseDate.getMonth() + 1).padStart(2, "0") +
          "-" +
          String(baseDate.getDate()).padStart(2, "0");
      }

      const codeIndex = logItems.findIndex((item) => item.__EMPTY === "Code");
      const nextEmptyIndex = logItems
        .slice(codeIndex + 1)
        .findIndex((item) => item.__EMPTY !== undefined);

      if (codeIndex === -1) {
        this.setState({
          loading: false,
          error: "Code text is missing in uploaded file",
        });
        return false;
      }

      const prodRowIndex =
        nextEmptyIndex !== -1 ? codeIndex + 1 + nextEmptyIndex : "Not found";

      console.log("Next row index with __EMPTY after 'Code':", prodRowIndex);

      // Remove all rows before prodRowIndex
      logItems = logItems.slice(prodRowIndex);

      console.log("Filtered items:", logItems);

      logItems =
        logItems &&
        logItems.filter((item) => item["__EMPTY"] && item["__EMPTY"] != "Code");

      console.log("Final logItems: ", logItems);

      if (logItems == undefined || logItems.length == 0) {
        this.setState({ error: "Data not available in file", loading: false });
        return false;
      }

      let keyName = "Adult";

      console.log("regItems intact: ", regItems);

      // Filter out items before encountering "Adult Regimen": "Adult Regimen"
      const foundIndex = regItems.findIndex(
        (item) => item["Adult Regimen"] === "Adult Regimen"
      );

      regItems = foundIndex !== -1 ? regItems.slice(foundIndex) : [];
      console.log(
        "Filter out items before encountering 'Adult Regimen': 'Adult Regimen': ",
        regItems
      );

      // // Check - Serial Number - in the Regimens
      // const col1Text = "#";
      // const hashObj = regItems.find(
      //   (item) => item.hasOwnProperty(col1Text) && item[col1Text] === col1Text
      // );

      // if (!hashObj) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col1Text}" not found in the 1st column in Regimens`,
      //   });
      //   return false;
      // }

      // // Check - Adult Regimen - in the Regimens
      // const col2Text = "Adult Regimen";
      // const adultRegimen = regItems.find(
      //   (item) =>
      //     item.hasOwnProperty(col2Text) && item[col2Text] === "Adult Regimen"
      // );

      // if (!adultRegimen) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col2Text}" not found in the 2nd column in Regimens`,
      //   });
      //   return false;
      // }

      // // Check - Therapy Line - in the Regimens
      // const col3Text = "Therapy Line";
      // const therapyLine = regItems.find(
      //   (item) => item.hasOwnProperty(col3Text) && item[col3Text] === col3Text
      // );

      // if (!therapyLine) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col3Text}" not found in the 3rd column in Regimens`,
      //   });
      //   return false;
      // }

      // // Check - Number of Patients as of Last Month - in the Regimens
      // const col4Text = "Number of Patients as of Last Month";
      // const numberOfPatientsAsOfLastMonth = regItems.find(
      //   (item) => item.hasOwnProperty(col4Text) && item[col4Text] === col4Text
      // );

      // if (!numberOfPatientsAsOfLastMonth) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col4Text}" not found in the 4th column in Regimens`,
      //   });
      //   return false;
      // }

      // // Check - No. of New Patients in the Current Month - in the Regimens
      // const col5Text = "No. of New Patients in the Current Month";
      // const noOfNewPatientsintheCurrentMonth = regItems.find(
      //   (item) => item.hasOwnProperty(col5Text) && item[col5Text] === col5Text
      // );

      // if (!noOfNewPatientsintheCurrentMonth) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col5Text}" not found in the 5th column in Regimens`,
      //   });
      //   return false;
      // }

      // // Check - No. of Attritions from the Last Month - in the Regimens
      // const col6Text = "No. of Attritions from the Last Month";
      // const noOfAttritionsfromtheLastMonth = regItems.find(
      //   (item) => item.hasOwnProperty(col6Text) && item[col6Text] === col6Text
      // );

      // if (!noOfAttritionsfromtheLastMonth) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col6Text}" not found in the 6th column in Regimens`,
      //   });
      //   return false;
      // }

      // // Check - Number of Patients in the Current Month - in the Regimens
      // const col7Text = "Number of Patients in the Current Month";
      // const numberofPatientsintheCurrentMonth = regItems.find(
      //   (item) => item.hasOwnProperty(col7Text) && item[col7Text] === col7Text
      // );

      // if (!numberofPatientsintheCurrentMonth) {
      //   this.setState({
      //     loading: false,
      //     error: `"${col7Text}" not found in the 7th column in Regimens`,
      //   });
      //   return false;
      // }

      const columnsRegimens = [
        { columnNumber: 1, columnText: "#" },
        { columnNumber: 2, columnText: "Adult Regimen" },
        { columnNumber: 3, columnText: "Therapy Line" },
        { columnNumber: 4, columnText: "Number of Patients as of Last Month" },
        {
          columnNumber: 5,
          columnText: "No. of New Patients in the Current Month",
        },
        {
          columnNumber: 6,
          columnText: "No. of Attritions from the Last Month",
        },
        {
          columnNumber: 7,
          columnText: "Number of Patients in the Current Month",
        },
      ];

      const bAllColsExist = this.checkColumnsValue(
        regItems,
        columnsRegimens,
        "Regimens"
      );

      if (!bAllColsExist) {
        return;
      }

      regItems =
        regItems &&
        regItems.length > 1 &&
        regItems.map((regItem) => {
          let matchedKey = Object.keys(regItem).find((key) =>
            key.toString().toLowerCase().includes("regimen")
          );

          console.log("matchedKey: ", matchedKey);

          if (regItem.hasOwnProperty(matchedKey)) {
            if (regItem[matchedKey].toString().includes("Tablets/Capsules")) {
              keyName = "Paediatric Tablets/Capsules";
            }

            if (regItem[matchedKey].toString().includes("Syrup/Granules")) {
              keyName = "Paediatric Syrup/Granules";
            }

            regItem["Regimen"] = keyName + "-" + regItem[matchedKey];
          }

          return regItem;
        });

      console.log("regItems after Regimen property added: ", regItems);

      this.setState({
        headingTitle,
        logItems,
        regItems,
      });

      this.generateJson(logItems, regItems, receiveDateValue);
    });
  }

  generateJson(logItems, regItems, receiveDateValue) {
    if (!receiveDateValue) {
      this.setState({
        loading: false,
        error: "Receive Date is missing in uploaded file",
      });
      return true;
    }
    // let logTemplateData = this.state.logTemplateData.slice(start_row_number, this.state.logTemplateData.length);
    let receiveDate = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    let timelyStatus = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    let lateStatus = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    if (
      this.state.logTemplateData &&
      this.state.logTemplateData[2] &&
      this.state.logTemplateData[2].__EMPTY_8 == "Date Received"
    ) {
      let receiveDateKey = this.state.logTemplateData[2].__EMPTY_9;
      let reportTimelyStatus = this.state.logTemplateData[2].__EMPTY_21;
      let reportLateStatus = this.state.logTemplateData[2].__EMPTY_22;

      if (receiveDateKey) {
        receiveDate["dataElement"] = receiveDateKey.split("-")[0];
        receiveDate["categoryOptionCombo"] = receiveDateKey.split("-")[1];
        receiveDate["value"] = receiveDateValue;

        let year = receiveDateValue.split("-")[0];
        let month = receiveDateValue.split("-")[1];
        let day = receiveDateValue.split("-")[2];

        let receiveDt = new Date(year, month, day);

        let nextMonthYear = this.getNextPeriod(this.state.selectedMonthYear);

        let nxtYear = parseInt(nextMonthYear.substring(0, 4));
        let nxtMonth = parseInt(nextMonthYear.substring(4));

        let lastSubmissionDt = new Date(nxtYear, nxtMonth, 10);

        timelyStatus["dataElement"] = reportTimelyStatus.split("-")[0];
        timelyStatus["categoryOptionCombo"] = reportTimelyStatus.split("-")[1];

        lateStatus["dataElement"] = reportLateStatus.split("-")[0];
        lateStatus["categoryOptionCombo"] = reportLateStatus.split("-")[1];

        const one = 1;
        const zero = 0;

        if (receiveDt <= lastSubmissionDt) {
          timelyStatus["value"] = one.toFixed(1);
          lateStatus["value"] = zero.toFixed(1);
        } else {
          timelyStatus["value"] = zero.toFixed(1);
          lateStatus["value"] = one.toFixed(1);
        }
      }
    }

    let totalLossKey = null;
    let totalBalanceKey = null;
    let countAllProductKey = null;
    let countNonZeroKey = null;
    let totalLossValue = [];
    let totalBalanceValue = [];
    let countAllProductValue = null;
    let countNonZeroValue = null;
    if (
      this.state.logTemplateData &&
      this.state.logTemplateData[2] &&
      this.state.logTemplateData[2].__EMPTY_23 &&
      this.state.logTemplateData[2].__EMPTY_24 &&
      this.state.logTemplateData[2].__EMPTY_25 &&
      this.state.logTemplateData[2].__EMPTY_26
    ) {
      totalBalanceKey = this.state.logTemplateData[2].__EMPTY_23;
      totalLossKey = this.state.logTemplateData[2].__EMPTY_24;
      countAllProductKey = this.state.logTemplateData[2].__EMPTY_25;
      countNonZeroKey = this.state.logTemplateData[2].__EMPTY_26;
      logItems.map((item) => {
        let currentPrice = this.state.vTemplateCmsVenData.find(
          (vtemplateItem) => vtemplateItem["Code"] == item["__EMPTY"]
        );
        if (
          currentPrice &&
          (currentPrice["CurrentPrice"] || currentPrice["CurrentPrice"] == 0)
        ) {
          totalLossValue.push(
            parseFloat(item["__EMPTY_8"]) *
              parseFloat(currentPrice["CurrentPrice"])
          );
          totalBalanceValue.push(
            parseFloat(item["__EMPTY_11"]) *
              parseFloat(currentPrice["CurrentPrice"])
          );
        }
      });
      totalLossValue = Math.round(totalLossValue.reduce((a, b) => a + b, 0));
      totalBalanceValue = Math.round(
        totalBalanceValue.reduce((a, b) => a + b, 0)
      );
      countAllProductValue = logItems.length;
      countNonZeroValue = logItems.filter(
        (logItem) => logItem["__EMPTY_11"] != 0
      ).length;
    }

    let logTemplateData = this.state.logTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );

    let regTemplateData =
      this.state.regTemplateData &&
      this.state.regTemplateData.length &&
      this.state.regTemplateData.filter((regTemplate) => {
        if (
          !["Adult Regimens", "Paediatric Regimens"].includes(
            regTemplate["Regimen"]
          )
        ) {
          return regTemplate;
        }
      });

    let columnList = [
      "__EMPTY_5",
      "__EMPTY_6",
      "__EMPTY_7",
      "__EMPTY_8",
      "__EMPTY_9",
      "__EMPTY_10",
      "__EMPTY_11",
      "__EMPTY_12",
      "__EMPTY_13",
      "__EMPTY_14",
      "__EMPTY_15",
      "__EMPTY_16",
      "__EMPTY_17",
    ];

    // "__EMPTY": "Code",
    // "__EMPTY_1": "ProductDescription / Specifications",
    // "__EMPTY_2": "class",
    // "__EMPTY_3": "VEN",
    // "__EMPTY_4": "Unit of Issue",
    // "__EMPTY_5": "Beginning Balance",
    // "__EMPTY_6": "Quantity received during the reporting period",
    // "__EMPTY_7": "Quantity Issued  during the reporting period",
    // "__EMPTY_8": "Losses",
    // "__EMPTY_9": "Adjustments"
    // "__EMPTY_10": "Ending Balance (Book)",
    // "__EMPTY_11": "Ending Balance (Physical)",
    // "__EMPTY_12": "Stock quantity with less than 3 months shelf life ",
    // "__EMPTY_13": "No. of Days Stocked Out",
    // "__EMPTY_14": "Quantity Required/ ordered",
    // "__EMPTY_15": "Comments",
    // "__EMPTY_16": "AMC",
    // "__EMPTY_17": "Adjustment Type",
    // "__EMPTY_21": "Price",
    // "__EMPTY_22": "MOS",
    // "__EMPTY_23": "Quantity Issued PreMonth",
    // "__EMPTY_24": "Quantity Issued PrePreMonth",
    // "__EMPTY_25": "Stockout",
    // "__EMPTY_26": "Emergencyt",
    // "__EMPTY_27": "Understock",
    // "__EMPTY_28": "Adequate",
    // "__EMPTY_29": "Overstock",
    // "__EMPTY_30": "Closing Zero Stock",
    // "__EMPTY_31": "Non-Use"

    // let regColumnList = ["Number of Patients as of Last Reporting Period", "Number of New Patients in the Current Reporting Period", "Number of Attritions from the Regimen in the Current Reporting Period", "Number of Patients in the Current Reporting Period"]

    let logDataValues = [];
    let regDataValues = [];
    let logGridDataValues = [];
    let regGridDataValues = [];
    let regTemplateEmptyKeys = [];
    let _this = this;
    let vTemplateCmsVenData = this.state.vTemplateCmsVenData;

    if (
      totalLossKey &&
      totalBalanceKey &&
      countAllProductKey &&
      countNonZeroKey
    ) {
      logDataValues.push({
        dataElement: totalLossKey.split("-")[0],
        categoryOptionCombo: totalLossKey.split("-")[1],
        value: totalLossValue,
      });
      logDataValues.push({
        dataElement: totalBalanceKey.split("-")[0],
        categoryOptionCombo: totalBalanceKey.split("-")[1],
        value: totalBalanceValue,
      });
      logDataValues.push({
        dataElement: countAllProductKey.split("-")[0],
        categoryOptionCombo: countAllProductKey.split("-")[1],
        value: countAllProductValue,
      });
      logDataValues.push({
        dataElement: countNonZeroKey.split("-")[0],
        categoryOptionCombo: countNonZeroKey.split("-")[1],
        value: countNonZeroValue,
      });
    }

    logItems.map((item) => {
      let flag = true;

      if (!item.hasOwnProperty("__EMPTY")) {
        return;
      }

      logTemplateData.map((logTemplate) => {
        if (logTemplate["__EMPTY"] == item["__EMPTY"]) {
          flag = false;
          let newItem = {};
          newItem["__EMPTY"] = item["__EMPTY"];
          newItem["__EMPTY_1"] = item["__EMPTY_1"];
          newItem["__EMPTY_2"] = item["__EMPTY_2"];
          newItem["__EMPTY_3"] = item["__EMPTY_3"];
          newItem["__EMPTY_4"] = item["__EMPTY_4"];
          columnList.map((col) => {
            if (col == "__EMPTY_14" || col == "__EMPTY_16") {
              if (item[col]) {
                item[col] = Math.round(item[col]);
              }
            }
            newItem[col] = item[col];
            if (
              typeof logTemplate[col] == "string" &&
              logTemplate[col].split("-").length > 1
            ) {
              if (col != "__EMPTY_17") {
                if (col == "__EMPTY_14" && item[col] < 0) {
                  item[col] = 0;
                }
                if (item[col] || item[col] == 0) {
                  logDataValues.push({
                    dataElement: logTemplate[col].split("-")[0],
                    categoryOptionCombo: logTemplate[col].split("-")[1],
                    value: item[col],
                  });
                  newItem[col] = { key: logTemplate[col], value: item[col] };
                } else {
                  logDataValues.push({
                    dataElement: logTemplate[col].split("-")[0],
                    categoryOptionCombo: logTemplate[col].split("-")[1],
                    deleted: true,
                  });
                  newItem[col] = { key: logTemplate[col], value: item[col] };
                }
              } else {
                if (item[col] || item[col] == 0) {
                  let adjustmentType = item[col].trim();
                  let adjustmentValue = 0;
                  let option = {};
                  if (
                    _this.state.optionSetsData &&
                    _this.state.optionSetsData.length > 0
                  ) {
                    option = _this.state.optionSetsData.find((option) =>
                      option.displayName
                        .toLowerCase()
                        .includes(adjustmentType.toLowerCase())
                    );
                  }
                  if (option && option.code) {
                    adjustmentValue = parseInt(option.code);
                  } else {
                    adjustmentValue = item[col].toString().trim();
                  }
                  logDataValues.push({
                    dataElement: logTemplate[col].split("-")[0],
                    categoryOptionCombo: logTemplate[col].split("-")[1],
                    value: adjustmentValue,
                  });
                  newItem[col] = { key: logTemplate[col], value: item[col] };
                } else {
                  // If "Adjustment Type" is Empty
                  logDataValues.push({
                    dataElement: logTemplate[col].split("-")[0],
                    categoryOptionCombo: logTemplate[col].split("-")[1],
                    value: 0,
                  });
                  newItem[col] = { key: logTemplate[col], value: item[col] };
                }
              }
            }
          });
          logGridDataValues.push(newItem);
        }
      });
      if (flag) {
        let newItem = {};
        newItem["__EMPTY"] = item["__EMPTY"];
        newItem["__EMPTY_1"] = item["__EMPTY_1"];
        newItem["__EMPTY_2"] = item["__EMPTY_2"];
        newItem["__EMPTY_3"] = item["__EMPTY_3"];
        newItem["__EMPTY_4"] = item["__EMPTY_4"];
        columnList.map((col) => {
          if (col == "__EMPTY_14" || col == "__EMPTY_16") {
            if (item[col]) {
              item[col] = Math.round(item[col]);
            }
          }
          newItem[col] = item[col];
        });
        regTemplateEmptyKeys.push(newItem.__EMPTY);
        logGridDataValues.push(newItem);
      }
    });

    logDataValues.push(receiveDate);
    logDataValues.push(timelyStatus);
    logDataValues.push(lateStatus);
    // regItems = regItems.filter((item) => item["Regimen"])

    // Filter to return rows that have at least one matching key from regColumnList
    regItems = regItems.filter((item) => {
      return regColumnList.some((key) => key in item);
    });

    // console.log("filteredRegItems111: ", regItems);

    // Filter out objects where any key has the same value
    regItems = regItems.filter((item) => {
      return item.hasOwnProperty("Adult Regimen");
    });

    // Filter out objects where any key has the same value
    regItems = regItems.filter((item) => {
      return !Object.entries(item).some(([key, value]) => key === value);
    });

    // console.log("filteredRegItems222: ", regItems);

    // Remove rows those have String value in "Number of Patients as of Last Month"
    // regItems = regItems.filter(
    //   (item) =>
    //     item["Regimen"] &&
    //     (typeof item["Number of Patients as of Last Month"] == "number" ||
    //       item["Number of Patients as of Last Month"] == undefined)
    // );

    // console.log("regItems =======: ", regItems);

    regItems.forEach((row, index) => {
      regColumnList.forEach((col) => {
        if (typeof row[col] === "string" && isNaN(Number(row[col]))) {
          console.log(
            `Row ${index + 1}: ${col} contains a string value - ${row[col]}`
          );
        }
      });
    });

    // console.log("regItems =======: ", regItems);

    const stringRows = [];

    regItems.forEach((row, index) => {
      regColumnList.forEach((col) => {
        if (typeof row[col] === "string" && isNaN(Number(row[col]))) {
          stringRows.push({
            rowIndex: index + 1,
            column: col,
            value: row[col],
          });
        }
      });
    });

    if (stringRows.length > 0) {
      this.setState({
        loading: false,
        error:
          "There are some cells have text values. All cells must be numeric values.",
      });
      return;
    }

    //  // Filter out rows where at least one of the keys has a non-string value
    //  const stringValuesRegItems = regItems.filter((item) => {
    //   return regColumnList.every(
    //     (key) => !(key in item) || typeof item[key] === "string"
    //   );
    // });

    //console.log("stringValuesRegItems: ", stringValuesRegItems);

    regItems &&
      regItems.length &&
      regItems.map((item) => {
        let flag = true;
        regTemplateData &&
          regTemplateData.length &&
          regTemplateData.map((regTemplate) => {
            if (regTemplate["Regimen"] == item["Regimen"]) {
              flag = false;
              let newItem = {};
              newItem["Regimen"] = regTemplate["Regimen"];
              newItem["Therapy Line"] = regTemplate["Therapy Line"];
              regColumnList.map((col) => {
                newItem[col] = item[col];
                if (
                  typeof regTemplate[col] == "string" &&
                  regTemplate[col].split("-").length > 1
                ) {
                  if (item[col] || item[col] == 0) {
                    regDataValues.push({
                      dataElement: regTemplate[col].split("-")[0],
                      categoryOptionCombo: regTemplate[col].split("-")[1],
                      value: item[col],
                    });
                    newItem[col] = { key: regTemplate[col], value: item[col] };
                  } else {
                    regDataValues.push({
                      dataElement: regTemplate[col].split("-")[0],
                      categoryOptionCombo: regTemplate[col].split("-")[1],
                      deleted: true,
                    });
                    newItem[col] = { key: regTemplate[col], value: item[col] };
                  }
                }
              });
              regGridDataValues.push(newItem);
            }
          });
        if (flag) {
          let newItem = {};
          newItem["Regimen"] = item["Regimen"];
          newItem["Therapy Line"] = item["Therapy Line"];
          regColumnList.map((col) => {
            newItem[col] = item[col];
          });
          regTemplateEmptyKeys.push(newItem["Regimen"]);
          regGridDataValues.push(newItem);
        }
      });
    if (logDataValues.length > 0 && logGridDataValues.length > 0) {
      logDataValues = logDataValues.concat(regDataValues);

      // for found blank/negative products
      let checkColumns = [
        "__EMPTY_5",
        "__EMPTY_6",
        "__EMPTY_7",
        "__EMPTY_8",
        "__EMPTY_9",
        "__EMPTY_10",
        "__EMPTY_11",
        "__EMPTY_13",
        "__EMPTY_16",
      ];
      let blankOrNegativeRocords = logGridDataValues.filter((item) => {
        let flag = false;
        checkColumns.map((col) => {
          if (
            item[col] &&
            typeof item[col] == "object" &&
            (item[col].value == undefined ||
              (col != "__EMPTY_9" &&
                item[col].value &&
                Math.sign(item[col].value) == -1))
          ) {
            flag = true;
          }
        });
        if (flag) {
          return item;
        }
      });
      // for found duplicate products
      let dataValuesCode = logGridDataValues.map((item) => item["__EMPTY"]);
      let counts = {};
      let duplicateRecords = [];
      for (let i = 0; i < dataValuesCode.length; i++) {
        if (counts[dataValuesCode[i]]) {
          counts[dataValuesCode[i]] += 1;
        } else {
          counts[dataValuesCode[i]] = 1;
        }
      }
      for (let prop in counts) {
        if (counts[prop] >= 2) {
          duplicateRecords.push(prop);
        }
      }
      if (duplicateRecords.length == 0 && blankOrNegativeRocords.length == 0) {
        let logJsonData = {
          resource: "dataValueSets",
          type: "create",
          data: {
            period: this.state.selectedMonthYear,
            orgUnit: this.state.selectedFacility,
            dataValues: logDataValues,
          },
        };
        this.setState({
          regTemplateEmptyKeys,
          regGridDataValues,
          logGridDataValues: logGridDataValues.filter(
            (item) =>
              !(
                item["__EMPTY"] &&
                regTemplateEmptyKeys.includes(item["__EMPTY"])
              )
          ),
          missingProducts: logGridDataValues.filter(
            (item) =>
              item["__EMPTY"] && regTemplateEmptyKeys.includes(item["__EMPTY"])
          ),
          logJsonData,
          saveJsonData: true,
        });
      } else {
        this.setState({
          regTemplateEmptyKeys,
          logGridDataValues,
          blankOrNegativeRocords,
          duplicateProducts: logGridDataValues.filter((item) =>
            duplicateRecords.includes(item["__EMPTY"])
          ),
          showDuplicateProducts: true,
          conflictKeyList: duplicateRecords,
          conflictStatus: true,
          gridHeadingTitle: "Duplicate Products",
          firstStep: false,
          secondStep: false,
          loading: false,
        });
      }
    } else {
      this.setState({
        error: "Template file key's didn't match with uploaded file",
        loading: false,
      });
    }
  }

  generatePeriods(defaultYear, defaultMonth) {
    if (defaultMonth == 0) {
      defaultYear = defaultYear - 1;
      defaultMonth = 12;
    }
    let months = Constants.MONTH_NAME;
    let periods = [];
    let currentyear = new Date().getFullYear();
    if (currentyear !== defaultYear) {
      defaultMonth = 12;
    }
    for (let i = defaultMonth - 1; i >= 0; i--) {
      let option = {};
      option["name"] = months[i] + " " + defaultYear;
      option["id"] = defaultYear + String(i + 1).padStart(2, "0");
      periods.push(option);
    }
    if (this.state.deleteUploadedFile) {
      this.setState({
        periods,
        dataSetRegistrations: [],
      });
    } else {
      this.setState({
        periods,
        selectedMonthYear: periods[0].id,
        dataSetRegistrations: [],
      });
    }
  }

  setPeriods(year) {
    if (year == "previous") {
      this.setState({
        defaultYear: this.state.defaultYear - 1,
        getDataSetRegistrations: true,
      });
      this.generatePeriods(this.state.defaultYear - 1, this.state.defaultMonth);
    } else {
      let currentyear = new Date().getFullYear();
      if (currentyear !== this.state.defaultYear) {
        this.setState({
          defaultYear: this.state.defaultYear + 1,
          getDataSetRegistrations: true,
        });
        this.generatePeriods(
          this.state.defaultYear + 1,
          this.state.defaultMonth
        );
      }
    }
  }

  getOptionSetsResponse(data) {
    if (data && data.options) {
      this.setState({
        getOptionSets: false,
        optionSetsData: data.options.options,
        getOrgUnits: true,
        getDataSetRegistrations: true,
      });
    }
  }

  getGeneralSettingsResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        generalMutationData: data.dataStore,
        getGeneralSettings: false,
        getArtLogTemplateData: true,
        // getOptionSets: true
      });
    }
  }

  getAppSettingsResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        artMutationData: data.dataStore,
        selectedFacility: data.dataStore.ARTOrganisationUnitGroup,
        getAppSettings: false,
        getGeneralSettings: true,
      });
    }
  }

  getArtLogTemplateSettings(data) {
    if (data && data.dataStore) {
      this.setState({
        logTemplateData: data.dataStore,
        // getOptionSets: true,
        // getCmsVenTemplateSettings: true,
        getArtLogTemplateData: false,
        getArtRegTemplateData: true,
      });
    } else {
      this.setState({
        loading: false,
        error: "Art Template JSON missing!",
      });
    }
  }

  getArtRegTemplateSettings(data) {
    if (data && data.dataStore) {
      this.setState({
        regTemplateData: data.dataStore,
        // getOptionSets: true,
        getCmsVenTemplateSettings: true,
        getArtRegTemplateData: false,
      });
    } else {
      this.setState({
        loading: false,
        error: "Art Template JSON missing!",
      });
    }
  }

  getCmsVenTemplateSettingsResponse(data) {
    if (data && data.dataStore) {
      let vTemplateCmsVenData = [];
      if (data.dataStore.length > 0) {
        let itemKeys = Object.keys(data.dataStore[0]);
        data.dataStore.filter((item) => {
          if (
            (item["Code"] && item["Code"] != "Code") ||
            (item["Code "] && item["Code "] != "Code ")
          ) {
            let flag = false;
            let newItem = {};
            itemKeys.map((itemKey) => {
              if (itemKey.includes("Code") || itemKey.includes("Code ")) {
                newItem["Code"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Unit Price")) {
                newItem["UnitPrice"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Current stock")) {
                newItem["CurrentStock"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Current Price")) {
                newItem["CurrentPrice"] = item[itemKey];
                flag = true;
              }
            });
            if (flag) {
              vTemplateCmsVenData.push(newItem);
            }
          }
        });
      }
      this.setState({
        vTemplateCmsVenData,
        vTemplateCmsVenDataList: data.dataStore,
        getOptionSets: true,
        getCmsVenTemplateSettings: false,
      });
    }
  }

  uploadAmcMosResponse = (response, AMCs, MOSs) => {
    if (response.conflicts.length > 0) {
      alert(
        "Uploading AMC and MOS has coflicts: " +
          JSON.stringify(response.conflicts)
      );
      this.setState({
        loading: false,
        error: "Uploading AMC and MOS has coflicts",
      });
    } else {
      this.setState({
        fourthStep: true,
        thirdStep: false,
        loading: false,
        AMCs,
        MOSs,
      });
    }
  };

  getNextPeriod = (ym) => {
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    if (month == 12) {
      month = 1;
      year = year + 1;
    } else {
      month = month + 1;
    }

    ym = year + month.toString().padStart(2, "0");

    return ym;
  };

  render() {
    return (
      <>
        {this.state.getAppSettings && (
          <GetAppSettingsNew
            query={getAppSettingsQuery}
            onResponse={this.getAppSettingsResponse}
          />
        )}
        {this.state.getGeneralSettings && (
          <GetAppSettingsNew
            query={getGeneralSettingsQuery}
            onResponse={this.getGeneralSettingsResponse}
          />
        )}
        {this.state.getArtLogTemplateData && (
          <GetArtTemplateSettings
            query={artLogTemplateQuery}
            onResponse={this.getArtLogTemplateSettings}
          />
        )}
        {this.state.getArtRegTemplateData && (
          <GetArtTemplateSettings
            query={artRegTemplateQuery}
            onResponse={this.getArtRegTemplateSettings}
          />
        )}
        {this.state.getCmsVenTemplateSettings && (
          <GetAppSettingsNew
            query={getCmsVenTemplateSettingsQuery}
            onResponse={this.getCmsVenTemplateSettingsResponse}
          />
        )}
        {this.state.getOptionSets && (
          <GetOptionSets
            query={getOptionSetsQuery}
            optionSetId={this.state.generalMutationData.AdjustmentOptionSet}
            onResponse={this.getOptionSetsResponse}
          />
        )}
        {this.state.fourthStep && (
          <ExcelImportAppLogsJson
            onComplete={(result) => {
              this.setState({
                fourthStep: false,
                fifthStep: true,
                loading: false,
              });
            }}
            query={mutationExcelImportAppLogsJson}
            importTemplateLogsJson={this.state.importTemplateLogsJson}
            onResponse={this.getExcelImportAppLogsJson}
          />
        )}
        {this.state.saveJsonData && (
          <InsertDataValueSets
            onComplete={(result) => {
              let conflictKeyList = [];
              let statusBtnIcon = null;
              let conflictStatus = false;
              if (result.conflicts && result.conflicts.length > 0) {
                conflictStatus = true;
              }
              result.conflicts.map((conflict) => {
                if (conflict.value) {
                  conflictKeyList.push(conflict.object.trim());
                }
              });
              let selectedFacility = this.state.orgUnits.find(
                (item) => item.id === this.state.selectedFacility
              );
              let importTemplateLogsJson = this.props.importTemplateLogs || [];
              importTemplateLogsJson.push({
                User: this.state.user.displayName,
                DateTime: new Date().toISOString(),
                FileName: this.state.fileName,
                FacilityName: selectedFacility
                  ? selectedFacility.displayName
                  : "",
                MonthYear: this.state.selectedMonthYear,
                Status: {
                  Message:
                    conflictKeyList.length == 0
                      ? "Import process completed successfully"
                      : "Import process completed with error",
                  conflicts: result.conflicts,
                },
              });
              this.setState({
                importTemplateLogsJson,
                conflictStatus,
                statusBtnIcon,
                conflictKeyList,
                saveJsonData: false,
                resultStatus: result.status,
                resInsertData: result,
                firstStep: false,
                secondStep: false,
                thirdStep: true,
                setDataSetRegistration: true,
              });
            }}
            logJsonData={this.state.logJsonData}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {this.state.deleteUploadedFile && (
          <InsertDataValueSets
            onComplete={(result) => {
              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: true,
                afterDeleteUploadedFile: true,
              });
            }}
            logJsonData={this.deleteJsonData()}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {this.state.afterDeleteUploadedFile && (
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson={mutationDatasetRegJson}
            orgUnitId={this.state.selectedFacility}
            period={this.state.selectedMonthYear}
            completed={false}
            artMutationData={this.state.artMutationData}
            saveDataSetRegistration={this.saveDataSetRegistration}
          />
        )}
        {this.state.firstStep && (
          <FirstStep
            deleteUploadedFile={this.deleteUploadedFile}
            entryOrEdit={this.entryOrEdit}
            searchFacility={this.state.searchFacility}
            handleSearchFacility={this.handleSearchFacility}
            handleFirstStep={this.handleFirstStep}
            readExcel={this.readExcel}
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            dataSetRegistrations={this.state.dataSetRegistrations}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
            calculateImportStatus={this.calculateImportStatus}
            facilityGridData={this.facilityGridData}
          />
        )}
        {this.state.firstStep && this.state.getOrgUnits && (
          <GetOrgUnitGroups
            response={this.getOrgUnitGroups}
            orgUnitsQuery={orgUnitsQuery}
            artMutationData={this.state.artMutationData}
            selectedFacility={this.state.selectedFacility}
            handleError={this.handleError}
            stateError={this.state.error}
          />
        )}
        {this.state.firstStep && this.state.getDataSetRegistrations && (
          <GetCompleteDataSetRegistrations
            dataSetRegistrationQuery={dataSetRegistrationQuery}
            selectedMonthYear={this.state.selectedMonthYear}
            artMutationData={this.state.artMutationData}
            response={this.getCompleteDataSet}
            handleError={this.handleError}
            stateError={this.state.error}
          />
        )}
        {this.state.setDataSetRegistration && (
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson={mutationDatasetRegJson}
            orgUnitId={this.state.selectedFacility}
            period={this.state.selectedMonthYear}
            completed={true}
            artMutationData={this.state.artMutationData}
            saveDataSetRegistration={this.saveDataSetRegistration}
          />
        )}
        {(this.state.secondStep ||
          this.state.thirdStep ||
          this.state.fourthStep) && (
          <SecondStep
            handleSecondStep={this.handleSecondStep}
            readExcel={this.readExcel}
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
          />
        )}
        {this.state.thirdStep && this.state.resultStatus && (
          <CalculateAmcMos
            logItems={this.state.logItems}
            logTemplateData={this.state.logTemplateData}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            artMutationData={this.state.artMutationData}
            uploadAmcMosResponse={this.uploadAmcMosResponse}
          />
        )}
        {this.state.fifthStep && (
          <ImportProgressArtTemplate
            changePanel={this.changePanel}
            logItems={this.state.logItems}
            logJsonData={this.state.logJsonData}
            loading={this.state.loading}
            headingTitle={this.state.headingTitle}
            resInsertData={this.state.resInsertData}
            resultStatus={this.state.resultStatus}
            conflictStatus={this.state.conflictStatus}
            conflictKeyList={this.state.conflictKeyList}
            logGridDataValues={this.state.logGridDataValues}
            regGridDataValues={this.state.regGridDataValues}
            missingProducts={this.state.missingProducts}
            regTemplateEmptyKeys={this.state.regTemplateEmptyKeys}
            fileName={this.state.fileName}
            statusBtnIcon={this.state.statusBtnIcon}
            redirectToFirstStep={this.redirectToFirstStep}
            AMCs={this.state.AMCs}
            MOSs={this.state.MOSs}
          />
        )}
        {this.state.showDuplicateProducts && (
          <ShowDuplicateProducts
            duplicateProducts={this.state.duplicateProducts}
            blankOrNegativeRocords={this.state.blankOrNegativeRocords}
            showDuplicateProducts={this.state.showDuplicateProducts}
            redirectToFirstStep={this.redirectToFirstStep}
            gridHeadingTitle={this.state.gridHeadingTitle}
            logGridDataValues={this.state.logGridDataValues}
            changePanel={this.changePanel}
            resultStatus="ERROR"
            // logItems = {this.state.logItems}
            // logJsonData = {this.state.logJsonData}
            loading={this.state.loading}
            headingTitle={this.state.headingTitle}
            // resInsertData = {this.state.resInsertData}
            // resultStatus = {this.state.resultStatus}
            conflictStatus={this.state.conflictStatus}
            conflictKeyList={this.state.conflictKeyList}
            regTemplateEmptyKeys={this.state.regTemplateEmptyKeys}
            fileName={this.state.fileName}
            // statusBtnIcon = {this.state.statusBtnIcon}
            // redirectToFirstStep = {this.redirectToFirstStep}
            // AMCs = {this.state.AMCs}
            // MOSs = {this.state.MOSs}
          />
        )}

        {this.state.showArvViewEntryEdit && (
          <ArvViewEntryEdit
            selectedOrgUnit={lastSelectedOrgUnit}
            backToFacilitylist={this.backToFacilitylist}
            selectedMonthYear={this.state.selectedMonthYear}
            artMutationData={this.state.artMutationData}
            optionSetsData={this.state.optionSetsData}
            completed={this.state.completed}
            setPeriods={this.setPeriods}
          />
        )}
      </>
    );
  }
}

export default ImportArtTemplate;
