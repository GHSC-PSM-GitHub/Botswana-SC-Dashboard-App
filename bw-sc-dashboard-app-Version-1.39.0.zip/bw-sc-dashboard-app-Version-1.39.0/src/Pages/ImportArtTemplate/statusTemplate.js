import React, { Component } from 'react';
import Dropzone from 'react-dropzone';
import styles from '../Pages.module.css';
import { Menu, MenuItem, Button, Table, TableHead, TableBody, TableRow, TableRowHead, TableCellHead, TableCell, CircularLoader } from '@dhis2/ui-core';

class StatusTemplate extends Component {
  constructor( props ) {
		super( props );
		this.state = {
		}
	}

  render() {
		const resInsertData = this.props.resInsertData
		const	logResultStatus = this.props.logResultStatus

    return (
      <>
				<div>
					<h2>Data Import</h2>
					{
						this.props.fileName && <p>Import data values from {this.props.fileName} file.</p>
					}
					<div className={styles.statusSection}>
						<h3>Job summery</h3>
            {
              logResultStatus=="WARNING" && resInsertData.conflicts && resInsertData.conflicts.length>1 && 
              <span className={styles.conflictLevel}>Conflicts</span>
            }
            {
              logResultStatus=="SUCCESS" && 	<span className={styles.completedLavel}>Completed</span>
            }

						<hr/>
						<h4>Summary</h4>
						<Table dataTest="dhis2-uicore-table">
							<TableHead dataTest="dhis2-uicore-tablehead">
								<TableRowHead dataTest="dhis2-uicore-tablerowhead">
									<TableCellHead dataTest="dhis2-uicore-tablecellhead">
										Status
									</TableCellHead>
									<TableCellHead dataTest="dhis2-uicore-tablecellhead" colSpan="4">
										Description
									</TableCellHead>
								</TableRowHead>
							</TableHead>
							<TableBody dataTest="dhis2-uicore-tablebody">
								<TableRow dataTest="dhis2-uicore-tablerow">
									<TableCell dataTest="dhis2-uicore-tablecell">
										{resInsertData.status}
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell" colSpan="4">
										{resInsertData.description}
									</TableCell>
								</TableRow>
								<TableRow dataTest="dhis2-uicore-tablerow">
									<TableCell dataTest="dhis2-uicore-tablecell">
										<b>Created</b>
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										<b>Deleted</b>
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										<b>Ignored</b>
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										<b>Updated</b>
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										<b>Total</b>
									</TableCell>
								</TableRow>
								<TableRow dataTest="dhis2-uicore-tablerow">
									<TableCell dataTest="dhis2-uicore-tablecell">
										{ resInsertData.importCount && resInsertData.importCount.imported}
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										{ resInsertData.importCount && resInsertData.importCount.deleted}
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										{ resInsertData.importCount && resInsertData.importCount.ignored}
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										{ resInsertData.importCount && resInsertData.importCount.updated}
									</TableCell>
									<TableCell dataTest="dhis2-uicore-tablecell">
										{ resInsertData.importCount && resInsertData.importCount.imported + resInsertData.importCount.deleted + resInsertData.importCount.ignored + resInsertData.importCount.updated}
									</TableCell>
								</TableRow>
							</TableBody>
						</Table>
						{
							resInsertData.conflicts && resInsertData.conflicts.length>0 &&
							<div>
								<h4>Conflicts</h4>
								<Table dataTest="dhis2-uicore-table">
									<TableHead dataTest="dhis2-uicore-tablehead">
										<TableRowHead dataTest="dhis2-uicore-tablerowhead">
											<TableCellHead dataTest="dhis2-uicore-tablecellhead">
												Object
											</TableCellHead>
											<TableCellHead dataTest="dhis2-uicore-tablecellhead" colSpan="4">
												Value
											</TableCellHead>
										</TableRowHead>
									</TableHead>
									<TableBody dataTest="dhis2-uicore-tablebody">
										{
											resInsertData.conflicts.map((conflict, confKey)=>{
												return(
													<TableRow dataTest="dhis2-uicore-tablerow" key={confKey}>
														<TableCell dataTest="dhis2-uicore-tablecell">
															{conflict.object}
														</TableCell>
														<TableCell dataTest="dhis2-uicore-tablecell" colSpan="4">
															{conflict.value}
														</TableCell>
													</TableRow>
												)
											})
										}
									</TableBody>
								</Table>
							</div>
						}
					</div>
				</div>
				</>
		)
  }
}

export default StatusTemplate;
