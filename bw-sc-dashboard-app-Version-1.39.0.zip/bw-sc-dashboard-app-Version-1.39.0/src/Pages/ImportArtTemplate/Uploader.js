import React, {Component} from 'react';
import Dropzone from 'react-dropzone';
import { Menu, MenuItem, Button } from '@dhis2/ui-core';
import {useDropzone} from 'react-dropzone';

const onDrop = (file, props) => {
  props.readExcel(file[0]);
}

export default function Uploader(props) {
  const {
    acceptedFiles,
    fileRejections,
    getRootProps,
    getInputProps
  } = useDropzone({
    accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, application/vnd.ms-excel.sheet.macroEnabled.12',
    maxFiles:1,
    multiple: false,
    onDrop: (event) => onDrop(event, props)
  });

  const acceptedFileItems = acceptedFiles.map(file => (
    <li key={file.path}>
      {file.path} - {file.size/1024} kb
    </li>
  ));

  return (
    <section className="container">
      <div {...getRootProps()} style={{ borderWidth: 2, height: 130, borderStyle: 'dashed', borderColor: '#ccc', alignItems: 'center', justifyContent: 'center' }}>
        <input {...getInputProps()} />
        <center>
          <p>{props.title}</p>
          <em>
            <Button
              dataTest="dhis2-uicore-button"
              icon={
                <svg focusable="false" viewBox="0 0 24 24" aria-hidden="true" height="50" width="50" xmlns="http://www.w3.org/2000/svg"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"></path>
                </svg>
              }
              name="Icon button"
              type="button"
              value="default"
            />
          </em>
        </center>
      </div>
      <aside>
       <center>{acceptedFileItems}</center>
      </aside>
    </section>
  );
}

<Uploader />