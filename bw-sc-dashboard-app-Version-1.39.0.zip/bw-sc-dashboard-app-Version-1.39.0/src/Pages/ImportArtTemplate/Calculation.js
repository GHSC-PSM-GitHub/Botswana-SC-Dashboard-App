import { useEffect } from "react";
import { useDataEngine } from "@dhis2/app-runtime";
import moment from "moment";
import { getNextPeriod, GetSortOrder } from '../../helpers/common';
import { CircularLoader } from "@dhis2/ui-core";
import styles from "../Pages.module.css";


const LEGENDS_MAP = [
  "Non-use",
  "Stockout",
  "Potential Stockout",
  "Understock",
  "Satisfactory",
  "Risk of Expiry",
];

const CalculateAmcMos = (props) => {
  console.log("CalculateAmcMos props: ", props);
  const engine = useDataEngine();

  const query = {
    dataValueSets: {
      resource: "dataValueSets",
      params: {
        dataSet: props.artMutationData.ARTDataset,
        period: props.selectedMonthYear,
        orgUnit: props.selectedFacility,
        includeDeleted: true,
      },
    },
  };

  const mutationJson = {
    resource: "dataValueSets",
    type: "create",
    data: {
      dataValues: [],
    },
  };

  const queryLegendSetsById = {
    legendsSets: {
      resource: "legendSets",
      id: props.artMutationData.ARTLegend,
      params: {
        fields:
          "id, displayName, legends[id,displayName, startValue, endValue]",
      },
    },
  };

  let itemsExcelTemplate = [];
  let legends = [];

  const AMCs = [];
  const MOSs = [];

  const getTemplateExcelElements = () => {
   
    const logTemplateData = props.logTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );

    const logItems = props.logItems;

    const itemsByCode = {};

    logItems.map((item) => {
      itemsByCode[item["__EMPTY"]] = item;
    });

    logTemplateData.map((logTemplate, index) => {
      let code = logTemplate["__EMPTY"];

      if (itemsByCode[code] != undefined) {
        if (code == itemsByCode[code]["__EMPTY"]) {
          itemsExcelTemplate[index] = {
            ItemCode: logTemplate["__EMPTY"],
            ConsumptionUID: logTemplate["__EMPTY_7"],
            ClosingUID: logTemplate["__EMPTY_11"],
            AmcUID: logTemplate["__EMPTY_16"],
            MosUID: logTemplate["__EMPTY_22"],
            PreMonthUID: logTemplate["__EMPTY_23"],
            PrePreMonthUID: logTemplate["__EMPTY_24"],
            PreMonthSODUID: logTemplate["__EMPTY_32"],
            PrePreMonthSODUID: logTemplate["__EMPTY_33"],

            StockoutUID: logTemplate["__EMPTY_25"],
            Potential_StockoutUID: logTemplate["__EMPTY_26"],
            UnderstockUID: logTemplate["__EMPTY_27"],
            SatisfactoryUID: logTemplate["__EMPTY_28"],
            Risk_of_ExpiryUID: logTemplate["__EMPTY_29"],
            Non_UseUID: logTemplate["__EMPTY_31"],

            Closing_Zero_Stock: logTemplate["__EMPTY_30"],

            Consumption: itemsByCode[code]["__EMPTY_7"],
            Closing: itemsByCode[code]["__EMPTY_11"],

            NoStockOutDaysUID: logTemplate["__EMPTY_13"],
          };
        }
      }
    });

    getLegends();
  };

  const getCrossMatchedData = (data) => {
    let dValuesByEID = {};
    if (data && data.dataValueSets && data.dataValueSets.dataValues) {
      data.dataValueSets.dataValues.map((d) => {
        dValuesByEID[d.dataElement + "-" + d.categoryOptionCombo] = {
          dataElement: d.dataElement,
          categoryOptionCombo: d.categoryOptionCombo,
          value: d.value,
        };
      });
    }
    const logItems = [];

    itemsExcelTemplate.map((uids, index) => {
      let consumption_eid = "";
      let closing_eid = "";
      let amc_eid = "";
      let mos_eid = "";
      let premonth_eid = "";
      let prepremonth_eid = "";
      let premonth_sod_eid = "";
      let prepremonth_sod_eid = "";

      let stockout_eid = "";
      let potential_stockout_eid = "";
      let understock_eid = "";
      let satisfactory_eid = "";
      let risk_of_expiry_eid = "";
      let non_use_eid = "";
      let closing_zero_stock_eid = "";
      let sod_eid = "";

      let consumption_cc = "";
      let closing_cc = "";
      let amc_cc = "";
      let mos_cc = "";
      let premonth_cc = "";
      let prepremonth_cc = "";
      let premonth_sod_cc = "";
      let prepremonth_sod_cc = "";

      let stockout_cc = "";
      let potential_stockout_cc = "";
      let understock_cc = "";
      let satisfactory_cc = "";
      let risk_of_expiry_cc = "";
      let non_use_cc = "";
      let closing_zero_stock_cc = "";
      let sod_cc = "";

      let consumption_value = 0;
      let closing_value = 0;
      let amc_value = 0;
      let mos_value = 0;
      let premonth_value = 0;
      let prepremonth_value = 0;
      let premonth_sod_value = 0;
      let prepremonth_sod_value = 0;

      let stockout_value = 0;
      let potential_stockout_value = 0;
      let understock_value = 0;
      let satisfactory_value = 0;
      let risk_of_expiry_value = 0;
      let non_use_value = 0;
      let closing_zero_stock_value = 0;
      let sod_value = 0;

      if (dValuesByEID[uids.ConsumptionUID] != undefined) {
        consumption_eid = dValuesByEID[uids.ConsumptionUID].dataElement;
        consumption_cc = dValuesByEID[uids.ConsumptionUID].categoryOptionCombo;
        consumption_value = dValuesByEID[uids.ConsumptionUID].value;
      }

      if (dValuesByEID[uids.ClosingUID] != undefined) {
        closing_eid = dValuesByEID[uids.ClosingUID].dataElement;
        closing_cc = dValuesByEID[uids.ClosingUID].categoryOptionCombo;
        closing_value = dValuesByEID[uids.ClosingUID].value;
      }

      if (dValuesByEID[uids.NoStockOutDaysUID] != undefined) {
        sod_eid = dValuesByEID[uids.NoStockOutDaysUID].dataElement;
        sod_cc = dValuesByEID[uids.NoStockOutDaysUID].categoryOptionCombo;
        sod_value = dValuesByEID[uids.NoStockOutDaysUID].value;
      }

      if (uids.AmcUID != undefined) {
        amc_eid = uids.AmcUID.split("-")[0];
        amc_cc = uids.AmcUID.split("-")[1];
        amc_value = 0;
      }

      if (uids.MosUID != undefined) {
        mos_eid = uids.MosUID.split("-")[0];
        mos_cc = uids.MosUID.split("-")[1];
        mos_value = 0.0;
      }

      if (uids.PreMonthUID != undefined) {
        if (dValuesByEID[uids.PreMonthUID] != undefined) {
          premonth_eid = dValuesByEID[uids.PreMonthUID].dataElement;
          premonth_cc = dValuesByEID[uids.PreMonthUID].categoryOptionCombo;
          premonth_value = dValuesByEID[uids.PreMonthUID].value;
        } else {
          premonth_eid = uids.PreMonthUID.split("-")[0];
          premonth_cc = uids.PreMonthUID.split("-")[1];
          premonth_value = 0;
        }
      }

      if (uids.PrePreMonthUID != undefined) {
        if (dValuesByEID[uids.PrePreMonthUID] != undefined) {
          prepremonth_eid = dValuesByEID[uids.PrePreMonthUID].dataElement;
          prepremonth_cc =
            dValuesByEID[uids.PrePreMonthUID].categoryOptionCombo;
          prepremonth_value = dValuesByEID[uids.PrePreMonthUID].value;
        } else {
          prepremonth_eid = uids.PrePreMonthUID.split("-")[0];
          prepremonth_cc = uids.PrePreMonthUID.split("-")[1];
          prepremonth_value = 0;
        }
      }

      if (uids.PreMonthSODUID != undefined) {
        if (dValuesByEID[uids.PreMonthSODUID] != undefined) {
          premonth_sod_eid = dValuesByEID[uids.PreMonthSODUID].dataElement;
          premonth_sod_cc =
            dValuesByEID[uids.PreMonthSODUID].categoryOptionCombo;
          premonth_sod_value = dValuesByEID[uids.PreMonthSODUID].value;
        } else {
          premonth_sod_eid = uids.PreMonthSODUID.split("-")[0];
          premonth_sod_cc = uids.PreMonthSODUID.split("-")[1];
          premonth_sod_value = 0;
        }
      }

      if (uids.PrePreMonthSODUID != undefined) {
        if (dValuesByEID[uids.PrePreMonthSODUID] != undefined) {
          prepremonth_sod_eid =
            dValuesByEID[uids.PrePreMonthSODUID].dataElement;
          prepremonth_sod_cc =
            dValuesByEID[uids.PrePreMonthSODUID].categoryOptionCombo;
          prepremonth_sod_value = dValuesByEID[uids.PrePreMonthSODUID].value;
        } else {
          prepremonth_sod_eid = uids.PrePreMonthSODUID.split("-")[0];
          prepremonth_sod_cc = uids.PrePreMonthSODUID.split("-")[1];
          prepremonth_sod_value = 0;
        }
      }

      if (uids.StockoutUID != undefined) {
        stockout_eid = uids.StockoutUID.split("-")[0];
        stockout_cc = uids.StockoutUID.split("-")[1];
        stockout_value = 0;
      }

      if (uids.Potential_StockoutUID != undefined) {
        potential_stockout_eid = uids.Potential_StockoutUID.split("-")[0];
        potential_stockout_cc = uids.Potential_StockoutUID.split("-")[1];
        potential_stockout_value = 0;
      }

      if (uids.UnderstockUID != undefined) {
        understock_eid = uids.UnderstockUID.split("-")[0];
        understock_cc = uids.UnderstockUID.split("-")[1];
        understock_value = 0;
      }

      if (uids.SatisfactoryUID != undefined) {
        satisfactory_eid = uids.SatisfactoryUID.split("-")[0];
        satisfactory_cc = uids.SatisfactoryUID.split("-")[1];
        satisfactory_value = 0;
      }

      if (uids.Risk_of_ExpiryUID != undefined) {
        risk_of_expiry_eid = uids.Risk_of_ExpiryUID.split("-")[0];
        risk_of_expiry_cc = uids.Risk_of_ExpiryUID.split("-")[1];
        risk_of_expiry_value = 0;
      }

      if (uids.Non_UseUID != undefined) {
        non_use_eid = uids.Non_UseUID.split("-")[0];
        non_use_cc = uids.Non_UseUID.split("-")[1];
        non_use_value = 0;
      }

      if (uids.Closing_Zero_Stock != undefined) {
        closing_zero_stock_eid = uids.Closing_Zero_Stock.split("-")[0];
        closing_zero_stock_cc = uids.Closing_Zero_Stock.split("-")[1];

        if (closing_value == 0) {
          closing_zero_stock_value = 1;
        } else {
          closing_zero_stock_value = 0;
        }
      }

      logItems[index] = {
        ItemCode: uids.ItemCode,
        Consumption_InExcel: uids.Consumption,
        Closing_InExcel: uids.Closing,
        Consumption_InDataset: {
          eid: consumption_eid,
          cc: consumption_cc,
          value: consumption_value,
        },
        Closing_InDataset: {
          eid: closing_eid,
          cc: closing_eid,
          value: closing_value,
        },
        Amc_InDataset: { eid: amc_eid, cc: amc_cc, value: amc_value },
        MOS_InDataset: { eid: mos_eid, cc: mos_cc, value: mos_value },
        PreMonth_InDataset: {
          eid: premonth_eid,
          cc: premonth_cc,
          value: premonth_value,
        },
        PrePreMonth_InDataset: {
          eid: prepremonth_eid,
          cc: prepremonth_cc,
          value: prepremonth_value,
        },
        PreMonthSOD_InDataset: {
          eid: premonth_sod_eid,
          cc: premonth_sod_cc,
          value: premonth_sod_value,
        },
        PrePreMonthSOD_InDataset: {
          eid: prepremonth_sod_eid,
          cc: prepremonth_sod_cc,
          value: prepremonth_sod_value,
        },
        Closing_Zero_Stock_InExcel: {
          eid: closing_zero_stock_eid,
          cc: closing_zero_stock_cc,
          value: closing_zero_stock_value,
        },
        SOD_InDataset: {
          eid: sod_eid,
          cc: sod_cc,
          value: sod_value,
        },

        Legends: {
          Stockout: {
            eid: stockout_eid,
            cc: stockout_cc,
            value: stockout_value,
          },
          "Potential Stockout": {
            eid: potential_stockout_eid,
            cc: potential_stockout_cc,
            value: potential_stockout_value,
          },
          Understock: {
            eid: understock_eid,
            cc: understock_cc,
            value: understock_value,
          },
          Satisfactory: {
            eid: satisfactory_eid,
            cc: satisfactory_cc,
            value: satisfactory_value,
          },
          "Risk of Expiry": {
            eid: risk_of_expiry_eid,
            cc: risk_of_expiry_cc,
            value: risk_of_expiry_value,
          },
          "Non-use": { eid: non_use_eid, cc: non_use_cc, value: non_use_value },
        },
      };
    });

    const newItems = createAmcMos(logItems);

    uploadAmcMos(newItems);
  };

  const getLegends = () => {
    engine.query(queryLegendSetsById, {
      onComplete: (res) => {
        legends = res.legendsSets.legends.sort(GetSortOrder("startValue"));

        getDataValues();
      },

      onError: (error) => {},
    });
  };

  const getDataValues = () => {
    engine.query(query, {
      onComplete: (data) => {
        getCrossMatchedData(data);
      },

      onError: (error) => {},
    });
  };

  const createAmcMos = (logItems) => {
    let idx = 0;
    const newItems = [];

    let idxAmc = 0;
    let idxMos = 0;

    logItems.map((item) => {
      let divisor = 0;
      let newItem = {};
      //let sum_3months = 0;
      let amc = 0;
      let mos = 0;

      let prepreIssued = 0;
      let preIssued = 0;
      let issued = 0;

      let prepreSOD = 0;
      let preSOD = 0;
      let SOD = 0;

      // Aggregating (PrePre + Pre + Current month) distributions
      if (
        !(
          item.PrePreMonth_InDataset.value == 0 ||
          item.PrePreMonth_InDataset.value == undefined
        )
      ) {
        divisor++;
        //sum_3months = sum_3months + parseInt(item.PrePreMonth_InDataset.value);
        prepreIssued = +(item.PrePreMonth_InDataset.value ?? 0);
        prepreSOD = +(item.PrePreMonthSOD_InDataset.value ?? 0);
      }

      if (
        !(
          item.PreMonth_InDataset.value == 0 ||
          item.PreMonth_InDataset.value == undefined
        )
      ) {
        divisor++;
        //sum_3months = sum_3months + parseInt(item.PreMonth_InDataset.value);
        preIssued = +(item.PreMonth_InDataset.value ?? 0);
        preSOD = +(item.PreMonthSOD_InDataset.value ?? 0);
      }

      if (
        !(
          item.Consumption_InDataset.value == 0 ||
          item.Consumption_InDataset.value == undefined
        )
      ) {
        divisor++;
        //sum_3months = sum_3months + parseInt(item.Consumption_InDataset.value);
        issued = +(item.Consumption_InDataset.value ?? 0);
        SOD = +(item.SOD_InDataset.value ?? 0);
      }

      // =('Aug-2023 Log'!H8/(100%-('Aug-2023 Log'!N8/31)*100%)+'Sep-2023 Log'!H8/(100%-('Sep-2023 Log'!N8/30)*100%)+H8/(100%-(N8/31))*100%)/3

      // = (AugIssued/(100%-(AugNoStockOutDays/31)*100%)+
      //   (SepIssued/(100%-(SepNoStockOutDays/30)*100%)+
      //   (Issued/(100%-(NoStockOutDays/31)*100%))/3

      // = (prePreIssued/(100%-(prePreSOD/31)*100%)+
      //   (preIssued/(100%-(preSOD/30)*100%)+
      //   (issued/(100%-(SOD/31)*100%))/3

      const ymd = props.selectedMonthYear + "01";

      const daysInMonth = moment(ymd, "YYYYMMDD").daysInMonth();
      const preDaysInMonth = moment(ymd, "YYYYMMDD")
        .subtract(1, "months")
        .daysInMonth();
      const prepreDaysInMonth = moment(ymd, "YYYYMMDD")
        .subtract(2, "months")
        .daysInMonth();

      // creating AMC
      if (divisor > 0) {
        amc = Math.round(
          (prepreIssued / (1 - prepreSOD / prepreDaysInMonth) +
            preIssued / (1 - preSOD / preDaysInMonth) +
            issued / (1 - SOD / daysInMonth)) /
            divisor
        );

        amc = amc == Infinity ? 0 : amc;

        console.log(
          "Creating AMC: ",
          item.ItemCode,
          "= prepreIssued / (1 - prepreSOD / prepreDaysInMonth) + preIssued / (1 - preSOD / preDaysInMonth) + issued / (1 - SOD / daysInMonth)) / 3",
          `= ${prepreIssued} / (1 - ${prepreSOD} / ${prepreDaysInMonth}) + ${preIssued} / (1 - ${preSOD} / ${preDaysInMonth}) + ${issued} / (1 - ${SOD} / ${daysInMonth})) / 3`,
          `= ${amc}`
        );
      }

      //amc = Math.round(divisor > 0 ? sum_3months / divisor : 0);

      // creating MOS
      mos = amc > 0 ? parseInt(item.Closing_InDataset.value) / amc : 0;

      mos = isNaN(mos) ? 0 : mos;

      // creating dataValues for AMC
      newItem = {
        dataElement: item.Amc_InDataset.eid,
        categoryOptionCombo: item.Amc_InDataset.cc,
        period: props.selectedMonthYear,
        orgUnit: props.selectedFacility,
        value: amc,
      };
      newItems[idx++] = newItem;

      mos = mos.toFixed(2);

      AMCs[idxAmc++] = {
        ItemCode: item.ItemCode,
        AMC: amc,
      };

      MOSs[idxMos++] = {
        ItemCode: item.ItemCode,
        MOS: mos,
      };

      newItem = {};

      if (amc == 0) {
        newItem = {
          dataElement: item.MOS_InDataset.eid,
          categoryOptionCombo: item.MOS_InDataset.cc,
          period: props.selectedMonthYear,
          orgUnit: props.selectedFacility,
          deleted: true,
        };
        newItems[idx++] = newItem;
      } else {
        newItem = {
          dataElement: item.MOS_InDataset.eid,
          categoryOptionCombo: item.MOS_InDataset.cc,
          period: props.selectedMonthYear,
          orgUnit: props.selectedFacility,
          value: mos,
        };
        newItems[idx++] = newItem;
      }

      // creating dataValues for Closing Zero Stock
      newItem = {
        dataElement: item.Closing_Zero_Stock_InExcel.eid,
        categoryOptionCombo: item.Closing_Zero_Stock_InExcel.cc,
        period: props.selectedMonthYear,
        orgUnit: props.selectedFacility,
        value: item.Closing_Zero_Stock_InExcel.value,
      };
      newItems[idx++] = newItem;

      const nextPeriod = getNextPeriod(props.selectedMonthYear);

      // creating dataValues for [Quantity Issued PreMonth] of next month
      newItem = {
        dataElement: item.PreMonth_InDataset.eid,
        categoryOptionCombo: item.PreMonth_InDataset.cc,
        period: nextPeriod,
        orgUnit: props.selectedFacility,
        value: item.Consumption_InDataset.value ?? 0,
      };
      newItems[idx++] = newItem;

      // creating dataValues for [Quantity Issued PrePreMonth] of next month
      newItem = {
        dataElement: item.PrePreMonth_InDataset.eid,
        categoryOptionCombo: item.PrePreMonth_InDataset.cc,
        period: nextPeriod,
        orgUnit: props.selectedFacility,
        value: item.PreMonth_InDataset.value ?? 0,
      };
      newItems[idx++] = newItem;

      // creating dataValues for [No. of Days Stocked Out PreMonth] of next month
      newItem = {
        dataElement: item.PreMonthSOD_InDataset.eid,
        categoryOptionCombo: item.PreMonthSOD_InDataset.cc,
        period: nextPeriod,
        orgUnit: props.selectedFacility,
        value: item.SOD_InDataset.value ?? 0,
      };
      newItems[idx++] = newItem;

      // creating dataValues for [No. of Days Stocked Out PrePreMonth	] of next month
      newItem = {
        dataElement: item.PrePreMonthSOD_InDataset.eid,
        categoryOptionCombo: item.PrePreMonthSOD_InDataset.cc,
        period: nextPeriod,
        orgUnit: props.selectedFacility,
        value: item.PreMonthSOD_InDataset.value ?? 0,
      };
      newItems[idx++] = newItem;

      let status = "";

      mos = parseFloat(mos);

      console.log("legends: ", legends);

      legends.map((l, index) => {
        if (amc == 0) {
          status = { ...item.Legends[LEGENDS_MAP[0]], legend: LEGENDS_MAP[0] };

          newItem = {
            dataElement: status.eid,
            categoryOptionCombo: status.cc,
            period: props.selectedMonthYear,
            orgUnit: props.selectedFacility,
            value: 1,
          };
          newItems[idx++] = newItem;

          Object.keys(item.Legends).map((key) => {
            if (status.legend != key) {
              // console.log('item: ', item);
              // console.log('status.legend: ', status.legend);
              // console.log('key: ', key);
              //creting dataValues 0 for others legends in the same row
              newItem = {
                dataElement: item.Legends[key].eid,
                categoryOptionCombo: item.Legends[key].cc,
                period: props.selectedMonthYear,
                orgUnit: props.selectedFacility,
                value: 0,
              };
              newItems[idx++] = newItem;
              //console.log('newItem: ', newItem);
            }
          });
        } else if (mos >= l.startValue && mos < l.endValue) {
          console.log("index: ", index);
          console.log("mos: ", mos);
          console.log("l.startValue: ", l.startValue);
          console.log("l.endValue: ", l.endValue);

          console.log("LEGENDS_MAP[index]: ", LEGENDS_MAP[index]);

          status = {
            ...item.Legends[LEGENDS_MAP[index]],
            legend: LEGENDS_MAP[index],
          };
          console.log("status: ", status);

          // creating dataValues for exact matched legend
          newItem = {
            dataElement: status.eid,
            categoryOptionCombo: status.cc,
            period: props.selectedMonthYear,
            orgUnit: props.selectedFacility,
            value: 1,
          };
          newItems[idx++] = newItem;

          // console.log('newItem 1: ', newItem);

          Object.keys(item.Legends).map((key) => {
            if (status.legend != key) {
              // console.log('item: ', item);
              // console.log('status.legend: ', status.legend);
              // console.log('key: ', key);
              //creting dataValues 0 for others legends in the same row
              newItem = {
                dataElement: item.Legends[key].eid,
                categoryOptionCombo: item.Legends[key].cc,
                period: props.selectedMonthYear,
                orgUnit: props.selectedFacility,
                value: 0,
              };
              newItems[idx++] = newItem;
              //console.log('newItem: ', newItem);
            }
          });
        }
      });
    });

    return newItems;
  };

  const uploadAmcMos = (dataValues) => {
    //console.log('dataValues: ', dataValues);

    mutationJson.data.dataValues = dataValues;

    engine.mutate(mutationJson, {
      onComplete: (res) => {
        props.uploadAmcMosResponse(res, AMCs, MOSs);
      },

      onError: (error) => {},
    });
  };

  useEffect(() => {
    getTemplateExcelElements();
  }, []);

  return  <>
  <center>
    <CircularLoader
      className={styles.loading_icon}
      dataTest="dhis2-uicore-circularloader"
      large
    />
  </center>
</>;
};

export { CalculateAmcMos };
