import React, {
  useState,
  useRef,
  useEffect,
  useMemo,
  useCallback,
} from "react";

import {
  InputField,
  Button,
  ButtonStrip,
  Modal,
  ModalTitle,
  ModalContent,
  ModalActions,
} from "@dhis2/ui";

import { AgGridReact } from "ag-grid-react"; // the AG Grid React Component

import "ag-grid-community/dist/styles/ag-grid.css"; // Core grid CSS, always needed
import "ag-grid-community/dist/styles/ag-theme-alpine.css"; // Optional theme CSS

import { useDataEngine, useAlert } from "@dhis2/app-runtime";

import Constants from "../../helpers/constants";

import "./ArtModule.css";

import ErrorListModal from "./ErrorListModal";

import moment from "moment";

import Tabs from "../../components/Tabs/Tabs";
import "../../components/Tabs/Tabs.css";

import styles from "../Pages.module.css";

let obj = {};

let legends = [];

let dataValueSetsResult = {};

const LEGENDS_MAP = [
  "Non-use",
  "Stockout",
  "Potential Stockout",
  "Understock",
  "Satisfactory",
  "Risk of Expiry",
];

let Column_CO_Map = {};
let Column_CO_Map_Regimen = {};
let Column_CO_Map_Regimen_Paediatric_Tablets = {};
let Legends = {};
let de_co_ReceiveDate = "";
let de_co_ReportTimelyStatus = "";
let de_co_ReportLateStatus = "";

let de_co_totalLoss = "";
let de_co_totalBalance = "";
let de_co_countAllProduct = "";
let de_co_countNonZero = "";
let totalLossValue = [];
let totalBalanceValue = [];
let countAllProductValue = null;
let countNonZeroValue = null;

let adjustmentMap = [];
let adjustmentType = [];
let dataValueSetsQueryPrevMonth = {};
let cmsVenTemplateResult = [];

const ArvViewEntryEdit = (props) => {
  const newDate = moment().format("YYYY-MM-DD");
  const [reportReceivedDate, setReportReceivedDate] = useState(newDate);
  const [reportTimelyStatus, setReportTimelyStatus] = useState("");
  const [reportLateStatus, setReportLateStatus] = useState("");

  const [render, setRender] = useState(false);
  const [confirmSubmit, setConfirmSubmit] = useState(false);
  const [confirmBackTo, setConfirmBackTo] = useState(false);

  const [readOnly, setReadOnly] = useState(props.completed ? true : false);

  const [adjustmentTypeError, setAdjustmentTypeError] = useState(
    props.completed ? true : false
  );

  const engine = useDataEngine();

  const { show: showSuccess } = useAlert(({ Msg }) => `${Msg}`, {
    success: true,
    duration: 3000,
  });

  const { show: showCritical } = useAlert(({ Msg }) => `${Msg}`, {
    critical: true,
  });

  const [errors, setErrors] = useState(false);

  //clkwFBnjsQL
  const dataValueSetsQuery = {
    dataValueSets: {
      resource: `dataValueSets.json?dataSet=${props.artMutationData.ARTDataset}&orgUnit=${props.selectedOrgUnit.id}&period=${props.selectedMonthYear}`,
    },
  };

  const artLogTemplateQuery = {
    dataStore: {
      resource: `dataStore/${Constants.namespace}/${Constants.ArtLogTemplateKey}`,
    },
  };

  const artRegTemplateQuery = {
    dataStore: {
      resource: `dataStore/${Constants.namespace}/${Constants.ArtRegTemplateKey}`,
    },
  };

  const mutationDatasetRegJson = {
    resource: "completeDataSetRegistrations",
    type: "create",
    data: {
      completeDataSetRegistrations: [
        {
          dataSet: "",
          period: "",
          organisationUnit: "",
          completed: true,
        },
      ],
    },
  };

  const queryLegendSetsById = {
    legendsSets: {
      resource: "legendSets",
      id: props.artMutationData.ARTLegend,
      params: {
        fields:
          "id, displayName, legends[id,displayName, startValue, endValue]",
      },
    },
  };

  //clkwFBnjsQL
  const dataValueSetsRegimensQuery = {
    dataValueSets: {
      resource: `dataValueSets.json?dataSet=${props.artMutationData.ARTDataset}&orgUnit=${props.selectedOrgUnit.id}&period=${props.selectedMonthYear}`,
    },
  };

  const getCmsVenTemplateSettingsQuery = {
    dataStore: {
      resource: `dataStore/${Constants.namespace}/${Constants.CmsVenTemplateKey}`,
    },
  };

  const gridRef = useRef();
  const gridRefReg = useRef();
  const [rowData, setRowData] = useState();
  const [rowDataReg, setRowDataReg] = useState();

  const [isLoading, setIsLoading] = useState(false);

  const [isDirty, setIsDirty] = useState(false);

  adjustmentMap = props.optionSetsData.map((o) => {
    return o.displayName;
  });

  console.log("adjustmentMap: ", adjustmentMap);

  adjustmentType = extractValues(adjustmentMap);

  function extractValues(mappings) {
    return Object.keys(mappings);
  }

  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo(() => ({
    sortable: false,
    // set every column width
    width: 100,
    // make every column editable
    editable: false,
    // make every column use 'text' filter by default
    filter: "agTextColumnFilter",

    //flex: 1,
    resizable: true,
    wrapText: true,
    //autoHeight: true,
  }));

  // Each Column Definition results in one Column.
  const [columnDefs, setColumnDefs] = useState([
    {
      field: "N",
      minWidth: 70,
      width: 70,
      type: "rightAligned",
      editable: false,
      pinned: "left",
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Code",
      headerName: "Code",
      minWidth: 70,
      filter: true,
      sortable: true,
      pinned: "left",
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Product_Description_Or_Specifications",
      headerName: "Product Description / Specifications",
      minWidth: 300,
      filter: true,
      sortable: true,
      pinned: "left",
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Class",
      headerName: "Class",
      minWidth: 70,
      width: 90,
      filter: true,
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "VEN",
      headerName: "VEN",
      minWidth: 70,
      width: 90,
      filter: true,
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Unit_of_Issue",
      headerName: "Unit of Issue",
      minWidth: 70,
      width: 90,
      filter: true,
      sortable: true,
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Beginning_Balance",
      headerName: "Beginning Balance",
      type: "rightAligned",
      minWidth: 70,
      width: 90,
      cellStyle: { backgroundColor: "#d9f1f1" },
      valueFormatter: valuePlus,
    },
    {
      field: "Quantity_received",
      headerName: "Quantity received during the reporting period",
      type: "rightAligned",
      valueFormatter: valuePlus,
      editable: true && !readOnly,
    },
    {
      field: "Quantity_Issued",
      headerName: "Quantity Issued during the reporting period",
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "Losses",
      headerName: "Losses",
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "Adjustments",
      headerName: "Adjustments",
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlusMinus,
    },
    {
      field: "Ending_Balance_Book",
      headerName: "Ending Balance (Book)",
      type: "rightAligned",
      editable: false,
      suppressNavigable: true,
      cellStyle: { backgroundColor: "#d9f1f1" },
    },
    {
      field: "Ending_Balance_Physical",
      headerName: "Ending Balance (Physical)",
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "Stock_quantity_with_less_than_3_months",
      headerName: "Stock quantity with less than 3 months shelf life",
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "Quantity_Required_ordered",
      headerName: "Quantity Required/ ordered",
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "Comments",
      headerName: "Comments",
      type: "rightAligned",
      editable: true && !readOnly,
    },
    {
      field: "AMC",
      headerName: "AMC",
      type: "rightAligned",
      suppressNavigable: true,
      cellStyle: { backgroundColor: "#d9f1f1" },
    },
    {
      field: "MOS",
      headerName: "MOS",
      type: "rightAligned",

      suppressNavigable: true,
      cellStyle: { backgroundColor: "#d9f1f1" },
    },
    {
      field: "Adjustment_Type",
      headerName: "Adjustment Type",
      //type: "rightAligned",
      editable: true && !readOnly,
      cellEditor: "agSelectCellEditor",
      cellEditorParams: {
        values: adjustmentType,
      },
      refData: adjustmentMap,
    },
    { field: "Price", headerName: "Price", type: "rightAligned", hide: false },
    {
      field: "Quantity_Issued_PreMonth",
      hide: true,
    },
    {
      field: "Quantity_Issued_PrePreMonth",
      hide: true,
    },
    {
      field: "Stockout",
      hide: true,
    },
    {
      field: "Emergency",
      hide: true,
    },
    {
      field: "Understock",
      hide: true,
    },
    {
      field: "Adequate",
      hide: true,
    },
    {
      field: "Overstock",
      hide: true,
    },
    {
      field: "Non_use",
      hide: true,
    },
    {
      field: "Closing_Zero_Stock",
      hide: true,
    },
    {
      field: "dE_Num",
      hide: true,
    },
    {
      field: "dE_Comments",
      hide: true,
    },
    {
      field: "dE_AdjustmentType",
      hide: true,
    },
  ]);

  // DefaultColDef sets props common to all Columns
  const defaultColDefRegimen = useMemo(() => ({
    sortable: false,
    // set every column width
    width: 100,
    // make every column editable
    editable: false,
    // make every column use 'text' filter by default
    filter: "agTextColumnFilter",

    //flex: 1,
    resizable: true,
    wrapText: true,
    //autoHeight: true,
  }));

  // Each Column Definition results in one Column.
  const [columnDefsReg, setColumnDefsReg] = useState([
    {
      field: "RegGroup",
      headerName: "Regimens Group",
      minWidth: 300,
      filter: true,
      sortable: true,
      pinned: "left",
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Regimens",
      headerName: "Regimens",
      minWidth: 200,
      filter: true,
      sortable: true,
      pinned: "left",
      suppressNavigable: true,
      lockPosition: true,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "Number_of_Patients_as_of_Last_Month",
      headerName: "Number of Patients as of Last Reporting Period",
      width: 150,
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "No_of_New_Patients_in_the_Current_Month",
      headerName: "Number of New Patients in the Current Reporting Period",
      width: 150,
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "No_of_Attritions_from_the_Last_Month",
      headerName:
        "Number of Attritions from the Regimen in the Current Reporting Period",
      width: 150,
      type: "rightAligned",
      editable: true && !readOnly,
      valueFormatter: valuePlus,
    },
    {
      field: "Number_of_Patients_in_the_Current_Month",
      headerName: "Number of Patients in the Current Month",
      width: 150,
      type: "rightAligned",
      editable: false,
      //valueFormatter: valuePlus,
      cellStyle: { backgroundColor: "#f8f8f8" },
    },
    {
      field: "dE_Num",
      hide: true,
    },
  ]);

  function valuePlus(params) {
    //console.log('params: ', params);
    if (params.value === undefined || params.value === "") {
      return "";
    }

    var numbers = /^[0-9]+$/;
    if (params.value.match(numbers)) {
      params.data[params.colDef.field] = params.value;
      return params.value;
    } else {
      params.data[params.colDef.field] = "";
      return "";
    }
  }

  function valuePlusMinus(params) {
    if (params.value === undefined) {
      return "";
    }

    var numbers = /^[-]?[0-9]+$/;
    if (params.value.match(numbers)) {
      params.data[params.colDef.field] = params.value;
      return params.value;
    } else {
      params.data[params.colDef.field] = "";
      return "";
    }
  }

  const getLMISDataFromDHIS2 = async () => {
    obj = {};
    let de_co = "";

    let previousMonthDataValues = await getPreviousMonthDataValues();

    previousMonthDataValues = previousMonthDataValues.reduce(function (
      acc,
      cur,
      i
    ) {
      acc[cur.dataElement + "-" + cur.categoryOptionCombo] = cur;
      return acc;
    },
    {});

    console.log("previousMonthDataValues: ", previousMonthDataValues);

    const artLogTemplate = await engine.query(artLogTemplateQuery);
    const artLogTemplateResult = artLogTemplate.dataStore;
    console.log("artLogTemplateResult: ", artLogTemplateResult);

    const cmsVenTemplate = await engine.query(getCmsVenTemplateSettingsQuery);
    cmsVenTemplateResult = cmsVenTemplate.dataStore;
    console.log("cmsVenTemplateResult: ", cmsVenTemplateResult);

    // columnName and 'categoryOptionCombo' mapping
    Column_CO_Map = {
      Beginning_Balance: artLogTemplateResult[6]["__EMPTY_5"].split("-")[1],
      Quantity_received: artLogTemplateResult[6]["__EMPTY_6"].split("-")[1],
      Quantity_Issued: artLogTemplateResult[6]["__EMPTY_7"].split("-")[1],
      Losses: artLogTemplateResult[6]["__EMPTY_8"].split("-")[1],
      Adjustments: artLogTemplateResult[6]["__EMPTY_9"].split("-")[1],
      Ending_Balance_Book: artLogTemplateResult[6]["__EMPTY_10"].split("-")[1],
      Ending_Balance_Physical:
        artLogTemplateResult[6]["__EMPTY_11"].split("-")[1],
      Stock_quantity_with_less_than_3_months:
        artLogTemplateResult[6]["__EMPTY_12"].split("-")[1],
      Quantity_Required_ordered:
        artLogTemplateResult[6]["__EMPTY_13"].split("-")[1],
      Comments: artLogTemplateResult[6]["__EMPTY_14"].split("-")[1],
      AMC: artLogTemplateResult[6]["__EMPTY_15"].split("-")[1],
      MOS: artLogTemplateResult[6]["__EMPTY_22"].split("-")[1],
      Adjustment_Type: artLogTemplateResult[6]["__EMPTY_16"].split("-")[1],
      Price: artLogTemplateResult[6]["__EMPTY_21"].split("-")[1],
      Quantity_Issued_PreMonth:
        artLogTemplateResult[6]["__EMPTY_23"].split("-")[1],
      Quantity_Issued_PrePreMonth:
        artLogTemplateResult[6]["__EMPTY_24"].split("-")[1],
      Stockout: artLogTemplateResult[6]["__EMPTY_25"].split("-")[1],
      Emergency: artLogTemplateResult[6]["__EMPTY_26"].split("-")[1],
      Understock: artLogTemplateResult[6]["__EMPTY_27"].split("-")[1],
      Adequate: artLogTemplateResult[6]["__EMPTY_28"].split("-")[1],
      Overstock: artLogTemplateResult[6]["__EMPTY_29"].split("-")[1],
      Non_use: artLogTemplateResult[6]["__EMPTY_31"].split("-")[1],
      Closing_Zero_Stock: artLogTemplateResult[6]["__EMPTY_30"].split("-")[1],
    };

    Legends = {
      Stockout: Column_CO_Map.Stockout,
      "Potential Stockout": Column_CO_Map.Emergency,
      Understock: Column_CO_Map.Understock,
      Satisfactory: Column_CO_Map.Adequate,
      "Risk of Expiry": Column_CO_Map.Overstock,
      "Non-use": Column_CO_Map.Non_use,
    };

    const legendsSetsResult = await engine.query(queryLegendSetsById);
    legends = legendsSetsResult.legendsSets.legends.sort(
      GetSortOrder("startValue")
    );
    console.log("legends: ", legends);

    console.log("dataValueSetsQuery: ", dataValueSetsQuery);
    dataValueSetsResult = await engine.query(dataValueSetsQuery);
    console.log("dataValueSetsResult: ", dataValueSetsResult);

    let dataValues = [];
    if (dataValueSetsResult.dataValueSets.dataValues !== undefined) {
      dataValues = dataValueSetsResult.dataValueSets.dataValues;
      console.log("dataValues: ", dataValues);

      obj = dataValues.reduce(function (acc, cur, i) {
        acc[cur.dataElement + "-" + cur.categoryOptionCombo] = cur;
        return acc;
      }, {});
    }

    console.log("obj: ", obj);

    de_co_ReceiveDate = artLogTemplateResult[2].__EMPTY_9;
    de_co_ReportTimelyStatus = artLogTemplateResult[2].__EMPTY_21;
    de_co_ReportLateStatus = artLogTemplateResult[2].__EMPTY_22;

    de_co_totalLoss = artLogTemplateResult[2].__EMPTY_24;
    de_co_totalBalance = artLogTemplateResult[2].__EMPTY_23;
    de_co_countAllProduct = artLogTemplateResult[2].__EMPTY_25;
    de_co_countNonZero = artLogTemplateResult[2].__EMPTY_26;

    let receiveDateValue =
      obj[de_co_ReceiveDate] !== undefined ? obj[de_co_ReceiveDate].value : "";
    //console.log('receiveDateValue: ', receiveDateValue);

    let reportTimelyStatusValue =
      obj[de_co_ReportTimelyStatus] !== undefined
        ? obj[de_co_ReportTimelyStatus].value
        : "";
    //console.log('reportTimelyStatusValue: ', reportTimelyStatusValue);

    let reportLateStatusValue =
      obj[de_co_ReportLateStatus] !== undefined
        ? obj[de_co_ReportLateStatus].value
        : "";
    //console.log('reportLateStatusValue: ', reportLateStatusValue);

    if (receiveDateValue) {
      setReportReceivedDate(receiveDateValue);
    }

    if (reportTimelyStatusValue) {
      setReportTimelyStatus(reportTimelyStatusValue);
    }

    if (reportLateStatusValue) {
      setReportLateStatus(reportLateStatusValue);
    }

    const aData = [];

    artLogTemplateResult.forEach((o, i) => {
      if (i < 6) {
        return;
      }

      let N = i - 5;
      let Code = o.__EMPTY;
      //Product Description / Specifications
      let Product_Description_Or_Specifications = o.__EMPTY_1;
      let Class = o.__EMPTY_2;
      let VEN = o.__EMPTY_3;
      let Unit_of_Issue = o.__EMPTY_4;
      //Beginning Balance = pA6CFxovxdh-dWTgv7nQzp3
      let Beginning_Balance = "";

      if (!props.completed) {
        Beginning_Balance =
          previousMonthDataValues[o.__EMPTY_11] !== undefined
            ? previousMonthDataValues[o.__EMPTY_11].value
            : "";

        if (previousMonthDataValues[o.__EMPTY_11] !== undefined) {
          const de_Beginning_Balance = o.__EMPTY_5.split("-")[0];
          const co_Beginning_Balance = o.__EMPTY_5.split("-")[1];

          de_co = de_Beginning_Balance + "-" + co_Beginning_Balance;

          obj[de_co] = {
            dataElement: de_Beginning_Balance,
            categoryOptionCombo: co_Beginning_Balance,
            value: Beginning_Balance,
          };
        }
      } else {
        Beginning_Balance =
          obj[o.__EMPTY_5] !== undefined ? obj[o.__EMPTY_5].value : "";
      }

      //Quantity received during the reporting period = pA6CFxovxdh-cqr9Qz4S9ir
      let Quantity_received =
        obj[o.__EMPTY_6] !== undefined ? obj[o.__EMPTY_6].value : "";
      //Quantity Issued during the reporting period = pA6CFxovxdh-d1ha3qv5NVz
      let Quantity_Issued =
        obj[o.__EMPTY_7] !== undefined ? obj[o.__EMPTY_7].value : "";
      //Losses = pA6CFxovxdh-H8wShkXgdh5
      let Losses = obj[o.__EMPTY_8] !== undefined ? obj[o.__EMPTY_8].value : "";
      //Adjustments = pA6CFxovxdh-BH0lye2amGG
      let Adjustments =
        obj[o.__EMPTY_9] !== undefined ? obj[o.__EMPTY_9].value : "";

      //Ending Balance (Physical)	 = pA6CFxovxdh-gdfxU93ELmJ
      let Ending_Balance_Physical =
        obj[o.__EMPTY_11] !== undefined ? obj[o.__EMPTY_11].value : "";

      //Ending Balance (Book)	 = pA6CFxovxdh-lNjhiBWostD
      let Ending_Balance_Book = "";
      if (!props.completed && !Ending_Balance_Physical) {
        Ending_Balance_Book =
          previousMonthDataValues[o.__EMPTY_11] !== undefined
            ? previousMonthDataValues[o.__EMPTY_11].value
            : "";

        if (previousMonthDataValues[o.__EMPTY_11] !== undefined) {
          const de_Ending_Balance = o.__EMPTY_10.split("-")[0];
          const co_Ending_Balance = o.__EMPTY_10.split("-")[1];

          de_co = de_Ending_Balance + "-" + co_Ending_Balance;

          obj[de_co] = {
            dataElement: de_Ending_Balance,
            categoryOptionCombo: co_Ending_Balance,
            value: Ending_Balance_Book,
          };
        }
      } else {
        Ending_Balance_Book =
          obj[o.__EMPTY_10] !== undefined ? obj[o.__EMPTY_10].value : "";
      }

      //Stock quantity with less than 3 months shelf life = pA6CFxovxdh-eJcatASNrDD
      let Stock_quantity_with_less_than_3_months =
        obj[o.__EMPTY_12] !== undefined ? obj[o.__EMPTY_12].value : "";

      //Quantity Required/ ordered	 = pA6CFxovxdh-X8TZ8BA9Q5w
      let Quantity_Required_ordered =
        obj[o.__EMPTY_13] !== undefined ? obj[o.__EMPTY_13].value : "";
      //Comments = tAy4VENAVWJ-f8tqseFk9CK

      let Comments =
        obj[o.__EMPTY_14] !== undefined ? obj[o.__EMPTY_14].value : "";
      //AMC = pA6CFxovxdh-qmKxrGMLfcL
      let AMC = obj[o.__EMPTY_15] !== undefined ? obj[o.__EMPTY_15].value : "";
      //MOS = pA6CFxovxdh-sUKxIAlbTae
      let MOS = obj[o.__EMPTY_22] !== undefined ? obj[o.__EMPTY_22].value : "";
      //Adjustment Type = LboUxEvXXDW-XxPpu51hMrn
      let Adjustment_Type =
        obj[o.__EMPTY_16] !== undefined ? obj[o.__EMPTY_16].value : "";

      //Price = pA6CFxovxdh-UXUSOHc5zOq
      // let Price =
      //   obj[o.__EMPTY_21] !== undefined ? obj[o.__EMPTY_21].value : "";

      let productCms = cmsVenTemplateResult.find((x) => x.Code == Code);

      const currentPrice = productCms["Current Price"];
      //console.log("currentPrice: ", Code, " - ", currentPrice);

      let Price =
        obj[o.__EMPTY_21] !== undefined
          ? obj[o.__EMPTY_21].value
          : currentPrice;

      let Quantity_Issued_PreMonth =
        obj[o.__EMPTY_23] !== undefined ? obj[o.__EMPTY_23].value : "";
      //console.log("Quantity_Issued_PreMonth: ", Quantity_Issued_PreMonth);
      let Quantity_Issued_PrePreMonth =
        obj[o.__EMPTY_24] !== undefined ? obj[o.__EMPTY_24].value : "";

      let Stockout =
        obj[o.__EMPTY_25] !== undefined ? obj[o.__EMPTY_25].value : "";
      let Emergency =
        obj[o.__EMPTY_26] !== undefined ? obj[o.__EMPTY_26].value : "";
      let Understock =
        obj[o.__EMPTY_27] !== undefined ? obj[o.__EMPTY_27].value : "";
      let Adequate =
        obj[o.__EMPTY_28] !== undefined ? obj[o.__EMPTY_28].value : "";
      let Overstock =
        obj[o.__EMPTY_29] !== undefined ? obj[o.__EMPTY_29].value : "";
      let Non_use =
        obj[o.__EMPTY_31] !== undefined ? obj[o.__EMPTY_31].value : "";

      let Closing_Zero_Stock =
        obj[o.__EMPTY_30] !== undefined ? obj[o.__EMPTY_30].value : "";

      aData.push({
        id: Code,
        N,
        Code,
        Product_Description_Or_Specifications,
        Class,
        VEN,
        Unit_of_Issue,
        Beginning_Balance,
        Quantity_received,
        Quantity_Issued,
        Losses,
        Adjustments,
        Ending_Balance_Book,
        Ending_Balance_Physical,
        Stock_quantity_with_less_than_3_months,
        Quantity_Required_ordered,
        Comments,
        AMC,
        MOS,
        Adjustment_Type,
        Price,
        Quantity_Issued_PreMonth,
        Quantity_Issued_PrePreMonth,
        Stockout,
        Emergency,
        Understock,
        Adequate,
        Overstock,
        Non_use,
        Closing_Zero_Stock,
        dE_Num: o.__EMPTY_5.split("-")[0],
        dE_Comments: o.__EMPTY_14.split("-")[0],
        dE_AdjustmentType: o.__EMPTY_16.split("-")[0],
      });
    });

    setRowData(aData);
  };

  const getRegimensDataFromDHIS2 = async () => {
    let de_co = "";

    const artRegTemplate = await engine.query(artRegTemplateQuery);
    const artRegTemplateResult = artRegTemplate.dataStore;
    console.log("artRegTemplateResult: ", artRegTemplateResult);

    Column_CO_Map_Regimen = {
      Number_of_Patients_as_of_Last_Month:
        artRegTemplateResult[0]["Number of Patients as of Last Month"].split(
          "-"
        )[1],
      No_of_New_Patients_in_the_Current_Month:
        artRegTemplateResult[0][
          "No. of New Patients in the Current Month"
        ].split("-")[1],
      No_of_Attritions_from_the_Last_Month:
        artRegTemplateResult[0]["No. of Attritions from the Last Month"].split(
          "-"
        )[1],
      Number_of_Patients_in_the_Current_Month:
        artRegTemplateResult[0][
          "Number of Patients in the Current Month"
        ].split("-")[1],
    };

    const artRegTemplateResult_Paediatric_Tablets = artRegTemplateResult.find(
      (x) => {
        if (x["Regimen"].includes("Paediatric Tablets")) {
          return true;
        }
        return false;
      }
    );

    console.log(
      "artRegTemplateResult_Paediatric_Tablets: ",
      artRegTemplateResult_Paediatric_Tablets
    );

    Column_CO_Map_Regimen_Paediatric_Tablets = {
      Number_of_Patients_as_of_Last_Month:
        artRegTemplateResult_Paediatric_Tablets[
          "Number of Patients as of Last Month"
        ].split("-")[1],
      No_of_New_Patients_in_the_Current_Month:
        artRegTemplateResult_Paediatric_Tablets[
          "No. of New Patients in the Current Month"
        ].split("-")[1],
      No_of_Attritions_from_the_Last_Month:
        artRegTemplateResult_Paediatric_Tablets[
          "No. of Attritions from the Last Month"
        ].split("-")[1],
      Number_of_Patients_in_the_Current_Month:
        artRegTemplateResult_Paediatric_Tablets[
          "Number of Patients in the Current Month"
        ].split("-")[1],
    };

    const aDataReg = [];

    const lenOfUID = 23;

    let idx = 1;

    artRegTemplateResult.forEach((o) => {
      if (o["Regimen"] !== "") {
        if (
          o["Number of Patients as of Last Month"].length === lenOfUID &&
          o["No. of New Patients in the Current Month"].length === lenOfUID &&
          o["No. of Attritions from the Last Month"].length === lenOfUID &&
          o["Number of Patients in the Current Month"].length === lenOfUID
        ) {
          const vNumber_of_Patients_as_of_Last_Month =
            obj[o["Number of Patients as of Last Month"]] !== undefined
              ? obj[o["Number of Patients as of Last Month"]].value
              : "";

          const vNo_of_New_Patients_in_the_Current_Month =
            obj[o["No. of New Patients in the Current Month"]] !== undefined
              ? obj[o["No. of New Patients in the Current Month"]].value
              : "";

          const vNo_of_Attritions_from_the_Last_Month =
            obj[o["No. of Attritions from the Last Month"]] !== undefined
              ? obj[o["No. of Attritions from the Last Month"]].value
              : "";

          const vNumber_of_Patients_in_the_Current_Month =
            obj[o["Number of Patients in the Current Month"]] !== undefined
              ? obj[o["Number of Patients in the Current Month"]].value
              : "";

          aDataReg.push({
            id: idx++,
            RegGroup: o["RegGroup"],
            Regimens: o["Regimen"].split("-")[1],
            Number_of_Patients_as_of_Last_Month:
              vNumber_of_Patients_as_of_Last_Month,
            Number_of_Patients_as_of_Last_Month_UID:
              o["Number of Patients as of Last Month"],
            No_of_New_Patients_in_the_Current_Month:
              vNo_of_New_Patients_in_the_Current_Month,
            No_of_New_Patients_in_the_Current_Month_UID:
              o["No. of New Patients in the Current Month"],
            No_of_Attritions_from_the_Last_Month:
              vNo_of_Attritions_from_the_Last_Month,
            No_of_Attritions_from_the_Last_Month_UID:
              o["No. of Attritions from the Last Month"],
            Number_of_Patients_in_the_Current_Month:
              vNumber_of_Patients_in_the_Current_Month,
            Number_of_Patients_in_the_Current_Month_UID:
              o["Number of Patients in the Current Month"],
            dE_Num: o["Number of Patients as of Last Month"].split("-")[0],
          });
        }
      }
    });

    setRowDataReg(aDataReg);
  };

  const getSetData = async () => {
    await getLMISDataFromDHIS2();
    await getRegimensDataFromDHIS2();
  };

  // Example load data from sever
  useEffect(() => {
    getSetData();
  }, []);

  // Example of consuming Grid Event
  const cellClickedListener = useCallback((event) => {
    //console.log("cellClicked", event);
  }, []);

  const getRowId = useMemo(() => {
    return (params) => {
      return params.data.id;
    };
  }, []);

  const getRowIdRegimen = useMemo(() => {
    return (params) => {
      return params.data.id;
    };
  }, []);

  const validNumber = (val) => {
    if (!val || isNaN(val) || val === undefined || val === "") {
      return 0;
    }
    return val;
  };

  const isAllCellEmptyInRow = (data) => {
    if (
      !(
        validNumber(data.Beginning_Balance) ||
        validNumber(data.Quantity_received) ||
        validNumber(data.Quantity_Issued) ||
        validNumber(data.Losses) ||
        validNumber(data.Adjustments) ||
        validNumber(data.Ending_Balance_Book) ||
        validNumber(data.Ending_Balance_Physical)
      )
    ) {
      return true;
    }
    return false;
  };

  const cellValueChangedHandler = (event) => {
    console.log("cellValueChangedHandler");
    console.log("event: ", event);

    try {
      let oldValue = event.oldValue;
      console.log("oldValue: ", oldValue);

      if (typeof oldValue == "undefined") {
        oldValue = 0;
      }

      let newValue = event.newValue;
      console.log("newValue: ", newValue);

      if (typeof newValue == "undefined") {
        newValue = 0;
      }

      if (oldValue == newValue) {
        return;
      }

      setIsDirty(true);

      let de_co = "";
      let de = "";
      let co = "";

      if (event.column.colId === "Comments") {
        de = event.data.dE_Comments;
        co = Column_CO_Map.Comments;
      } else if (event.column.colId === "Adjustment_Type") {
        de = event.data.dE_AdjustmentType;
        co = Column_CO_Map.Adjustment_Type;
      } else {
        de = event.data.dE_Num;
        co = Column_CO_Map[event.column.colId];
      }

      de_co = de + "-" + co;

      console.log("de_co: ", de_co);

      // updating cell value
      if (obj[de_co] === undefined) {
        console.log(
          `Value not found for dataElement-categoryOptionCombo (${de_co}). So new index adding in data object.`
        );
        obj[de_co] = {
          dataElement: de,
          categoryOptionCombo: co,
          value: newValue,
        };
      } else {
        obj[de_co].value = newValue;
      }

      if (
        event.column.colId === "Comments" ||
        event.column.colId === "Adjustment_Type"
      ) {
        return;
      }

      let endBalanceBook =
        (event.data.Beginning_Balance === ""
          ? 0
          : parseInt(event.data.Beginning_Balance)) +
        (event.data.Quantity_received === ""
          ? 0
          : parseInt(event.data.Quantity_received)) -
        (event.data.Quantity_Issued === ""
          ? 0
          : parseInt(event.data.Quantity_Issued)) -
        (event.data.Losses === "" ? 0 : parseInt(event.data.Losses)) +
        (event.data.Adjustments === "" ? 0 : parseInt(event.data.Adjustments));

      setEndBalanceBook(event.data.id, endBalanceBook);

      let divisor = 0;
      let sum_3months = 0;
      let amc = 0;
      let mos = 0;

      let Ending_Balance_Physical =
        obj[event.data.dE_Num + "-" + Column_CO_Map.Ending_Balance_Physical];
      Ending_Balance_Physical = Ending_Balance_Physical
        ? parseInt(Ending_Balance_Physical.value)
        : 0;
      console.log("Ending_Balance_Physical: ", Ending_Balance_Physical);

      let Quantity_Issued =
        obj[event.data.dE_Num + "-" + Column_CO_Map.Quantity_Issued];
      Quantity_Issued = Quantity_Issued ? parseInt(Quantity_Issued.value) : 0;
      console.log("Quantity_Issued: ", Quantity_Issued);

      let Quantity_Issued_PreMonth =
        obj[event.data.dE_Num + "-" + Column_CO_Map.Quantity_Issued_PreMonth];
      Quantity_Issued_PreMonth = Quantity_Issued_PreMonth
        ? parseInt(Quantity_Issued_PreMonth.value)
        : 0;
      console.log("Quantity_Issued_PreMonth: ", Quantity_Issued_PreMonth);

      let Quantity_Issued_PrePreMonth =
        obj[
          event.data.dE_Num + "-" + Column_CO_Map.Quantity_Issued_PrePreMonth
        ];
      Quantity_Issued_PrePreMonth = Quantity_Issued_PrePreMonth
        ? parseInt(Quantity_Issued_PrePreMonth.value)
        : 0;
      console.log("Quantity_Issued_PrePreMonth: ", Quantity_Issued_PrePreMonth);

      // Aggregating (PrePre + Pre + Current month) distributions
      if (Quantity_Issued) {
        divisor++;
        sum_3months = sum_3months + Quantity_Issued;
      }
      if (Quantity_Issued_PreMonth) {
        divisor++;
        sum_3months = sum_3months + Quantity_Issued_PreMonth;
      }
      if (Quantity_Issued_PrePreMonth) {
        divisor++;
        sum_3months = sum_3months + Quantity_Issued_PrePreMonth;
      }

      console.log("sum_3months: ", sum_3months);
      console.log("divisor: ", divisor);

      // creating AMC
      amc = Math.round(divisor > 0 ? sum_3months / divisor : 0);
      console.log("sum_3months / divisor: ", sum_3months / divisor);
      console.log("amc=", sum_3months, "/", divisor, "=", amc);

      // creating MOS
      mos = amc > 0 ? Ending_Balance_Physical / amc : 0;

      mos = isNaN(mos) ? 0 : mos.toFixed(2);

      if (amc === 0 && Ending_Balance_Physical > 0) {
        mos = "";
      }

      console.log("mos=", Ending_Balance_Physical, "/", amc, "=", mos);

      if (
        !(
          validNumber(event.data.Quantity_Issued) ||
          validNumber(event.data.Quantity_Issued_PreMonth) ||
          validNumber(event.data.Quantity_Issued_PrePreMonth)
        )
      ) {
        setAMC(event.data.id, "");
        amc = "";
      } else {
        setAMC(event.data.id, amc);
      }

      if (
        !(
          validNumber(event.data.Beginning_Balance) ||
          validNumber(event.data.Quantity_received) ||
          validNumber(event.data.Quantity_Issued) ||
          validNumber(event.data.Losses) ||
          validNumber(event.data.Adjustments) ||
          validNumber(event.data.Ending_Balance_Book) ||
          validNumber(event.data.Ending_Balance_Physical)
        )
      ) {
        setMOS(event.data.id, "");
        mos = "";
      } else {
        setMOS(event.data.id, mos);
      }

      // Setting AMC
      de_co = event.data.dE_Num + "-" + Column_CO_Map.AMC;
      console.log("de_co AMC: ", de_co);

      obj[de_co] = {
        dataElement: event.data.dE_Num,
        categoryOptionCombo: Column_CO_Map.AMC,
        value: amc,
      };

      // Setting MOS
      de_co = event.data.dE_Num + "-" + Column_CO_Map.MOS;
      console.log("de_co MOS: ", de_co);

      obj[de_co] = {
        dataElement: event.data.dE_Num,
        categoryOptionCombo: Column_CO_Map.MOS,
        value: mos,
      };

      // Setting Closing_Zero_Stock to 1/0
      let Closing_Zero_Stock_Value = null;
      if (Ending_Balance_Physical === 0) {
        Closing_Zero_Stock_Value = 1;
      } else {
        Closing_Zero_Stock_Value = 0;
      }

      de_co = event.data.dE_Num + "-" + Column_CO_Map.Closing_Zero_Stock;
      console.log("de_co Closing: ", de_co);

      obj[de_co] = {
        dataElement: event.data.dE_Num,
        categoryOptionCombo: Column_CO_Map.Closing_Zero_Stock,
        value: Closing_Zero_Stock_Value,
      };

      if (isAllCellEmptyInRow(event.data)) {
        obj[de_co] = {
          dataElement: event.data.dE_Num,
          categoryOptionCombo: Column_CO_Map.Closing_Zero_Stock,
          value: "",
        };
        legends.forEach((l, index) => {
          de_co = event.data.dE_Num + "-" + Legends[LEGENDS_MAP[index]];
          obj[de_co] = {
            dataElement: event.data.dE_Num,
            categoryOptionCombo: Legends[LEGENDS_MAP[index]],
            value: "",
          };
        });
        return;
      }

      // Setting legends
      legends.forEach((l, index) => {
        if (amc == 0) {
          //Creating dataValues 1 for the legend Non-use
          de_co = event.data.dE_Num + "-" + Legends[LEGENDS_MAP[0]];
          let legendAvailable = LEGENDS_MAP[0];
          obj[de_co] = {
            dataElement: event.data.dE_Num,
            categoryOptionCombo: Legends[LEGENDS_MAP[0]],
            value: 1,
          };

          setValueZeroToOtherLegends(event.data.dE_Num, legendAvailable);
        } else if (mos >= l.startValue && mos < l.endValue) {
          // creating dataValues for exact matched legend
          de_co = event.data.dE_Num + "-" + Legends[LEGENDS_MAP[index]];
          let legendAvailable = LEGENDS_MAP[index];
          obj[de_co] = {
            dataElement: event.data.dE_Num,
            categoryOptionCombo: Legends[LEGENDS_MAP[index]],
            value: 1,
          };

          setValueZeroToOtherLegends(event.data.dE_Num, legendAvailable);
        }
      });
    } catch (error) {
      console.log("error: ", error);
      showCritical({ Msg: error });
    }
  };

  const cellValueChangedHandlerRegimen = (event) => {
    console.log("cellValueChangedHandlerRegimen");
    console.log("event: ", event);

    try {
      let oldValue = event.oldValue;
      console.log("oldValue: ", oldValue);

      if (typeof oldValue == "undefined") {
        oldValue = 0;
      }

      let newValue = event.newValue;
      console.log("newValue: ", newValue);

      if (typeof newValue == "undefined") {
        newValue = 0;
      }

      if (oldValue == newValue) {
        return;
      }

      setIsDirty(true);

      let de_co = "";
      let de = "";
      let co = "";

      //de = event.data.dE_Num;

      //console.log("de: ", de);

      console.log("event.column.colId: ", event.column.colId);

      //co = Column_CO_Map_Regimen[event.column.colId];

      //de_co = de + "-" + co;
      de_co = event.data[event.column.colId + "_UID"];

      console.log("de_co: ", de_co);

      de = de_co.split("-")[0];
      co = de_co.split("-")[1];

      let numberOfPatientsInTheCurrentMonth =
        (event.data.Number_of_Patients_as_of_Last_Month === ""
          ? 0
          : parseInt(event.data.Number_of_Patients_as_of_Last_Month)) +
        (event.data.No_of_New_Patients_in_the_Current_Month === ""
          ? 0
          : parseInt(event.data.No_of_New_Patients_in_the_Current_Month)) -
        (event.data.No_of_Attritions_from_the_Last_Month === ""
          ? 0
          : parseInt(event.data.No_of_Attritions_from_the_Last_Month));

      setNumberOfPatientsInTheCurrentMonth(
        event.data.id,
        numberOfPatientsInTheCurrentMonth
      );

      // updating cell value
      if (obj[de_co] === undefined) {
        console.log(
          `Value not found for dataElement-categoryOptionCombo (${de_co}). So new index adding in data object.`
        );
        obj[de_co] = {
          dataElement: de,
          categoryOptionCombo: co,
          value: newValue,
        };
      } else {
        obj[de_co].value = newValue;
      }
    } catch (error) {
      console.log("error: ", error);
      showCritical({ Msg: error });
    }
  };

  //Creating dataValues 0 for others legends in the same row
  const setValueZeroToOtherLegends = (dE_Num, legendAvailable) => {
    //console.log('setValueZeroToOtherLegends');
    Object.keys(Legends).forEach((key) => {
      if (legendAvailable != key) {
        let co = Legends[key];
        let de_co = dE_Num + "-" + co;
        //console.log('de_co: ', de_co);
        obj[de_co] = {
          dataElement: dE_Num,
          categoryOptionCombo: co,
          value: "0",
        };
      }
    });
  };

  const saveHandler = async () => {
    console.log("obj: ", obj);

    if (!isDirty) {
      return;
    }

    if (gridRef.current !== null) {
      const rows = gridRef.current.props.rowData;

      countAllProductValue = rows.length;

      countNonZeroValue = rows.filter(
        (o) => o.Ending_Balance_Physical != 0
      ).length;

      totalLossValue = getTotalLossValue(rows);
      totalBalanceValue = getTotalBalanceValue(rows);
    }

    setIsLoading(true);

    try {
      const dataValues = [];

      for (let k in obj) {
        //console.log('obj[k]: ', obj[k].value);
        if (obj[k].value) {
          dataValues.push({
            dataElement: obj[k].dataElement,
            categoryOptionCombo: obj[k].categoryOptionCombo,
            value: obj[k].value,
          });
        } else {
          dataValues.push({
            dataElement: obj[k].dataElement,
            categoryOptionCombo: obj[k].categoryOptionCombo,
            deleted: true,
          });
        }
      }

      const de_ReceiveDate = de_co_ReceiveDate.split("-")[0];
      const co_ReceiveDate = de_co_ReceiveDate.split("-")[1];

      dataValues.push({
        dataElement: de_ReceiveDate,
        categoryOptionCombo: co_ReceiveDate,
        value: reportReceivedDate,
      });

      let year = reportReceivedDate.split("-")[0];
      let month = reportReceivedDate.split("-")[1];
      let day = reportReceivedDate.split("-")[2];

      let receiveDt = new Date(year, month, day);

      let nextMonthYear = getNextPeriod(props.selectedMonthYear);

      let nxtYear = parseInt(nextMonthYear.substring(0, 4));
      let nxtMonth = parseInt(nextMonthYear.substring(4));

      let lastSubmissionDt = new Date(nxtYear, nxtMonth, 10);

      let timelyStatus = "";
      let lateStatus = "";

      if (receiveDt <= lastSubmissionDt) {
        timelyStatus = "1";
        lateStatus = "0";
      } else {
        timelyStatus = "0";
        lateStatus = "1";
      }

      const de_ReportTimelyStatus = de_co_ReportTimelyStatus.split("-")[0];
      const co_ReportTimelyStatus = de_co_ReportTimelyStatus.split("-")[1];

      dataValues.push({
        dataElement: de_ReportTimelyStatus,
        categoryOptionCombo: co_ReportTimelyStatus,
        value: timelyStatus,
      });

      const de_ReportLateStatus = de_co_ReportLateStatus.split("-")[0];
      const co_ReportLateStatus = de_co_ReportLateStatus.split("-")[1];

      dataValues.push({
        dataElement: de_ReportLateStatus,
        categoryOptionCombo: co_ReportLateStatus,
        value: lateStatus,
      });

      const de_totalLoss = de_co_totalLoss.split("-")[0];
      const co_totalLoss = de_co_totalLoss.split("-")[1];

      if (gridRef.current !== null) {
        dataValues.push({
          dataElement: de_totalLoss,
          categoryOptionCombo: co_totalLoss,
          value: totalLossValue,
        });

        const de_totalBalance = de_co_totalBalance.split("-")[0];
        const co_totalBalance = de_co_totalBalance.split("-")[1];

        dataValues.push({
          dataElement: de_totalBalance,
          categoryOptionCombo: co_totalBalance,
          value: totalBalanceValue,
        });

        const de_countAllProduct = de_co_countAllProduct.split("-")[0];
        const co_countAllProduct = de_co_countAllProduct.split("-")[1];

        dataValues.push({
          dataElement: de_countAllProduct,
          categoryOptionCombo: co_countAllProduct,
          value: countAllProductValue,
        });

        const de_countNonZero = de_co_countNonZero.split("-")[0];
        const co_countNonZero = de_co_countNonZero.split("-")[1];

        dataValues.push({
          dataElement: de_countNonZero,
          categoryOptionCombo: co_countNonZero,
          value: countNonZeroValue,
        });
      }

      // Inserting/Updating DataValues
      const dataValuesMutation = {
        resource: "dataValueSets",
        type: "create",
        data: {
          orgUnit: props.selectedOrgUnit.id,
          period: props.selectedMonthYear,
          dataValues: dataValues,
        },
      };

      console.log("dataValuesMutation: ", dataValuesMutation);

      const mutationPromise = engine.mutate(dataValuesMutation);
      const mutationData = await mutationPromise;
      console.log("DataValues Inserted/Updated: ", mutationData);

      showSuccess({ Msg: "Data Saved Successfully" });

      setIsLoading(false);
      setIsDirty(false);
    } catch (error) {
      console.log("error: ", error);
      showCritical({ Msg: error });
    }
  };

  const submitHandler = async () => {
    setConfirmSubmit(true);
  };

  const submit = async () => {
    console.log("obj: ", obj);

    let rows = {};

    if (gridRef.current !== null) {
      rows = gridRef.current.props.rowData;
      countAllProductValue = rows.length;
      countNonZeroValue = rows.filter(
        (o) => o.Ending_Balance_Physical != 0
      ).length;

      if (!isSetAdjustMentType(rows)) {
        setConfirmSubmit(false);
        return;
      }

      if (!isDataValidated(rows)) {
        return;
      }

      totalLossValue = getTotalLossValue(rows);
      console.log("totalLossValue: ", totalLossValue);
      totalBalanceValue = getTotalBalanceValue(rows);
      console.log("totalBalanceValue: ", totalBalanceValue);
    }

    setIsLoading(true);

    try {
      const dataValues = [];

      for (let k in obj) {
        //console.log('obj[k]: ', obj[k].value);
        if (obj[k].value) {
          dataValues.push({
            dataElement: obj[k].dataElement,
            categoryOptionCombo: obj[k].categoryOptionCombo,
            value: obj[k].value,
          });
        } else {
          dataValues.push({
            dataElement: obj[k].dataElement,
            categoryOptionCombo: obj[k].categoryOptionCombo,
            deleted: true,
          });
        }
      }

      const de_ReceiveDate = de_co_ReceiveDate.split("-")[0];
      const co_ReceiveDate = de_co_ReceiveDate.split("-")[1];

      dataValues.push({
        dataElement: de_ReceiveDate,
        categoryOptionCombo: co_ReceiveDate,
        value: reportReceivedDate,
      });

      let year = reportReceivedDate.split("-")[0];
      let month = reportReceivedDate.split("-")[1];
      let day = reportReceivedDate.split("-")[2];

      let receiveDt = new Date(year, month, day);

      let nextMonthYear = getNextPeriod(props.selectedMonthYear);

      let nxtYear = parseInt(nextMonthYear.substring(0, 4));
      let nxtMonth = parseInt(nextMonthYear.substring(4));

      let lastSubmissionDt = new Date(nxtYear, nxtMonth, 10);

      let timelyStatus = "";
      let lateStatus = "";

      if (receiveDt <= lastSubmissionDt) {
        timelyStatus = "1";
        lateStatus = "0";
      } else {
        timelyStatus = "0";
        lateStatus = "1";
      }

      const de_ReportTimelyStatus = de_co_ReportTimelyStatus.split("-")[0];
      const co_ReportTimelyStatus = de_co_ReportTimelyStatus.split("-")[1];

      dataValues.push({
        dataElement: de_ReportTimelyStatus,
        categoryOptionCombo: co_ReportTimelyStatus,
        value: timelyStatus,
      });

      const de_ReportLateStatus = de_co_ReportLateStatus.split("-")[0];
      const co_ReportLateStatus = de_co_ReportLateStatus.split("-")[1];

      dataValues.push({
        dataElement: de_ReportLateStatus,
        categoryOptionCombo: co_ReportLateStatus,
        value: lateStatus,
      });

      const de_totalLoss = de_co_totalLoss.split("-")[0];
      const co_totalLoss = de_co_totalLoss.split("-")[1];

      if (gridRef.current !== null) {
        dataValues.push({
          dataElement: de_totalLoss,
          categoryOptionCombo: co_totalLoss,
          value: totalLossValue,
        });

        const de_totalBalance = de_co_totalBalance.split("-")[0];
        const co_totalBalance = de_co_totalBalance.split("-")[1];

        dataValues.push({
          dataElement: de_totalBalance,
          categoryOptionCombo: co_totalBalance,
          value: totalBalanceValue,
        });

        const de_countAllProduct = de_co_countAllProduct.split("-")[0];
        const co_countAllProduct = de_co_countAllProduct.split("-")[1];

        dataValues.push({
          dataElement: de_countAllProduct,
          categoryOptionCombo: co_countAllProduct,
          value: countAllProductValue,
        });

        const de_countNonZero = de_co_countNonZero.split("-")[0];
        const co_countNonZero = de_co_countNonZero.split("-")[1];

        dataValues.push({
          dataElement: de_countNonZero,
          categoryOptionCombo: co_countNonZero,
          value: countNonZeroValue,
        });
      }

      // Inserting/Updating DataValues
      const dataValuesMutation = {
        resource: "dataValueSets",
        type: "create",
        data: {
          orgUnit: props.selectedOrgUnit.id,
          period: props.selectedMonthYear,
          dataValues: dataValues,
        },
      };

      console.log("dataValuesMutation: ", dataValuesMutation);

      const mutationPromise = engine.mutate(dataValuesMutation);
      const mutationData = await mutationPromise;
      console.log("DataValues Inserted/Updated: ", mutationData);

      ///////////////////////////////////////////////////////////
      // Inserting/Updating DataValues for Next Month ( Pre and PrePre )
      const dataValuesNextMonth = getQueryForNextMonth(rows);

      const dataValuesNextMonthMutation = {
        resource: "dataValueSets",
        type: "create",
        data: {
          orgUnit: props.selectedOrgUnit.id,
          period: getNextPeriod(props.selectedMonthYear),
          dataValues: dataValuesNextMonth,
        },
      };

      console.log("dataValuesNextMonthMutation: ", dataValuesNextMonthMutation);

      const mutationNextMonthPromise = engine.mutate(
        dataValuesNextMonthMutation
      );
      const mutationNextMonthData = await mutationNextMonthPromise;
      console.log(
        "DataValues Next Month Inserted/Updated: ",
        mutationNextMonthData
      );
      ///////////////////////////////////////////////////////////

      // Updating dataSet Registration
      mutationDatasetRegJson.data.completeDataSetRegistrations[0].organisationUnit =
        props.selectedOrgUnit.id;
      mutationDatasetRegJson.data.completeDataSetRegistrations[0].period =
        props.selectedMonthYear;
      mutationDatasetRegJson.data.completeDataSetRegistrations[0].dataSet =
        props.artMutationData.ARTDataset;
      mutationDatasetRegJson.data.completeDataSetRegistrations[0].completed = true;

      console.log("mutationDatasetRegJson: ", mutationDatasetRegJson);

      const dataSetRegPromis = engine.mutate(mutationDatasetRegJson);
      const dataSetRegistered = await dataSetRegPromis;
      console.log("DataSet Registered: ", dataSetRegistered);

      showSuccess({ Msg: "Data Submitted Successfully" });

      setIsLoading(false);
      setIsDirty(false);
      props.backToFacilitylist("orgUnit");
    } catch (error) {
      console.log("error: ", error);
      showCritical({ Msg: error });
    }
  };

  const confirmSubmitHandler = async () => {
    submit();
  };

  const noConfirmSubmitHandler = async () => {
    setConfirmSubmit(false);
  };

  const backToHandler = async () => {
    if (isDirty) {
      setConfirmBackTo(true);
    } else {
      props.backToFacilitylist("orgUnit");
    }
  };

  const confirmBackToHandler = async () => {
    props.backToFacilitylist("orgUnit");
  };

  const noConfirmBackToHandler = async () => {
    setConfirmBackTo(false);
  };

  const setAMC = useCallback((id, value) => {
    let rowNode = gridRef.current.api.getRowNode(id);
    rowNode.setDataValue("AMC", value);
  }, []);

  const setMOS = useCallback((id, value) => {
    let rowNode = gridRef.current.api.getRowNode(id);
    rowNode.setDataValue("MOS", value);
  }, []);

  const setEndBalanceBook = useCallback((id, value) => {
    let rowNode = gridRef.current.api.getRowNode(id);
    rowNode.setDataValue("Ending_Balance_Book", value);
  }, []);

  const setNumberOfPatientsInTheCurrentMonth = useCallback((id, value) => {
    let rowNode = gridRefReg.current.api.getRowNode(id);
    rowNode.setDataValue("Number_of_Patients_in_the_Current_Month", value);
  }, []);

  const isDataValidated = (rows) => {
    const errorList = [];
    //let bNotSetAdjustMentType = false;

    rows.forEach((row) => {
      let result =
        (row.Beginning_Balance === "" ? 0 : parseInt(row.Beginning_Balance)) +
        (row.Quantity_received === "" ? 0 : parseInt(row.Quantity_received)) -
        (row.Quantity_Issued === "" ? 0 : parseInt(row.Quantity_Issued)) -
        (row.Losses === "" ? 0 : parseInt(row.Losses)) +
        (row.Adjustments === "" ? 0 : parseInt(row.Adjustments)) -
        (row.Ending_Balance_Physical === ""
          ? 0
          : parseInt(row.Ending_Balance_Physical));
      let EndBalanceShouldBe =
        (row.Beginning_Balance === "" ? 0 : parseInt(row.Beginning_Balance)) +
        (row.Quantity_received === "" ? 0 : parseInt(row.Quantity_received)) -
        (row.Quantity_Issued === "" ? 0 : parseInt(row.Quantity_Issued)) -
        (row.Losses === "" ? 0 : parseInt(row.Losses)) +
        (row.Adjustments === "" ? 0 : parseInt(row.Adjustments));

      // if(row.Adjustments > 0 && row.Adjustment_Type === "0"){
      //   //setAdjustmentTypeError(true);
      //   //showCritical({ Msg: 'Please set the adjustment type for rows yellow colored.' });
      //   bNotSetAdjustMentType = true;
      // }

      if (result !== 0) {
        errorList.push({
          Code: row.Code,
          ProductName: row.Product_Description_Or_Specifications,
          Result: result,
          EndBalanceShouldBe: EndBalanceShouldBe,
        });
      }
    });

    setErrors(errorList);

    // if (errorList.length > 0) {
    //   setRender(true);
    //   return false;
    // }

    return true;
  };

  const isSetAdjustMentType = (rows) => {
    let bSetAdjustMentType = true;

    for (let i = 0; i < rows.length; i++) {
      if (
        Math.abs(rows[i].Adjustments) > 0 &&
        rows[i].Adjustment_Type === "0"
      ) {
        console.log(
          "Math.abs(rows[i].Adjustments): ",
          Math.abs(rows[i].Adjustments)
        );
        console.log("rows[i].Adjustment_Type: ", rows[i].Adjustment_Type);
        bSetAdjustMentType = false;
        showCritical({
          Msg: "Please set the adjustment type for the rows yellow colored.",
        });
        break;
      }
    }

    return bSetAdjustMentType;
  };

  const getQueryForNextMonth = (rows) => {
    const queryForNextMonth = [];
    rows.forEach((row) => {
      if (row.Quantity_Issued) {
        queryForNextMonth.push({
          dataElement: row.dE_Num,
          categoryOptionCombo: Column_CO_Map.Quantity_Issued_PreMonth,
          value: row.Quantity_Issued,
        });
      } else {
        queryForNextMonth.push({
          dataElement: row.dE_Num,
          categoryOptionCombo: Column_CO_Map.Quantity_Issued_PreMonth,
          deleted: true,
        });
      }

      if (row.Quantity_Issued_PreMonth) {
        queryForNextMonth.push({
          dataElement: row.dE_Num,
          categoryOptionCombo: Column_CO_Map.Quantity_Issued_PrePreMonth,
          value: row.Quantity_Issued_PreMonth,
        });
      } else {
        queryForNextMonth.push({
          dataElement: row.dE_Num,
          categoryOptionCombo: Column_CO_Map.Quantity_Issued_PrePreMonth,
          deleted: true,
        });
      }
    });
    return queryForNextMonth;
  };

  const getTotalLossValue = (rows) => {
    let totalLossVal = 0;
    rows.forEach((row) => {
      totalLossVal =
        totalLossVal +
        (row.Losses === "" ? 0 : parseInt(row.Losses)) *
          (row.Price === "" ? 0 : row.Price);
    });
    return Math.round(totalLossVal);
  };

  const getTotalBalanceValue = (rows) => {
    let totalBalanceVal = 0;
    rows.forEach((row) => {
      totalBalanceVal =
        totalBalanceVal +
        (row.Ending_Balance_Physical === ""
          ? 0
          : parseInt(row.Ending_Balance_Physical)) *
          row.Price;
    });

    return Math.round(totalBalanceVal);
  };

  const closeModalHandler = () => {
    setRender(false);
  };

  const GetSortOrder = () => {
    return function (a, b) {
      if (a.startValue > b.startValue) {
        return 1;
      } else if (a.startValue < b.startValue) {
        return -1;
      }
      return 0;
    };
  };

  const reportReceivedDateHandler = ({ value }) => {
    setReportReceivedDate(value);
    setIsDirty(true);
  };

  const getPreviousPeriod = (ym) => {
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    if (month == 1) {
      month = 12;
      year = year - 1;
    } else {
      month = month - 1;
    }

    ym = year + month.toString().padStart(2, "0");

    return ym;
  };

  const getNextPeriod = (ym) => {
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    if (month == 12) {
      month = 1;
      year = year + 1;
    } else {
      month = month + 1;
    }

    ym = year + month.toString().padStart(2, "0");

    return ym;
  };

  const getPreviousMonthDataValues = async () => {
    console.log(
      "getPreviousPeriod: ",
      getPreviousPeriod(props.selectedMonthYear)
    );

    try {
      dataValueSetsQueryPrevMonth = {
        dataValueSets: {
          resource: `dataValueSets.json?dataSet=${
            props.artMutationData.ARTDataset
          }&orgUnit=${props.selectedOrgUnit.id}&period=${getPreviousPeriod(
            props.selectedMonthYear
          )}`,
        },
      };

      console.log("dataValueSetsQueryPrevMonth: ", dataValueSetsQueryPrevMonth);
      const dataValueSetsResultPrevMonth = await engine.query(
        dataValueSetsQueryPrevMonth
      );
      console.log(
        "dataValueSetsResultPrevMonth: ",
        dataValueSetsResultPrevMonth
      );

      let previousMonthClosingBalance = [];
      if (
        dataValueSetsResultPrevMonth &&
        dataValueSetsResultPrevMonth.dataValueSets.dataValues
      ) {
        // "gdfxU93ELmJ" = Ending_Balance_Physical
        previousMonthClosingBalance =
          dataValueSetsResultPrevMonth.dataValueSets.dataValues.filter(
            (x) => x.categoryOptionCombo === "gdfxU93ELmJ"
          );
      }

      return previousMonthClosingBalance;
    } catch (error) {
      console.log("getPreviousMonthDataValues error: ", error);
    }
  };

  const gridConfig = {
    rowClassRules: {
      "row-fail": (params) => {
        const row = params.data;
        let result =
          (row.Beginning_Balance === "" ? 0 : parseInt(row.Beginning_Balance)) +
          (row.Quantity_received === "" ? 0 : parseInt(row.Quantity_received)) -
          (row.Quantity_Issued === "" ? 0 : parseInt(row.Quantity_Issued)) -
          (row.Losses === "" ? 0 : parseInt(row.Losses)) +
          (row.Adjustments === "" ? 0 : parseInt(row.Adjustments)) -
          (row.Ending_Balance_Physical === ""
            ? 0
            : parseInt(row.Ending_Balance_Physical));

        return result !== 0;
      },
      "row-fail-adj": (params) => {
        const row = params.data;
        return Math.abs(row.Adjustments) > 0 && row.Adjustment_Type === "0";
      },
      "row-pass": (params) => {
        const row = params.data;
        let result =
          (row.Beginning_Balance === "" ? 0 : parseInt(row.Beginning_Balance)) +
          (row.Quantity_received === "" ? 0 : parseInt(row.Quantity_received)) -
          (row.Quantity_Issued === "" ? 0 : parseInt(row.Quantity_Issued)) -
          (row.Losses === "" ? 0 : parseInt(row.Losses)) +
          (row.Adjustments === "" ? 0 : parseInt(row.Adjustments)) -
          (row.Ending_Balance_Physical === ""
            ? 0
            : parseInt(row.Ending_Balance_Physical));

        return result === 0;
      },
    },
  };

  const gridConfigReg = {
    rowClassRules: {
      "row-fail": (params) => {
        const row = params.data;

        let result =
          row.Number_of_Patients_in_the_Current_Month === ""
            ? 0
            : parseInt(row.Number_of_Patients_in_the_Current_Month);

        return result < 0;
      },
      "row-pass": (params) => {
        const row = params.data;
        let result =
        row.Number_of_Patients_in_the_Current_Month === ""
          ? 0
          : parseInt(row.Number_of_Patients_in_the_Current_Month);

        return result >= 0;
      },
    },
  };

  const [tab1, setTab1] = useState(true);
  const [tab2, setTab2] = useState(false);

  const logClick = () => {
    setTab1(true);
    setTab2(false);
    saveHandler();
  };

  const regClick = () => {
    setTab2(true);
    setTab1(false);
    saveHandler();
  };

  return (
    <div>
      {isDirty && (
        <div
          style={{
            position: "fixed",
            right: 80,
            top: 50,
            zIndex: 1000,
            backgroundColor: "#FDFD96",
            color: "#FF6961",
            border: "1px solid #FF6961",
            padding: 5,
          }}
        >
          You changed data, save before leaving the page
        </div>
      )}

      {render && (
        <ErrorListModal errors={errors} closeModalHandler={closeModalHandler} />
      )}

      <div style={{ paddingBottom: 10, paddingTop: 10 }}>
        <Button
          className="backToListBtn"
          name="Primary button"
          onClick={backToHandler}
          secondary
          value="default"
          loading
        >
          Back to Facility List
        </Button>
      </div>

      {confirmBackTo && isDirty && (
        <Modal small>
          <ModalTitle>Back to List Confirmation!</ModalTitle>
          <ModalContent>
            You have unsaved changes which will be lost. Continue?
          </ModalContent>
          <ModalActions>
            <ButtonStrip end>
              <Button onClick={noConfirmBackToHandler} secondary>
                NO
              </Button>
              <Button onClick={confirmBackToHandler} primary>
                YES
              </Button>
            </ButtonStrip>
          </ModalActions>
        </Modal>
      )}

      <table className="table" id="table_Container">
        <tbody>
          <tr>
            <td>
              <strong>Facility:</strong>
            </td>
            <td>{props.selectedOrgUnit.displayName}</td>
            <td>
              <strong>Month-Year:</strong>
            </td>
            <td>
              {" "}
              {props.selectedOrgUnit.period !== "" &&
                moment(
                  props.selectedOrgUnit.period.substr(0, 4) +
                    "-" +
                    props.selectedOrgUnit.period.substr(4, 2) +
                    "-01"
                ).format("MMMM-YYYY")}
            </td>
            <td>
              <strong>Report Received Date:</strong>
            </td>
            <td>
              <InputField
                name="defaultName1"
                onChange={reportReceivedDateHandler}
                value={`${reportReceivedDate}`}
                type="date"
                small
                disabled={readOnly}
                required
                error={`${reportReceivedDate}` == ""}
                dense
              />
            </td>
            <td>
              {/* {isDirty ? (
                <span
                  style={{ color: "red", border: "1px solid red", padding: 5 }}
                >
                  You changed data, save before leaving the page
                </span>
              ) : (
                ""
              )} */}
            </td>
          </tr>
        </tbody>
      </table>

      <div className="tabs">
        <ol className="tab-list">
          <li
            className={"tab-list-item" + (tab1 ? " tab-list-active" : "")}
            onClick={logClick}
          >
            Log
          </li>
          <li
            className={"tab-list-item" + (tab2 ? " tab-list-active" : "")}
            onClick={regClick}
          >
            Reg
          </li>
        </ol>
        <div className="tab-content-log">
          <div
            className="ag-theme-alpine"
            style={{
              width: "100%",
              height: 500,
              display: tab1 ? "block" : "none",
            }}
          >
            <AgGridReact
              ref={gridRef} // Ref for accessing Grid's API
              rowData={rowData} // Row Data for Rows
              columnDefs={columnDefs} // Column Defs for Columns
              defaultColDef={defaultColDef} // Default Column Properties
              animateRows={true} // Optional - set to 'true' to have rows animate when sorted
              //rowSelection="single" // Options - allows click selection of rows
              onCellClicked={cellClickedListener} // Optional - registering for Grid Event
              headerHeight={120}
              getRowId={getRowId}
              onCellValueChanged={cellValueChangedHandler}
              enterMovesDown={true}
              enterMovesDownAfterEdit={true}
              gridOptions={gridConfig}
            />
          </div>
        </div>
        <div class="tab-content-reg">
          <div
            className="ag-theme-alpine"
            style={{
              width: "100%",
              height: 500,
              display: tab2 ? "block" : "none",
            }}
          >
            <AgGridReact
              ref={gridRefReg} // Ref for accessing Grid's API
              rowData={rowDataReg} // Row Data for Rows
              columnDefs={columnDefsReg} // Column Defs for Columns
              defaultColDef={defaultColDefRegimen} // Default Column Properties
              animateRows={true} // Optional - set to 'true' to have rows animate when sorted
              headerHeight={90}
              getRowId={getRowIdRegimen}
              onCellValueChanged={cellValueChangedHandlerRegimen}
              enterMovesDown={true}
              enterMovesDownAfterEdit={true}
              gridOptions={gridConfigReg}
            />
          </div>
        </div>
      </div>

      {/* <Tabs saveHandler={saveHandler}>
        <div label="Log"></div>

        <div label="Reg"></div>
      </Tabs> */}

      <center>
        {confirmSubmit && (
          <Modal small>
            <ModalTitle>Submit Confirmation!</ModalTitle>
            <ModalContent>
              Do you want to Submit the Report? You will not be able to change
              it afterwards.
            </ModalContent>
            <ModalActions>
              <ButtonStrip end>
                <Button onClick={noConfirmSubmitHandler} secondary>
                  NO
                </Button>
                <Button onClick={confirmSubmitHandler} primary>
                  YES
                </Button>
              </ButtonStrip>
            </ModalActions>
          </Modal>
        )}
        <div
          style={{
            paddingBottom: 10,
            paddingTop: 10,
            display: props.completed ? "none" : "block",
          }}
        >
          <Button
            className="saveArvBtn"
            name="Primary button"
            onClick={saveHandler}
            primary
            value="default"
            disabled={isLoading || !isDirty}
            large
          >
            {!isLoading && "Save"}
            {isLoading && "Saving.."}
          </Button>
          {"   "}
          <Button
            name="Primary button"
            onClick={submitHandler}
            primary
            value="default"
            large
          >
            Submit
          </Button>
        </div>
      </center>
    </div>
  );
};

export default ArvViewEntryEdit;
