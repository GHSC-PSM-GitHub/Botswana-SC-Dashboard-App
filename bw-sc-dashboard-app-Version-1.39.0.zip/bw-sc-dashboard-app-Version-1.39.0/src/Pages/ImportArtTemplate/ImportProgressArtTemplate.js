import React, { Component } from "react";
import Dropzone from "react-dropzone";
import styles from "../Pages.module.css";
import StatusTemplate from "./statusTemplate";
import {
  Menu,
  MenuItem,
  Button,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableRowHead,
  TableCellHead,
  TableCell,
  CircularLoader,
  AlertBar,
} from "@dhis2/ui-core";
import Constant from "../../helpers/constants";

const LIST_ICON_WARNING = (
  <Button
    dataTest="dhis2-uicore-button"
    icon={
      <svg viewBox="0 0 48 48" width="30px" height="30px">
        <path
          fill="#ffc107"
          d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"
        />
        <path
          fill="#ccff90"
          d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"
        />
      </svg>
    }
    name="Icon button"
    type="button"
    value="default"
    className={styles.list_icon_btn}
  />
);
const LIST_ICON_SUCCESS = (
  <Button
    dataTest="dhis2-uicore-button"
    icon={
      <svg viewBox="0 0 48 48" width="30px" height="30px">
        <path
          fill="#28a745"
          d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"
        />
        <path
          fill="#ccff90"
          d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"
        />
      </svg>
    }
    name="Icon button"
    type="button"
    value="default"
    className={styles.list_icon_btn}
  />
);

const LIST_ICON_WARNING_BIG_SIZE = (
  <Button
    dataTest="dhis2-uicore-button"
    icon={
      <svg viewBox="0 0 48 48" width="50px" height="50px">
        <path
          fill="#ffc107"
          d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"
        />
        <path
          fill="#ccff90"
          d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"
        />
      </svg>
    }
    name="Icon button"
    type="button"
    value="default"
    className={styles.list_icon_btn}
  />
);
const LIST_ICON_SUCCESS_BIG_SIZE = (
  <Button
    dataTest="dhis2-uicore-button"
    icon={
      <svg viewBox="0 0 48 48" width="50px" height="50px">
        <path
          fill="#28a745"
          d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"
        />
        <path
          fill="#ccff90"
          d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"
        />
      </svg>
    }
    name="Icon button"
    type="button"
    value="default"
    className={styles.list_icon_btn}
  />
);

const LIST_ICON_FAILURE_BIG_SIZE = (
  <Button
    dataTest="dhis2-uicore-button"
    icon={
      <svg viewBox="0 0 24 24" width="40px" height="40px">
        <path
          fill="#FF0000"
          d="M16.971 0h-9.942l-7.029 7.029v9.941l7.029 7.03h9.941l7.03-7.029v-9.942l-7.029-7.029zm-1.402 16.945l-3.554-3.521-3.518 3.568-1.418-1.418 3.507-3.566-3.586-3.472 1.418-1.417 3.581 3.458 3.539-3.583 1.431 1.431-3.535 3.568 3.566 3.522-1.431 1.43z"
        />
      </svg>
    }
    name="Icon button"
    type="button"
    value="default"
    className={styles.list_icon_btn}
  />
);

class ImportProgressArtTemplate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      activeTab: "Log",
    };
    this.changeTab = this.changeTab.bind(this);
  }

  changeTab(activeTab) {
    this.setState({ activeTab });
  }

  componentWillMount() {
    this.setState({ loading: this.props.loading });
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.state.loading &&
      this.props.logItems &&
      this.props.logItems.length &&
      this.props.logGridDataValues.length > 0 &&
      this.props.AMCs.length > 0 &&
      this.props.MOSs.length > 0 &&
      this.props.resInsertData &&
      this.props.resultStatus &&
      this.props.resultStatus
    ) {
      this.setState({ loading: false });
    }
  }

  getTableHeading = (logItems, type = "grid") => {
    if (type == "grid") {
      return (
        <TableRowHead dataTest="dhis2-uicore-tablerow">
          <TableCellHead dataTest="dhis2-uicore-tablecellhead">
            SI#
          </TableCellHead>
          {Constant.TABLE_HEADING_LIST.map((col, key) => {
            return (
              <TableCellHead key={key} dataTest="dhis2-uicore-tablecellhead">
                {col}
              </TableCellHead>
            );
          })}
        </TableRowHead>
      );
    } else {
      return (
        <TableRowHead dataTest="dhis2-uicore-tablerow">
          {["Sl#", "Product Code", "Product Description / Specifications"].map(
            (col, key) => {
              return (
                <TableCellHead key={key} dataTest="dhis2-uicore-tablecellhead">
                  {col}
                </TableCellHead>
              );
            }
          )}
        </TableRowHead>
      );
    }
  };

  getRegTableHeading = (logItems, type = "grid") => {
    let columnList =
      logItems && logItems[0]
        ? Object.keys(logItems[0])
        : [
            "Regimen",
            "Therapy Line",
            "Number of Patients as of Last Month",
            "No. of Attritions from the Last Month",
            "Number of Patients in the Current Month",
            "No. of New Patients in the Current Month",
          ];
    return (
      <TableRowHead dataTest="dhis2-uicore-tablerow">
        <TableCellHead dataTest="dhis2-uicore-tablecellhead">SI#</TableCellHead>
        {columnList.map((col, key) => {
          return (
            <TableCellHead key={key} dataTest="dhis2-uicore-tablecellhead">
              {col}
            </TableCellHead>
          );
        })}
      </TableRowHead>
    );
  };

  getTableList = (
    logItems,
    conflictKeyList,
    regTemplateEmptyKeys,
    type = "grid"
  ) => {
    if (logItems.length == 0) {
      return;
    }

    if (
      logItems.length > 0 &&
      this.props.AMCs.length > 0 &&
      this.props.MOSs.length > 0
    ) {
      if (type == "grid") {
        logItems.map((item, i) => {
          if (!regTemplateEmptyKeys.includes(logItems[i]["__EMPTY"])) {
            const newItem = this.props.AMCs.filter((itm) => {
              return itm.ItemCode == item["__EMPTY"];
            });
            logItems[i]["__EMPTY_16"] = newItem[0].AMC;
          }
        });

        logItems.map((item, i) => {
          if (!regTemplateEmptyKeys.includes(logItems[i]["__EMPTY"])) {
            const newItem = this.props.MOSs.filter((itm) => {
              return itm.ItemCode == item["__EMPTY"];
            });
            logItems[i]["MOS"] = newItem[0].MOS;
          }
        });

        let from_index = 0;
        let to_index = logItems.length;
        let columnList = [
          "__EMPTY",
          "__EMPTY_1",
          "__EMPTY_2",
          "__EMPTY_3",
          "__EMPTY_4",
          "__EMPTY_5",
          "__EMPTY_6",
          "__EMPTY_7",
          "__EMPTY_8",
          "__EMPTY_9",
          "__EMPTY_10",
          "__EMPTY_11",
          "__EMPTY_12",
          "__EMPTY_13",
          "__EMPTY_14",
          "__EMPTY_15",
          "__EMPTY_16",
          "MOS",
          "__EMPTY_17",
        ];
        logItems.slice(0, 10).map((item, i) => {
          if (item["__EMPTY"] == "Code") {
            columnList = Object.keys(item);
            from_index = i + 3;
          }
        });

        return logItems.slice(from_index, to_index).map((item, table_row) => {
          return (
            <TableRow dataTest="dhis2-uicore-tablerow">
              <TableCell dataTest="dhis2-uicore-tablecell">
                {table_row + 1}
              </TableCell>
              {columnList.map((col, col_key) => {
                let keyId = null;
                if (item[col] && item[col].key) {
                  keyId = item[col].key.split("-")[0];
                }

                if (
                  ["__EMPTY", "__EMPTY_1"].includes(col) &&
                  regTemplateEmptyKeys &&
                  regTemplateEmptyKeys.includes(item["__EMPTY"])
                ) {
                  return (
                    <TableCell
                      key={col_key}
                      dataTest="dhis2-uicore-tablecell"
                      className={styles.cellColor}
                    >
                      {item[col]
                        ? item[col].key
                          ? item[col].value
                          : item[col]
                        : null}
                    </TableCell>
                  );
                } else {
                  return (
                    <TableCell
                      key={col_key}
                      dataTest="dhis2-uicore-tablecell"
                      className={
                        keyId && conflictKeyList.includes(keyId)
                          ? styles.cellColor
                          : null
                      }
                    >
                      {item[col]
                        ? item[col].key
                          ? item[col].value
                          : item[col]
                        : null}
                    </TableCell>
                  );
                }
              })}
            </TableRow>
          );
        });
      } else {
        return logItems.map((item, table_row) => {
          return (
            <TableRow key={table_row} dataTest="dhis2-uicore-tablerow">
              <TableCell dataTest="dhis2-uicore-tablecell">
                {table_row + 1}
              </TableCell>
              <TableCell dataTest="dhis2-uicore-tablecell">
                {item["__EMPTY"]}
              </TableCell>
              <TableCell dataTest="dhis2-uicore-tablecell">
                {item["__EMPTY_1"]}
              </TableCell>
            </TableRow>
          );
        });
      }
    }
  };

  getRegTableList = (
    regItems,
    conflictKeyList,
    regTemplateEmptyKeys,
    type = "grid"
  ) => {
    if (regItems.length == 0) {
      return;
    }
    if (
      regItems.length > 0 &&
      this.props.AMCs.length > 0 &&
      this.props.MOSs.length > 0
    ) {
      let regColumnList =
        regItems && regItems[0]
          ? Object.keys(regItems[0])
          : [
              "Regimen",
              "Therapy Line",
              "Number of Patients as of Last Month",
              "No. of Attritions from the Last Month",
              "Number of Patients in the Current Month",
              "No. of New Patients in the Current Month",
            ];

      return regItems.map((item, table_row) => {
        return (
          <TableRow dataTest="dhis2-uicore-tablerow">
            <TableCell dataTest="dhis2-uicore-tablecell">
              {table_row + 1}
            </TableCell>
            {regColumnList.map((col, col_key) => {
              let keyId = null;
              if (item[col] && item[col].key) {
                keyId = item[col].key.split("-")[0];
              }

              if (
                ["Regimen"].includes(col) &&
                regTemplateEmptyKeys &&
                regTemplateEmptyKeys.includes(item["Regimen"])
              ) {
                return (
                  <TableCell
                    key={col_key}
                    dataTest="dhis2-uicore-tablecell"
                    className={styles.cellColor}
                  >
                    {item[col]
                      ? item[col].key
                        ? item[col].value
                        : item[col]
                      : null}
                  </TableCell>
                );
              } else {
                return (
                  <TableCell
                    key={col_key}
                    dataTest="dhis2-uicore-tablecell"
                    className={
                      keyId && conflictKeyList.includes(keyId)
                        ? styles.cellColor
                        : null
                    }
                  >
                    {item[col]
                      ? item[col].key
                        ? item[col].value
                        : item[col]
                      : null}
                  </TableCell>
                );
              }
            })}
          </TableRow>
        );
      });
    }
  };

  render() {
    let activeTab = this.state.activeTab;
    const resultStatus = this.props.resultStatus;
    let status = null;
    if (resultStatus == "SUCCESS") {
      status = "SUCCESS";
    } else if (resultStatus == "WARNING" && !this.props.conflictStatus) {
      status = "WARNING";
    } else if (resultStatus == "WARNING" && this.props.conflictStatus) {
      status = "FAILURE";
    } else if (resultStatus == "ERROR") {
      status = "FAILURE";
    }

    return (
      <>
        <div className={styles.progressPanel}>
          {this.state.loading && (
            <center>
              <CircularLoader
                className={styles.loading_icon}
                dataTest="dhis2-uicore-circularloader"
                large
              />
            </center>
          )}
          <div className={styles.progressTabRow}>
            <div className={styles.progressTabLeftContainer}>
              <h2>Import ARV LMIS Report - Import Progress</h2>
              <p>
                Step 2 of 2: Import the Excel file data into DHIS2 and calculate
                AMC/MOS
              </p>
              <ul className={styles.progressPanelList}>
                {this.props.headingTitle.facilityName && (
                  <li>
                    {LIST_ICON_SUCCESS}
                    Excel template contains data for{" "}
                    {this.props.headingTitle.facilityName} -{" "}
                    {this.props.headingTitle.monthName}{" "}
                    {this.props.headingTitle.year}
                  </li>
                )}
                {this.props.logGridDataValues &&
                  this.props.logGridDataValues.length > 0 &&
                  this.props.regTemplateEmptyKeys.length == 0 && (
                    <li>
                      {LIST_ICON_SUCCESS}
                      Importing{" "}
                      {this.props.logGridDataValues &&
                      this.props.logGridDataValues.length
                        ? this.props.logGridDataValues.length
                        : "XXX"}{" "}
                      products
                    </li>
                  )}
                {this.props.logGridDataValues &&
                  this.props.logGridDataValues.length > 0 &&
                  this.props.regTemplateEmptyKeys.length > 0 && (
                    <li>
                      {LIST_ICON_WARNING}
                      Importing{" "}
                      {this.props.logGridDataValues &&
                      this.props.logGridDataValues.length
                        ? this.props.logGridDataValues.length +
                          this.props.missingProducts.length
                        : "XXX"}{" "}
                      products, {this.props.logGridDataValues.length} imported!
                    </li>
                  )}
                {status && (status == "WARNING" || status == "SUCCESS") && (
                  <li>
                    {status == "WARNING"
                      ? LIST_ICON_WARNING
                      : status == "SUCCESS"
                      ? LIST_ICON_SUCCESS
                      : null}
                    Import completed with{" "}
                    {status == "WARNING"
                      ? "warning"
                      : status == "SUCCESS"
                      ? "success"
                      : null}
                    !
                  </li>
                )}
                {status && (
                  <li>
                    {this.props.AMCs &&
                    this.props.AMCs.length > 0 &&
                    this.props.MOSs &&
                    this.props.MOSs.length > 0
                      ? LIST_ICON_SUCCESS
                      : LIST_ICON_WARNING}
                    Calculating AMC/MOS
                  </li>
                )}
              </ul>
            </div>
            {status && (
              <div className={styles.progressTabRightContainer}>
                <div className={styles.importSuccessBox}>
                  {status == "SUCCESS" && (
                    <label>{LIST_ICON_SUCCESS_BIG_SIZE} IMPORT SUCCESS! </label>
                  )}
                  {status == "WARNING" && (
                    <label>{LIST_ICON_WARNING_BIG_SIZE} IMPORT WARNING! </label>
                  )}
                  {status == "FAILURE" && (
                    <label>{LIST_ICON_FAILURE_BIG_SIZE} IMPORT FAILURE! </label>
                  )}
                  <br /> <br />
                  {status == "WARNING" && (
                    <label className={styles.upload_another_template}>
                      Review Import Summary below
                    </label>
                  )}
                  <br />
                  <label>
                    <Button
                      dataTest="dhis2-uicore-button"
                      large
                      name="Primary button"
                      onClick={this.props.redirectToFirstStep}
                      primary
                      type="button"
                      value="default"
                      className={styles.upload_another_template}
                    >
                      UPLOAD ANOTHER TEMPLATE
                    </Button>
                  </label>
                </div>
              </div>
            )}
          </div>
          <div className={styles.setting}>
            <ul className={styles.settingPages}>
              <li
                className={
                  activeTab == "Log" ? styles.activeTab : styles.settingPage
                }
                onClick={this.changeTab.bind(this, "Log")}
              >
                Log
              </li>
              <li
                className={
                  activeTab == "Reg" ? styles.activeTab : styles.settingPage
                }
                onClick={this.changeTab.bind(this, "Reg")}
              >
                Reg
              </li>
            </ul>
            <div className={styles.art_grid_tab}>
              {activeTab == "Log" && (
                <div className={styles.progress_art_grid_table}>
                  <Table dataTest="dhis2-uicore-table">
                    <TableHead dataTest="dhis2-uicore-tablehead">
                      {this.getTableHeading(this.props.logItems, "grid")}
                    </TableHead>
                    <TableBody dataTest="dhis2-uicore-tablebody">
                      {this.getTableList(
                        this.props.logGridDataValues,
                        this.props.conflictKeyList,
                        this.props.regTemplateEmptyKeys,
                        "grid"
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
              {activeTab == "Reg" && (
                <div className={styles.progress_art_grid_table}>
                  <Table dataTest="dhis2-uicore-table">
                    <TableHead dataTest="dhis2-uicore-tablehead">
                      {this.getRegTableHeading(
                        this.props.regGridDataValues,
                        "grid"
                      )}
                    </TableHead>
                    <TableBody dataTest="dhis2-uicore-tablebody">
                      {this.getRegTableList(
                        this.props.regGridDataValues,
                        this.props.conflictKeyList,
                        this.props.regTemplateEmptyKeys,
                        "grid"
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </div>

          <StatusTemplate
            resInsertData={this.props.resInsertData}
            resultStatus={this.props.resultStatus}
            fileName={this.props.fileName}
          />
        </div>
        {this.props.missingProducts &&
          this.props.missingProducts.length > 0 && (
            <div>
              <h2>Missing Products</h2>
              <div className={styles.progress_table}>
                <Table dataTest="dhis2-uicore-table">
                  <TableHead dataTest="dhis2-uicore-tablehead">
                    {this.getTableHeading(
                      this.props.logItems,
                      "missing-product"
                    )}
                  </TableHead>
                  <TableBody dataTest="dhis2-uicore-tablebody">
                    {this.getTableList(
                      this.props.missingProducts,
                      this.props.conflictKeyList,
                      this.props.regTemplateEmptyKeys,
                      "missing-product"
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
      </>
    );
  }
}

export default ImportProgressArtTemplate;
