import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Button,
  ButtonStrip,
  Modal,
  ModalTitle,
  ModalContent,
  ModalActions,
} from "@dhis2/ui";

import { AgGridReact } from "ag-grid-react"; // the AG Grid React Component

import "ag-grid-community/dist/styles/ag-grid.css"; // Core grid CSS, always needed
import "ag-grid-community/dist/styles/ag-theme-alpine.css"; // Optional theme CSS

export default function ErrorListModal(props) {

  const [isLoading, setLoading] = useState(false);

  const gridRef = useRef();
  const [rowData, setRowData] = useState();

  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo(() => ({
    sortable: true,
    // set every column width
    width: 100,
    // make every column editable
    editable: true,
    // make every column use 'text' filter by default
    filter: "agTextColumnFilter",

    //flex: 1,
    resizable: true,
    wrapText: true,
    //autoHeight: true,

  }));

  const [columnDefs, setColumnDefs] = useState([
    {
      field: "Code",
      editable: false
    },
    {
      field: "ProductName",
      minWidth: 300,
      editable: false
    },
    {
      field: "EndBalanceShouldBe",
      headerName: "End Balance should be",
      minWidth: 200,
      type: "rightAligned",
      editable: false
    },
  ]
  );

  const closeModalHandler = () => {
    props.closeModalHandler();
  };

  useEffect(() => {
    console.log('props.errors: ', props.errors);
    setRowData(props.errors);
  }, []);

  return (
    <>
      <Modal large>
        <ModalTitle>Invalid End Balance Product List</ModalTitle>
        <ModalContent>
          {isLoading && <LoadingSpinner />}
          <div className="ag-theme-alpine" style={{ height: 300, width: '100%'}}>
            <AgGridReact
              rowData={rowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              animateRows={true}
            />
          </div>
        </ModalContent>
        <ModalActions>
          <ButtonStrip end>
            <Button onClick={closeModalHandler} secondary>
              Close
            </Button>
          </ButtonStrip>
        </ModalActions>
      </Modal>
    </>
  );
}
