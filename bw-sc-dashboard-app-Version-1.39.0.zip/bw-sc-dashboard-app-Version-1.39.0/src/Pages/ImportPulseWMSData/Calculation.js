import { useEffect } from 'react'
import { useDataEngine } from '@dhis2/app-runtime'

const CalculateAmcMos = (props) => {

  const engine = useDataEngine()

  let cmsPhysicalStockRows = [];

  const getCMSPhysicalStock = async (monthStartDate) => {    
    const query = {
      "sqlViewsData": {
        "resource": `sqlViews/Er7zUJpw4YB/data.json?var=monthstartdate:${monthStartDate}&paging=false`
      }
    }

    try {
      const cmsPhysicalStockPromise = engine.query(query);
      const cmsPhysicalStockData = await cmsPhysicalStockPromise;

      cmsPhysicalStockRows = cmsPhysicalStockData.sqlViewsData.listGrid.rows;
           
    } catch (err) {
      console.log("cmsPhysicalStockRows error", err);
    }

    let currentStockEid= '';
    let currentStockVal = '';
    let dataValues = [];
    
    cmsPhysicalStockRows.forEach((row)=>{        
      currentStockEid = row[0];
      currentStockVal = row[1];
      
      if (currentStockVal > 0){
        dataValues.push({
          "dataElement": currentStockEid,
          "categoryOptionCombo": props.closingZeroStockCat,
          "value": 0
        })
      } else if (currentStockVal == 0){
        dataValues.push({
          "dataElement": currentStockEid,
          "categoryOptionCombo": props.closingZeroStockCat,
          "value": 1
        })
      }

    });

    const mutation = {
      "resource": "dataValueSets",
      "type": "create",
      "data": {
        "period": props.selectedMonthYear,
        "orgUnit": props.selectedFacility,
        "dataValues": dataValues
      }
    }

    try {
      const cmsPhysicalStockPromise = engine.mutate(mutation);
      const cmsPhysicalStockData = await cmsPhysicalStockPromise;

      props.uploadAmcMosResponse(cmsPhysicalStockData);
    } catch (err) {
      console.log("ClosingZeroStock error", err);
    }

  }

  const getYMD = (ym) => {
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    let ymd = year + "-" + month.toString().padStart(2, "0") + "-01";

    return ymd; // "2021-03-01";
  };

  useEffect(() => {
    
    getCMSPhysicalStock(getYMD(props.selectedMonthYear));

  }, [])

  return <></>;
};

export { CalculateAmcMos }