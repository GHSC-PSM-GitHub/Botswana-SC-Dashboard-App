import React,  {useEffect } from 'react'
import PropTypes from 'prop-types'
import { useDataMutation, useDataQuery, DataQuery, useDataEngine } from '@dhis2/app-runtime';

const InsertDataValueSets = ({ onComplete, vJsonData, resposeSaveJson }) => {
  const [mutate, { called, loading, error, data }] = useDataMutation(vJsonData, {
      onComplete: onComplete
  })
	useEffect(() => {
    mutate();
  }, []);
  resposeSaveJson(called, loading, error);
  return (
    <>
    </>
  )
}

const GetOrgUnitGroups = ({ orgUnitsQuery, selectedFacility, cmsMutationData, response, handleError, stateError }) => {
  orgUnitsQuery.orgUnitGroups.id = cmsMutationData.CmsOrganisationUnitGroup
  return(
    <DataQuery query={orgUnitsQuery}>
      {({ error, loading, data }) => {
        if (error && loading == false && (!stateError)){
          handleError("organisationUnitGroups... " + error.message);
        };
        if (loading) return <span>...</span>;
        if(error == undefined && loading == false && data && data.orgUnitGroups && data.orgUnitGroups.organisationUnits){
          let orgUnits = data.orgUnitGroups.organisationUnits.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((orgUnit)=> orgUnit.id !== "default")
          handleError(undefined);
          response(orgUnits);
        }
        return (
          <></>
        )
        }}
    </DataQuery>
  )
}

const GetCompleteDataSetRegistrations = ({ dataSetRegistrationQuery, selectedMonthYear, cmsMutationData, response, handleError, stateError}) => {
  dataSetRegistrationQuery.result.params.dataSet = cmsMutationData.CmsDataset
  dataSetRegistrationQuery.result.params.period = selectedMonthYear
  dataSetRegistrationQuery.result.params.orgUnitGroup = cmsMutationData.CmsOrganisationUnitGroup
  return(
    <DataQuery query={dataSetRegistrationQuery}>
      {({ error, loading, data }) => {
        if (error && loading == false && (!stateError)){
          handleError("completeDataSetRegistrations... "+ error.message);
        };
        if (loading) return <span>...</span>;
        if(error == undefined && loading == false && data){
          handleError(undefined);
          response(data);
        }
        return (<>
        </>)
        }}
    </DataQuery>
  )
}

const FetchDataValueSets = ({ reqGriedData, responceGriedData }) => {
  const { loading, error, data, refetch } = useDataQuery(reqGriedData)
  responceGriedData(loading, error, data, refetch );
  return (
    <>
    </>
  )
}

const SetCompleteDataSetRegistrations = ({mutationDatasetRegJson, orgUnitId, period, completed, cmsMutationData, saveDataSetRegistration}) => {
	mutationDatasetRegJson.data.completeDataSetRegistrations[0].organisationUnit = orgUnitId;
  mutationDatasetRegJson.data.completeDataSetRegistrations[0].period = period;
  mutationDatasetRegJson.data.completeDataSetRegistrations[0].dataSet = cmsMutationData.CmsDataset;
  mutationDatasetRegJson.data.completeDataSetRegistrations[0].completed = completed;
  const engine = useDataEngine();
	engine.mutate(mutationDatasetRegJson, {
		onComplete: res => {
      saveDataSetRegistration(res);
		},
		onError: error => {
		},
	})
  return (
    <>
    </>
  )
}

InsertDataValueSets.propTypes = {
    onComplete: PropTypes.func.isRequired,
}
FetchDataValueSets.propTypes = {
  onComplete: PropTypes.func.isRequired,
}

export {
  InsertDataValueSets,
  FetchDataValueSets,
  GetOrgUnitGroups,
  SetCompleteDataSetRegistrations,
  GetCompleteDataSetRegistrations
}