import React from 'react';
import { useState, useEffect } from 'react'
import { useConfig } from '@dhis2/app-runtime'
import Constants from './../../helpers/constants';
import { labTemplateUpdateSettings, cmsLabTemplateUpdateSettings, cmsVenTemplateUpdateSettings } from '././../../actions/settings';

const UpdateTemplateData = (props) => {
  const { baseUrl, apiVersion } = useConfig();  
  useEffect(() => {    
  }, []);

  if(props.type == "cmsLab"){    
    let cmsLabTemplateSettings = Constants.CmsLabTemplateSettingsCreate
    cmsLabTemplateSettings["data"] = props.cmsTemplateData
    cmsLabTemplateSettings["type"] = "update"
  
    const { cmsLabTemplate_update_loading, cmsLabTemplate_update_req, cmsLabTemplate_update_data, cmsLabTemplate_update_error } = cmsLabTemplateSettings && cmsLabTemplateSettings.data && cmsLabTemplateUpdateSettings(cmsLabTemplateSettings)
  
    if(cmsLabTemplate_update_data && cmsLabTemplate_update_data.httpStatusCode && cmsLabTemplate_update_data.httpStatusCode==200){      
      props.productUpdateResponse(cmsLabTemplate_update_data)
    } 
  }

  if(props.type == "cmsVen"){    
    let cmsVenTemplateSettings = Constants.CmsVenTemplateSettingsCreate
    cmsVenTemplateSettings["data"] = props.cmsTemplateData
    cmsVenTemplateSettings["type"] = "update"
  
    const { cmsVenTemplate_update_loading, cmsVenTemplate_update_req, cmsVenTemplate_update_data, cmsVenTemplate_update_error } = cmsVenTemplateSettings && cmsVenTemplateSettings.data && cmsVenTemplateUpdateSettings(cmsVenTemplateSettings)
  
    if(cmsVenTemplate_update_data && cmsVenTemplate_update_data.httpStatusCode && cmsVenTemplate_update_data.httpStatusCode==200){      
      props.productUpdateResponse(cmsVenTemplate_update_data)
    } 
  }

  return (
    <>
    </>
  );
};

export default UpdateTemplateData;