import React, { Component } from 'react';
import { Button } from '@dhis2/ui-core';
import Dropzone from 'react-dropzone';
import SecondStep from './SecondStep';
import FirstStep from './FirstStep';
import ImportProgressCmsTemplate from './ImportProgressCmsTemplate';
import StatusTemplate from './statusTemplate';
import { InsertDataValueSets, FetchDataValueSets, GetOrgUnitGroups, SetCompleteDataSetRegistrations, GetCompleteDataSetRegistrations } from './cmsTemplateApi';
import XLSX from 'xlsx';
import Constants from '../../helpers/constants';
import { GetAppSettings, SetAppSettings, GetAppSettingsNew, SetAppSettingsNew } from '../Settings/settingComponentApi';
import { CalculateAmcMos } from './Calculation';
import {ExcelImportAppLogsJson} from "../../actions/auditLog";
import UpdateTemplateData from './UpdateTemplateData';

const orgUnitsQuery = {
	orgUnitGroups: {
		resource: 'organisationUnitGroups',
		id: 'AxB3vV3yUrN',
		params: {
			fields: "organisationUnits[id,displayName]",
			paging: false
		}
	}
}

const dataSetRegistrationQuery = {
  result: {
    resource: "completeDataSetRegistrations",
    params: {
      dataSet:"",
      period:"",
      orgUnitGroup:""
    }
  }
}

const mutationDatasetRegJson = {
  resource: "completeDataSetRegistrations",
  type: "create",
  data:{
    completeDataSetRegistrations:[{
      dataSet:"",
      period:"",
      organisationUnit:"",
      completed:true
    }]}
}

const getAppSettingsQuery = {
	"dataStore": {
			"resource": `dataStore/${Constants.namespace}/${Constants.CmsKey}`
	}
}

const getCmsLabTemplateSettingsQuery = {
	"dataStore": {
			"resource": `dataStore/${Constants.namespace}/${Constants.CmsLabTemplateKey}`
	}
}

const getCmsVenTemplateSettingsQuery = {
	"dataStore": {
			"resource": `dataStore/${Constants.namespace}/${Constants.CmsVenTemplateKey}`
	}
}

let today = new Date();
let date = today.getFullYear() + '-' + (String(today.getMonth() + 1)).padStart(2, '0') + '-' + (String(today.getDate())).padStart(2, '0');
const mutationExcelImportAppLogsJson = {
  resource: "dataStore/Excel-Import-App-Logs/" + date,
  type: "create",
  data: [],
};

class ImportCmsTemplate extends Component {
  constructor( props ) {
		super( props );
		this.state = {
      defaultMonth: new Date().getMonth(),
      defaultYear: new Date().getFullYear(),
      getAppSettings: true,
      getCmsLabTemplateSettings: false,
      getCmsVenTemplateSettings: false,
      getOrgUnits: false,
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      loading: false,
      vTemplateVenData: [],
      vTemplateLabData: [],
      saveJsonData: false,
      resGriedData: {},
      error: undefined,
      headingTitle: {},
      resultStatus: null,
      conflictKeyList: [],
      gridDataValues: [],
      missingProducts: [],
      fileName: null,
      statusBtnIcon: null,
      resInsertData: {},
      selectedFacility: null,
      selectedMonthYear: null,
      uploadedFiles: null,
      orgUnits: [],
      setDataSetRegistration: false,
      dataSetRegistrations: [],
      getDataSetRegistrations: false,
      periods: [],
      masterTemplateError: false,
      conflictStatus: false,
      cmsMutationData: {
        CmsVenMasterTemplate: "",
        LMISVenWorksheetName: "",
        CmsLabMasterTemplate: "",
        LMISLabWorksheetName: "",
        LMISWorksheetStartRow: "",
        ExpiryWorkSheetName: "",
        ExpiryWorkStartRow: "",
        CmsOrganisationUnitGroup: "",
        CmsDataset: "",
        CmsLegend: ""
			},
      AMCs: [],
      MOSs: [],
      searchFacility: "",
      deleteUploadedFile: false,
      templateEmptyKeys: [],
      importTemplateLogsJson: [],
      user: this.props.user,
      receiveDate: {},
      updateVenTemplateData: false,
      updateLabTemplateData: false,
      expiryElementsUID: Constants.EXPIRY_ELEMENTS_UID,
      expiryEventSave: false,
      closingZeroStockCat: ''
    }
    this.readExcel = this.readExcel.bind(this);
    this.changePanel = this.changePanel.bind(this);
    this.handleFirstStep = this.handleFirstStep.bind(this);
    this.deleteUploadedFile = this.deleteUploadedFile.bind(this);
    this.handleSecondStep = this.handleSecondStep.bind(this);
    this.generateJson = this.generateJson.bind(this);
    this.closeAlertBar = this.closeAlertBar.bind(this);
    this.resposeSaveJson = this.resposeSaveJson.bind(this);
    this.readDataFromExcel = this.readDataFromExcel.bind(this);
    this.handleChangeFacility = this.handleChangeFacility.bind(this);
    this.redirectToFirstStep = this.redirectToFirstStep.bind(this);
    this.getOrgUnitGroups = this.getOrgUnitGroups.bind(this);
    this.getCompleteDataSet = this.getCompleteDataSet.bind(this);
    this.saveDataSetRegistration = this.saveDataSetRegistration.bind(this);
    this.generatePeriods = this.generatePeriods.bind(this);
    this.setPeriods = this.setPeriods.bind(this);
    this.calculateImportStatus = this.calculateImportStatus.bind(this);
    this.facilityGridData = this.facilityGridData.bind(this);
    this.getAppSettingsResponse = this.getAppSettingsResponse.bind(this);
    this.getCmsLabTemplateSettingsResponse = this.getCmsLabTemplateSettingsResponse.bind(this);
    this.getCmsVenTemplateSettingsResponse = this.getCmsVenTemplateSettingsResponse.bind(this);
    this.uploadAmcMosResponse = this.uploadAmcMosResponse.bind(this);
    this.handleSearchFacility = this.handleSearchFacility.bind(this);
    this.getExcelImportAppLogsJson = this.getExcelImportAppLogsJson.bind(this);
    this.handleError = this.handleError.bind(this);
    this.deleteJsonData = this.deleteJsonData.bind(this);
    this.cmsVenProductUpdateResponse = this.cmsVenProductUpdateResponse.bind(this);
    this.cmsLabProductUpdateResponse = this.cmsLabProductUpdateResponse.bind(this);
    this.cmsExpiryEventsSaveResponse = this.cmsExpiryEventsSaveResponse.bind(this);
	}

  componentWillMount(){
    this.generatePeriods(this.state.defaultYear, this.state.defaultMonth);
  }
  handleSearchFacility(e){
    this.setState({searchFacility: e.value.toLowerCase()});
  }

  handleError(error){
    this.setState({error});
  }

  getExcelImportAppLogsJson(called, loading, error, data){
   if(called && loading && error){
      this.setState({fourthStep: false, loading: false, error});
    }
  }

  deleteJsonData(){
    let vTemplateVenData = this.state.vTemplateVenData
    let vTemplateLabData = this.state.vTemplateLabData
    vTemplateVenData = vTemplateVenData.concat(vTemplateLabData)
    
    let columnList = []
    if(vTemplateVenData && vTemplateVenData.length>0){
      columnList = Object.keys(vTemplateVenData[0]);
    }

    let dataValues = []
    vTemplateVenData.map((logTemplate)=>{
      columnList.map((col)=>{        
        if(logTemplate[col] && logTemplate[col].toString().split('-').length > 1){
          if(col == "__EMPTY_16"){
            dataValues.push({
              "dataElement": logTemplate[col].split('-')[0],
              "categoryOptionCombo": logTemplate[col].split('-')[1],
              "value": 0
            })
          }else{
            dataValues.push({
              "dataElement": logTemplate[col].split('-')[0],
              "categoryOptionCombo": logTemplate[col].split('-')[1],
              "deleted": true
            })
          }
        }
      })
    })

    let mutation = {
      "resource": "dataValueSets",
      "type": "create",
      "data": {
        "period": this.state.selectedMonthYear,
        "orgUnit": this.state.selectedFacility,
        "dataValues": dataValues
      }
    }
    
    return mutation
  }

  facilityGridData(){
    let searchFacility = this.state.searchFacility
    let orgUnits =  this.state.orgUnits.filter((orgUnit)=>{
      if(orgUnit.id !='default' && orgUnit.displayName.toLowerCase().includes(searchFacility)){
        return orgUnit
      }
    })
    let dataSetRegistrations = this.state.dataSetRegistrations;
    let GridData = orgUnits.map((orgUnit)=>{
      let newOrgUnit = {
        period: "",
        dataSet: "",
        organisationUnit: "",
        attributeOptionCombo: "",
        date: "",
        storedBy: "",
        completed: false,
        id: orgUnit.id,
        displayName: orgUnit.displayName,
      }
      dataSetRegistrations.map((dataSet)=>{
        if(orgUnit.id == dataSet.organisationUnit){
          newOrgUnit["period"] = dataSet.period
          newOrgUnit["dataSet"] = dataSet.dataSet
          newOrgUnit["organisationUnit"] = dataSet.organisationUnit
          newOrgUnit["attributeOptionCombo"] = dataSet.attributeOptionCombo
          newOrgUnit["date"] = dataSet.date
          newOrgUnit["storedBy"] = dataSet.storedBy
          newOrgUnit["completed"] = dataSet.completed
        }
      })
      return newOrgUnit
    })
    return GridData
  }

  calculateImportStatus(){
    if(this.state.orgUnits.length>1){
      let facilityCount = this.state.orgUnits.filter((orgUnit)=>orgUnit.id !='default').length
      let importStatusCount = 0
      if(this.state.dataSetRegistrations && this.state.dataSetRegistrations.length){
        importStatusCount = this.state.dataSetRegistrations.filter((dataSet)=> dataSet.completed === true).length
      }
      let percentage = 0
      try{
        percentage = ((importStatusCount/facilityCount)*100).toFixed(1)
      }catch{
        percentage = 0
      }
      return percentage+"% ("+importStatusCount+"/"+facilityCount+ " Facilities)"
    }
  }

  getOrgUnitGroups(res){
    res.unshift({id: "default", displayName: "Select CMS Organisation Unit"})
    this.setState({
      getOrgUnits: false,
      orgUnits:res
    });
  }

  redirectToFirstStep(){
    this.setState({
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      resultStatus: null,
      fileName: null,
      selectedFacility: this.state.cmsMutationData.CmsOrganisationUnitGroup,
      uploadedFiles: null,
      getOrgUnits: true,
      getDataSetRegistrations: true,
      dataSetRegistrations: [],
      AMCs: [],
      MOSs: []
    })
  }

  handleFirstStep(selectedOrgUnit){
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      secondStep:true,
      selectedFacility: selectedOrgUnit.id
    })
  }
  deleteUploadedFile(selectedOrgUnit){
    this.setState({
      getDataSetRegistrations: true,
      deleteUploadedFile: true,
      selectedFacility: selectedOrgUnit.id,
      loading: true
    })
  }

  handleSecondStep(){
    if(this.state.selectedFacility == "default"){
      let error = "Please select a facility"
      this.setState({error});
      return true
    } 
    if(this.state.uploadedFiles == null){
      let error = "Please upload the Excel file you want to import"
      this.setState({error});
      return true
    }
    this.readDataFromExcel()
    this.setState({
      loading: true
    })
  }

  handleChangeFacility(e, name){
    if(name=="selectFacility"){
      this.setState({selectedFacility: e.selected, error: null});
    }else{
      this.setState({
        selectedMonthYear: e.selected,
        error: null,
        getDataSetRegistrations: true,
        dataSetRegistrations: []
      });
    }
    
  }
  resposeSaveJson(called, loading, error){
    if(loading && called && error){
      this.setState({error});
    }
  }

  saveDataSetRegistration(response){
    this.setState({
      getDataSetRegistrations: true,
      setDataSetRegistration: false,
      deleteUploadedFile: false,
      afterDeleteUploadedFile: false,
      loading: false
    })
  }

  getCompleteDataSet(response){
    this.setState({getDataSetRegistrations: false});
    if(response && response.result && response.result.completeDataSetRegistrations){
      this.setState({dataSetRegistrations: response.result.completeDataSetRegistrations});
    }
  }

  closeAlertBar(){
    this.setState({error: null});
  }

  validate(){
    let flag = true
    let error = null

    if(this.state.uploadedFiles == null){
      flag = false
      error = "Please upload the Excel file you want to import"
    }

    if(this.state.selectedFacility == "default"){
      flag = false
      error = "Please select a facility"
    }
    if(flag == false){
      this.setState({error});
    }
    return flag;
  }

  validateFirstStep(){
    let flag = true
    if(this.state.masterTemplateError){
      this.setState({error: "Template file "+this.state.cmsMutationData.CmsVenMasterTemplate+" does not exist"});
      flag = false
    }
    return flag;
  }

  changePanel(){
    if (this.validate()==false) {
      return true
    }
    if (this.state.secondStep) {
      this.setState({
        secondStep: !this.state.secondStep,
        items: [],
        resultStatus: null,
        fileName: null,
        selectedFacility: this.state.cmsMutationData.CmsOrganisationUnitGroup,
        selectedMonthYear: null,
        uploadedFiles: null
      });
    }else{
      this.readDataFromExcel()
      this.setState({
        loading: true
      });
    }
  }

  readExcel(files){  
    if(files.length ==2 ){
      this.setState({
        uploadedFiles: files,
        fileName: files[0].name +" and "+files[1].name,
        error: null
      });
    }else{
      this.setState({
        loading: false,
        error: "please must be upload 2 files",
      })
    } 
  }

  readDataFromExcel(){
    let files = this.state.uploadedFiles;
    let selectedMonthYear = this.state.selectedMonthYear;
    let LMISVenWorksheetName = this.state.cmsMutationData.LMISVenWorksheetName
    let LMISLabWorksheetName = this.state.cmsMutationData.LMISLabWorksheetName
    let LMISVenExpiryWorksheetName = "Expiry"
    let LMISLabExpiryWorksheetName = "Expiry"
    let dataObj = {}
    let firstKey = null
    let months = Constants.MONTH_NAME
    let headingTitle = {
      facilityName: "CMS",
      monthName: months[parseInt(this.state.selectedMonthYear.substring(4,6))-1],
      year: this.state.selectedMonthYear.substring(0,4)
    }
    this.setState({headingTitle});
    const promise = new Promise((resolve, reject) => {
      let fileReader = new FileReader();
      fileReader.readAsArrayBuffer(files[0]);
      fileReader.onload = (e) => {
        let data = []
        let expiryData = []
        let bufferArray = e.target.result;
        let wb = XLSX.read(bufferArray, { type: "buffer" });
        let ven_ws_name = wb.SheetNames.find((sheetName)=> sheetName.toUpperCase().includes(LMISVenWorksheetName.toUpperCase()))
        if(ven_ws_name){
          let ws = wb.Sheets[ven_ws_name];
          firstKey = "ven"
          data = XLSX.utils.sheet_to_json(ws, {defval: "" });
          let str = Object.keys(data[0]).find((key)=> key.toLowerCase().includes("current stock"))
          if(str && str.match(/\d+/g) && str.match(/\d+/g).length){
            let receiveDate = this.state.receiveDate
            let receiveDateValue =  str.match(/\d+/g)[0]
            receiveDate["value"] = receiveDateValue.substring(4,8)+"-"+receiveDateValue.substring(2,4)+"-"+receiveDateValue.substring(0,2)
            this.setState({receiveDate});
          }
        }else{
          let lab_ws_name = wb.SheetNames.find((sheetName)=> sheetName.toUpperCase().includes(LMISLabWorksheetName.toUpperCase()))
          if(lab_ws_name){
            let ws = wb.Sheets[lab_ws_name];
            firstKey = "lab"
            data = XLSX.utils.sheet_to_json(ws, {defval: "" });
          }else{
            this.setState({
              error: "File does not contain "+LMISLabWorksheetName+" worksheet. Unable to proceed",
              loading: false
            });
          }
        }
        let ven_expiry_ws_name = wb.SheetNames.find((sheetName)=> sheetName.toUpperCase().includes(LMISVenExpiryWorksheetName.toUpperCase()))
        if(ven_expiry_ws_name){
          let ws = wb.Sheets[ven_expiry_ws_name];
          expiryData = XLSX.utils.sheet_to_json(ws, {defval: "" });
        }

        resolve({data: data, expiryData: expiryData});
      };

      fileReader.onerror = (error) => {        
        reject(error);
      };
  })
  promise.then((data) => {
    dataObj[firstKey] = data['data'];
    dataObj['expiryData'] = data['expiryData'];
    const secondPromise = new Promise((resolve, reject) => {
      let secondFileReader = new FileReader();
      secondFileReader.readAsArrayBuffer(files[1]);
      secondFileReader.onload = (e) => {
        let secondData = []
        let expiryData = []
        let bufferArray = e.target.result;
        let wb = XLSX.read(bufferArray, { type: "buffer" });
        let ven_ws_name = wb.SheetNames.find((sheetName)=> sheetName.toUpperCase().includes(LMISVenWorksheetName.toUpperCase()))
        if(ven_ws_name){
          let ws = wb.Sheets[ven_ws_name];
          firstKey = "ven"
          secondData = XLSX.utils.sheet_to_json(ws, {defval: "" });
          let str = Object.keys(secondData[0]).find((key)=> key.toLowerCase().includes("current stock"))
          if(str && str.match(/\d+/g) && str.match(/\d+/g).length){
            let receiveDate = this.state.receiveDate
            let receiveDateValue =  str.match(/\d+/g)[0]
            receiveDate["value"] = receiveDateValue.substring(4,8)+"-"+receiveDateValue.substring(2,4)+"-"+receiveDateValue.substring(0,2)
            this.setState({receiveDate});
          }
        }else{
          let lab_ws_name = wb.SheetNames.find((sheetName)=> sheetName.toUpperCase().includes(LMISLabWorksheetName.toUpperCase()))
          if(lab_ws_name){
            let ws = wb.Sheets[lab_ws_name];
            firstKey = "lab"
            secondData = XLSX.utils.sheet_to_json(ws, {defval: "" });
          }else{
            this.setState({
              error: "File does not contain "+LMISLabWorksheetName+" worksheet. Unable to proceed",
              loading: false
            });
          }
        }

        let lab_expiry_ws_name = wb.SheetNames.find((sheetName)=> sheetName.toUpperCase().includes(LMISLabExpiryWorksheetName.toUpperCase()))
        if(lab_expiry_ws_name){
          let ws = wb.Sheets[lab_expiry_ws_name];
          expiryData = XLSX.utils.sheet_to_json(ws, {defval: "" });
        }

        resolve({secondData: secondData, expiryData: expiryData});
      };

      secondFileReader.onerror = (error) => {        
        reject(error);
      };
    })
    secondPromise.then((data) => {
      dataObj[firstKey] = data['secondData']
      dataObj['expiryData'] = dataObj['expiryData'].concat(data['expiryData']);
      if(dataObj["ven"] && dataObj["ven"].length && dataObj["lab"] && dataObj["lab"].length){
        this.generateJson(dataObj);
      }
    });
  });
}

  generateJson(dataObj){
    let vTemplateVenData = this.state.vTemplateVenData
    let vTemplateLabData = this.state.vTemplateLabData
    let vTemplateVenDataList = this.state.vTemplateVenDataList
    let vTemplateLabDataList = this.state.vTemplateLabDataList
    let dataValues = []
    let expiryDataValues = []
    let gridDataValues = []
    let templateEmptyKeys = []
    let venItems = dataObj["ven"]
    let labItems = dataObj["lab"]
    let expiryDataItems = dataObj["expiryData"]
    let vTemplateVenDataWithPrice = []
    let priceObjectVen = {}
    let priceObjectLab = {}    
    let _this = this;
    // let columnList = ["UnitPrice", "CurrentStock"]    
    venItems.map((item)=>{
      let flag = true
      let itemKeys = Object.keys(item)      
      vTemplateVenData.map((vTemplate)=>{
        let vTemplatePrice = vTemplate
        if (vTemplate["Code"] == item["Code"]) {
          flag = false
          let newItem = {}          
          itemKeys.map((itemKey)=>{
            if(itemKey.includes("Code") || itemKey.includes("Code ")){
              newItem["Code"] = item[itemKey]
              itemKey = "Code"
            }
            if(itemKey.includes("Description")){
              newItem["Description"] = item[itemKey]
              itemKey = "Description"
            }
            if(itemKey.includes("Unit Price")){
              if(item[itemKey]){
                newItem["UnitPrice"] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
                item["UnitPrice"] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
                itemKey = "UnitPrice"
                priceObjectVen[vTemplate["Code"]] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
              }else{
                newItem["UnitPrice"] = item[itemKey]
                item["UnitPrice"] = item[itemKey]
                itemKey = "UnitPrice"
              }
            }
            if(itemKey.includes("Current stock")){
              if(item[itemKey]){
                newItem["CurrentStock"] = parseFloat(item[itemKey])
                item["CurrentStock"] = parseFloat(item[itemKey])
                itemKey = "CurrentStock"
              }else{
                newItem["CurrentStock"] = item[itemKey]
                item["CurrentStock"] = item[itemKey]
                itemKey = "CurrentStock"
              }
              
            }
            if (typeof vTemplate[itemKey] == "string" && vTemplate[itemKey].split('-').length >1) {
              if (item[itemKey] || (item[itemKey] === 0)){
                dataValues.push({
                  "dataElement": vTemplate[itemKey].split('-')[0],
                  "categoryOptionCombo": vTemplate[itemKey].split('-')[1],
                  "value": item[itemKey]
                })
              }else{
                dataValues.push({
                  "dataElement": vTemplate[itemKey].split('-')[0],
                  "categoryOptionCombo": vTemplate[itemKey].split('-')[1],
                  "deleted": true
                })
              }
            }
          })
          gridDataValues.push(newItem)
        }
        vTemplateVenDataWithPrice.push(vTemplatePrice);
      })
      if(flag){
        let newItem = {}
        itemKeys.map((itemKey)=>{
          if(itemKey.includes("Code") || itemKey.includes("Code ")){
            newItem["Code"] = item[itemKey]
            templateEmptyKeys.push(item[itemKey]);
          }
          if(itemKey.includes("Description")){
            newItem["Description"] = item[itemKey]
          }
          if(itemKey.includes("Unit Price")){
            if(item[itemKey]){
              newItem["UnitPrice"] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
              // priceObjectVen[vTemplate["Code"]] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
            }else{
              newItem["UnitPrice"] = item[itemKey]
            }
          }
          if(itemKey.includes("Current stock")){
            if(item[itemKey]){
              newItem["CurrentStock"] = parseFloat(item[itemKey])
            }else{
              newItem["CurrentStock"] = item[itemKey]
            }
          }
        })
        gridDataValues.push(newItem)
      }
    })
    labItems.map((item)=>{
      let flag = true
      let itemKeys = Object.keys(item)
      vTemplateLabData.map((vTemplate)=>{
        if ((vTemplate["Code"] == item["Code"]) || (vTemplate["Code"] == item["Code "])) {
          flag = false
          let newItem = {}
          itemKeys.map((itemKey)=>{
            if(itemKey.includes("Code") || itemKey.includes("Code ")){
              newItem["Code"] = item[itemKey]
              item["Code"] = item[itemKey]
              itemKey = "Code"
            }
            if(itemKey.includes("Description")){
              newItem["Description"] = item[itemKey]
              item["Description"] = item[itemKey]
              itemKey = "Description"
            }
            if(itemKey.includes("Unit Price")){
              if(item[itemKey]){
                newItem["UnitPrice"] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
                item["UnitPrice"] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
                itemKey = "UnitPrice"
                priceObjectLab[vTemplate["Code"]] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
              }else{
                newItem["UnitPrice"] = item[itemKey]
                item["UnitPrice"] = item[itemKey]
                itemKey = "UnitPrice"
              }
            }
            
            if(itemKey.includes("Current stock")){
              if(item[itemKey]){
                newItem["CurrentStock"] = parseFloat(item[itemKey])
                item["CurrentStock"] = parseFloat(item[itemKey])
                itemKey = "CurrentStock"
              }else{
                newItem["CurrentStock"] = item[itemKey]
                item["CurrentStock"] = item[itemKey]
                itemKey = "CurrentStock"
              }

            }
            if (typeof vTemplate[itemKey] == "string" && vTemplate[itemKey].split('-').length >1) {
              if (item[itemKey] || (item[itemKey] === 0)){
                dataValues.push({
                  "dataElement": vTemplate[itemKey].split('-')[0],
                  "categoryOptionCombo": vTemplate[itemKey].split('-')[1],
                  "value": item[itemKey]
                })
              }else{
                dataValues.push({
                  "dataElement": vTemplate[itemKey].split('-')[0],
                  "categoryOptionCombo": vTemplate[itemKey].split('-')[1],
                  "deleted": true
                })
              }
            }
          })
          gridDataValues.push(newItem)
        }
      })
      if(flag){
        let newItem = {}
        itemKeys.map((itemKey)=>{
          if(itemKey.includes("Code") || itemKey.includes("Code ")){
            newItem["Code"] = item[itemKey]
            templateEmptyKeys.push(item[itemKey]);
          }
          if(itemKey.includes("Description")){
            newItem["Description"] = item[itemKey]
          }
          if(itemKey.includes("Unit Price")){
            if(item[itemKey]){
              newItem["UnitPrice"] = parseFloat(parseFloat(item[itemKey]).toFixed(2));
            }else{
              newItem["UnitPrice"] = item[itemKey]
            }
          }
          if(itemKey.includes("Current stock")){
            if(item[itemKey]){
              newItem["CurrentStock"] = parseFloat(item[itemKey]);
            }else{
              newItem["CurrentStock"] = item[itemKey];
            }
          }
        })
        gridDataValues.push(newItem)
      }
    })
    dataValues.push(this.state.receiveDate);    
    vTemplateVenDataList = vTemplateVenDataList.map((item)=>{
      if(item["Code "]){
        if(priceObjectVen[item["Code "]]){
          item["Current Price"] = priceObjectVen[item["Code "]]
        }
      }
      if(item["Code"]){
        if(priceObjectVen[item["Code"]]){
          item["Current Price"] = priceObjectVen[item["Code"]]
        }
      }
      return item
    })    
    vTemplateLabDataList = vTemplateLabDataList.map((item)=>{
      if(item["Code "]){
        if(priceObjectLab[item["Code "]]){
          item["Current Price"] = priceObjectLab[item["Code "]]
        }
      }
      if(item["Code"]){
        if(priceObjectLab[item["Code"]]){
          item["Current Price"] = priceObjectLab[item["Code"]]
        }
      }
      return item
    })

    // expiryDataItems
    let expiryElementsUID = this.state.expiryElementsUID
    let expiryDataKeys = Object.keys(expiryDataItems[0]);
    let eventDate = _this.state.selectedMonthYear.substring(0,4) + "-" + _this.state.selectedMonthYear.substring(4,6) + "-01"
    let selectedFacility = _this.state.selectedFacility

    expiryDataItems.map((expiryData) => {
      let event = {
        "program": "zd2SFJtdP2g",
        "programStage": "G9NnqECqD9a",
        "orgUnit": selectedFacility,
        "eventDate": eventDate,
        "dataValues": []
      }
      let expiryDataArr = []
        expiryElementsUID.map((uid, index)=>{
          if(index == 0){
            expiryDataArr.push({
              "dataElement": uid,
              "value": expiryData[expiryDataKeys[index]].substring(0,6)
            })
          } else if(index==1){
            expiryDataArr.push({
              "dataElement": uid,
              "value": expiryData[expiryDataKeys[index-1]]
            })
          } else{
            if(expiryData[expiryDataKeys[index-1]] != "" || expiryData[expiryDataKeys[index-1]] === 0){
              if(uid == "c78aSY84PIA"){
                let baseDate = new Date("1900-01-01")
                baseDate.setDate(baseDate.getDate() + (parseInt(expiryData[expiryDataKeys[index-1]])-2));
                let dateValue = baseDate.getFullYear() + '-' + (String(baseDate.getMonth() + 1)).padStart(2, '0') + '-' + (String(baseDate.getDate())).padStart(2, '0');
                expiryDataArr.push({
                  "dataElement": uid,
                  "value": dateValue
                })
              }else{
                expiryDataArr.push({
                  "dataElement": uid,
                  "value": expiryData[expiryDataKeys[index-1]]
                })
              }
            }
          }
        })
      event["dataValues"] = expiryDataArr
      expiryDataValues.push(event)
    })
    let expiryEventRequest = {
      "resource": "events",
      "type": "create",
      "data": {
        "events": expiryDataValues
      }
    }    

    if(dataValues.length>0 && gridDataValues.length>0){
      let vJsonData = {
        "resource": "dataValueSets",
        "type": "create",
        "data": {
          "period": this.state.selectedMonthYear,
          "orgUnit": this.state.selectedFacility,
          "dataValues": dataValues
        }
      }
      
      this.setState({
        expiryDataItems,
        expiryEventRequest,
        vTemplateVenDataList,
        vTemplateLabDataList,
        templateEmptyKeys,
        gridDataValues: gridDataValues.filter((item) => !(item["Code"] && templateEmptyKeys.includes(item["Code"]))),
        missingProducts: gridDataValues.filter((item) => (item["Code"] && templateEmptyKeys.includes(item["Code"]))),
        vJsonData,
        updateVenTemplateData: true
        // saveJsonData: true,
      });
    }else{
      this.setState({error: "Template file key's didn't match with uploaded file", loading: false});
    }
  }

  generatePeriods(defaultYear, defaultMonth){
    if (defaultMonth == 0) {
      defaultYear = defaultYear-1;
      defaultMonth=12;
    }
    let months = Constants.MONTH_NAME
    let periods = [];
    let currentyear = new Date().getFullYear();
    if((currentyear !== defaultYear)){
      defaultMonth = 12;
    }
    for(let i = (defaultMonth-1); i >= 0; i-- ){
      let option = {}
      option["name"] = months[i] +" "+ defaultYear
      option["id"] = defaultYear+String((i+1)).padStart(2, '0')
      periods.push(option);
    }
    if(this.state.deleteUploadedFile){
      this.setState({
        periods,
        dataSetRegistrations: []
      })
    }else{
      this.setState({
        periods,
        selectedMonthYear: periods[0].id,
        dataSetRegistrations: []
      })
    }
  }

  setPeriods(year){
    if(year=="previous"){
      this.setState({
        defaultYear: this.state.defaultYear - 1,
        getDataSetRegistrations: true,
      });
      this.generatePeriods(this.state.defaultYear - 1, this.state.defaultMonth)
    }else{
      let currentyear = new Date().getFullYear();
      if(currentyear !== this.state.defaultYear){
        this.setState({
          defaultYear: this.state.defaultYear + 1,
          getDataSetRegistrations: true,
        });
        this.generatePeriods(this.state.defaultYear + 1, this.state.defaultMonth)
      }
    }
  }

  getAppSettingsResponse(data){
    if( data && data.dataStore){
      this.setState({
        cmsMutationData: data.dataStore,
        selectedFacility: data.dataStore.CmsOrganisationUnitGroup,
        getAppSettings: false,
        getCmsLabTemplateSettings: true
      })
    }
  }

  cmsVenProductUpdateResponse(cmsVenTemplate_data){
		if(cmsVenTemplate_data.httpStatusCode==200){
			this.setState({
        updateVenTemplateData: false,
        updateLabTemplateData: true
			});
		}
  }
  cmsLabProductUpdateResponse(cmsLabTemplate_data){    
		if(cmsLabTemplate_data.httpStatusCode==200){
			this.setState({
        updateLabTemplateData: false,
        expiryEventSave: true
			});
		}
	}

  cmsExpiryEventsSaveResponse(called, loading, error){
    if(loading && called && error){
      this.setState({error});
    }
	}

  getCmsLabTemplateSettingsResponse(data){
    if( data && data.dataStore){
      let vTemplateLabData = data.dataStore

      const closingZeroStockCat = vTemplateLabData[0].ClosingZeroStockCat;

      this.setState({
        closingZeroStockCat
      })
                 
        let itemKeys = Object.keys(vTemplateLabData[0])
        vTemplateLabData = vTemplateLabData.map((item)=>{
          if((item["Code"] && item["Code"] != "Code") || (item["Code "] && item["Code "] != "Code ")){
            let newItem = {}
            itemKeys.map((itemKey)=>{
              if(itemKey.includes("Code") || itemKey.includes("Code ")){
                newItem["Code"] = item[itemKey]
              }
              if(itemKey.includes("Unit Price")){
                newItem["UnitPrice"] = item[itemKey]
              }
              if(itemKey.includes("Current stock")){
                newItem["CurrentStock"] = item[itemKey]
              }
            })

            let labEid = newItem["CurrentStock"].split('-')[0];
            
            newItem["ClosingZeroStock"] = labEid + '-' + closingZeroStockCat;

            return newItem
          }
        })
      
      this.setState({
        getCmsLabTemplateSettings: false,
        vTemplateLabData,        
        vTemplateLabDataList: data.dataStore,
        getAppSettings: false,
        getCmsVenTemplateSettings: true
      })
    }
  }

  getCmsVenTemplateSettingsResponse(data){
    if( data && data.dataStore){
      let receiveDate = {
        "dataElement":"",
        "categoryOptionCombo":"",
        "value": ""
      }
      let vTemplateVenData = data.dataStore
      
      if(vTemplateVenData.length>0){

        const closingZeroStockCat = vTemplateVenData[0].ClosingZeroStockCat;

        this.setState({
          closingZeroStockCat
        })
        
        let itemKeys = Object.keys(vTemplateVenData[0])

        vTemplateVenData = vTemplateVenData.map((item)=>{  
                
          if(item["CMS Receive Date"] && item["CMS Receive Date"].split("-") && item["CMS Receive Date"].split("-").length==2){
            receiveDate["dataElement"] = item["CMS Receive Date"].split("-")[0]
            receiveDate["categoryOptionCombo"] = item["CMS Receive Date"].split("-")[1]
          }

          if((item["Code"] && item["Code"] != "Code") || (item["Code "] && item["Code "] != "Code ")){

            let newItem = {}

            itemKeys.map((itemKey)=>{
              if(itemKey.includes("Code") || itemKey.includes("Code ")){
                newItem["Code"] = item[itemKey]
              }
              if(itemKey.includes("Unit Price")){
                newItem["UnitPrice"] = item[itemKey]
              }
              if(itemKey.includes("Current stock")){
                newItem["CurrentStock"] = item[itemKey]
              }
            })

            let venEid = newItem["CurrentStock"].split('-')[0];

            newItem["ClosingZeroStock"] = venEid + '-' + closingZeroStockCat;

            return newItem
          }
        })
      }
            
      this.setState({
        receiveDate,
        getCmsVenTemplateSettings: false,
        vTemplateVenData,
        vTemplateVenDataList: data.dataStore,
        getAppSettings: false,
        getOrgUnits: true,
        getDataSetRegistrations: true,
      })
    }
  }

  uploadAmcMosResponse = (response) => {
    if( response.conflicts.length > 0 ) {      
      console.log('Uploading AMC and MOS has coflicts: ' + JSON.stringify(response.conflicts));
      this.setState({loading: false, error: "Uploading AMC and MOS has coflicts"});
    } else {
      this.setState({
        thirdStep: false,
        fourthStep: true,        
        loading: false
      });
    }
  }

  render() {
    return (
      <>
        {
          this.state.getAppSettings &&
          <GetAppSettingsNew query = {getAppSettingsQuery} onResponse = {this.getAppSettingsResponse}/>
        }
        {
          this.state.getCmsLabTemplateSettings &&
          <GetAppSettingsNew query = {getCmsLabTemplateSettingsQuery} onResponse = {this.getCmsLabTemplateSettingsResponse}/>
        }
        {
          this.state.getCmsVenTemplateSettings &&
          <GetAppSettingsNew query = {getCmsVenTemplateSettingsQuery} onResponse = {this.getCmsVenTemplateSettingsResponse}/>
        }
        {
          this.state.fourthStep &&
          <ExcelImportAppLogsJson
            onComplete={result => {
              this.setState({
                fourthStep: false,
                fifthStep: true,
                loading: false
              })
            }}
            query = {mutationExcelImportAppLogsJson}
            importTemplateLogsJson = {this.state.importTemplateLogsJson}
            onResponse = {this.getExcelImportAppLogsJson}
          />
        }
        {
					(this.state.updateVenTemplateData) &&
					<UpdateTemplateData
						cmsTemplateData = {this.state.vTemplateVenDataList}
						productUpdateResponse = {this.cmsVenProductUpdateResponse}
						type = "cmsVen"
					/>
				}
        {
					(this.state.updateLabTemplateData) &&
					<UpdateTemplateData
						cmsTemplateData = {this.state.vTemplateLabDataList}
						productUpdateResponse = {this.cmsLabProductUpdateResponse}
						type = "cmsLab"
					/>
				}
        {
          this.state.expiryEventSave && <InsertDataValueSets
            onComplete={result => {
              this.setState({
                expiryEventSave: false,
                saveJsonData: true
              });
            }}
            vJsonData = { this.state.expiryEventRequest }
            resposeSaveJson = {this.cmsExpiryEventsSaveResponse}
          />
        }
        {
          this.state.saveJsonData && <InsertDataValueSets
            onComplete={result => {
              let conflictKeyList = []
              let statusBtnIcon = null
              let conflictStatus = false
              if(result.conflicts && result.conflicts.length>0){
                conflictStatus = true
              }
              result.conflicts.map((conflict)=>{
                if(conflict.value){
                  conflictKeyList.push(conflict.object.trim());
                }
              })
              let selectedFacility = this.state.orgUnits.find(item => item.id === this.state.selectedFacility)
              let importTemplateLogsJson = this.props.importTemplateLogs || []
              importTemplateLogsJson.push({
                User: this.state.user.displayName,
                DateTime: new Date().toISOString(),
                FileName: this.state.fileName,
                FacilityName: selectedFacility ? selectedFacility.displayName : '',
                MonthYear: this.state.selectedMonthYear,
                Status: {
                  Message: conflictKeyList.length==0 ? "Import process completed successfully" : "Import process completed with error",
                  conflicts: result.conflicts,
                },
              })
              this.setState({
                importTemplateLogsJson,
                conflictStatus,
                statusBtnIcon,
                conflictKeyList,
                saveJsonData: false,
                resultStatus: result.status,
                resInsertData: result,
                firstStep: false,
                secondStep: false,
                thirdStep: true,                
                setDataSetRegistration: true
              })
            }}
            vJsonData = { this.state.vJsonData }
            resposeSaveJson = {this.resposeSaveJson}
          />
        }
        {
          this.state.deleteUploadedFile && <InsertDataValueSets
            onComplete={result => {
              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: false,
                afterDeleteUploadedFile: true,
              })
            }}
            vJsonData = { this.deleteJsonData()}
            resposeSaveJson = {this.resposeSaveJson}
          />
        }
        {
          this.state.afterDeleteUploadedFile &&
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson = {mutationDatasetRegJson}
            orgUnitId = {this.state.selectedFacility}
            period = {this.state.selectedMonthYear}
            completed = {false}
            cmsMutationData = {this.state.cmsMutationData}
            saveDataSetRegistration = {this.saveDataSetRegistration}
          />
        }
        {
          this.state.firstStep &&
          <FirstStep
            deleteUploadedFile = {this.deleteUploadedFile}
            searchFacility = {this.state.searchFacility}
            handleSearchFacility = {this.handleSearchFacility}
            handleFirstStep = {this.handleFirstStep}
            readExcel={this.readExcel}
            loading = {this.state.loading}
            error = {this.state.error}
            closeAlertBar = {this.closeAlertBar}
            handleChangeFacility = {this.handleChangeFacility}
            selectedFacility = {this.state.selectedFacility}
            selectedMonthYear = {this.state.selectedMonthYear}
            orgUnits = {this.state.orgUnits}
            dataSetRegistrations = {this.state.dataSetRegistrations}
            defaultMonth = {this.state.defaultMonth}
            defaultYear = {this.state.defaultYear}
            periods = {this.state.periods}
            setPeriods = {this.setPeriods}
            calculateImportStatus = {this.calculateImportStatus}
            facilityGridData = {this.facilityGridData}
          />
        }
        {
          this.state.firstStep && this.state.getOrgUnits &&
          <GetOrgUnitGroups
            response = {this.getOrgUnitGroups}
            orgUnitsQuery = {orgUnitsQuery}
            cmsMutationData = {this.state.cmsMutationData}
            selectedFacility = {this.state.selectedFacility}
            handleError = {this.handleError}
            stateError = {this.state.error}
          />
        }
        {
          this.state.firstStep && this.state.getDataSetRegistrations &&
          <GetCompleteDataSetRegistrations
            dataSetRegistrationQuery = {dataSetRegistrationQuery}
            selectedMonthYear = {this.state.selectedMonthYear}
            cmsMutationData = {this.state.cmsMutationData}
            response = {this.getCompleteDataSet}
            handleError = {this.handleError}
            stateError = {this.state.error}
          />
        }
        {
          this.state.setDataSetRegistration &&
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson = {mutationDatasetRegJson}
            orgUnitId = {this.state.selectedFacility}
            period = {this.state.selectedMonthYear}
            completed = {true}
            cmsMutationData = {this.state.cmsMutationData}
            saveDataSetRegistration = {this.saveDataSetRegistration}
          />
        }
        {
          (this.state.secondStep || this.state.thirdStep || this.state.fourthStep) &&
          <SecondStep
            handleSecondStep = {this.handleSecondStep}            
            readExcel={this.readExcel}
            loading = {this.state.loading}
            error = {this.state.error}
            closeAlertBar = {this.closeAlertBar}
            handleChangeFacility = {this.handleChangeFacility}
            selectedFacility = {this.state.selectedFacility}
            selectedMonthYear = {this.state.selectedMonthYear}
            orgUnits = {this.state.orgUnits}
            defaultMonth = {this.state.defaultMonth}
            defaultYear = {this.state.defaultYear}
            periods = {this.state.periods}
            setPeriods = {this.setPeriods}
          />
        }
        {
          this.state.thirdStep && <CalculateAmcMos 
          selectedFacility = { this.state.selectedFacility }
          selectedMonthYear = { this.state.selectedMonthYear }
          closingZeroStockCat = {this.state.closingZeroStockCat}
          uploadAmcMosResponse = { this.uploadAmcMosResponse }
          />
        }
        {
          this.state.fifthStep && <ImportProgressCmsTemplate
            changePanel = {this.changePanel}
            items = {this.state.items}
            vJsonData = {this.state.vJsonData}
            loading = {this.state.loading}
            headingTitle = {this.state.headingTitle} 
            resInsertData = {this.state.resInsertData}
            resultStatus = {this.state.resultStatus}
            conflictStatus = {this.state.conflictStatus}
            conflictKeyList = {this.state.conflictKeyList}
            gridDataValues = {this.state.gridDataValues}
            missingProducts = {this.state.missingProducts}
            templateEmptyKeys = {this.state.templateEmptyKeys}
            fileName = {this.state.fileName}
            statusBtnIcon = {this.state.statusBtnIcon}
            redirectToFirstStep = {this.redirectToFirstStep}
            AMCs = {this.state.AMCs}
            MOSs = {this.state.MOSs}
            expiryDataItems = {this.state.expiryDataItems}
          />
        }
      </>
    );
  }
}

export default ImportCmsTemplate;
