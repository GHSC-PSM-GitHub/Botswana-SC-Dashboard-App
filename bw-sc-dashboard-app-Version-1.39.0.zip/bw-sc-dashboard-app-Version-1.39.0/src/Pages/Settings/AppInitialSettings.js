import React from "react";
import { useEffect } from "react";
import { useDataEngine } from "@dhis2/app-runtime";
import Constants from "../../helpers/constants";

const AppInitialSettings = (props) => {
  console.log("AppInitialSettings");

  const engine = useDataEngine();

  const fetchInitialData = async () => {
    // writing general settings to dataStore.
    try {
      const mutationDataPromise = engine.mutate(
        Constants.GeneralSettingsCreate
      );
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("GeneralSettingsCreate error", err);
    }
    //===============End Block===================

    // writing ArtSettingsCreate to dataStore.
    try {
      const mutationDataPromise = engine.mutate(Constants.ArtSettingsCreate);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("ArtSettingsCreate error", err);
    }
    //===============End Block===================

    // writing VenSettingsCreate to dataStore.
    try {
      const mutationDataPromise = engine.mutate(Constants.VenSettingsCreate);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("VenSettingsCreate error", err);
    }
    //===============End Block===================

    // writing LabSettingsCreate to dataStore.
    try {
      const mutationDataPromise = engine.mutate(Constants.LabSettingsCreate);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("LabSettingsCreate error", err);
    }
    //===============End Block===================

    // writing CmsSettingsCreate to dataStore.
    try {
      const mutationDataPromise = engine.mutate(Constants.CmsSettingsCreate);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("CmsSettingsCreate error", err);
    }
    //===============End Block===================

    // writing PipelineSettingsCreate to dataStore.
    try {
      const mutationDataPromise = engine.mutate(
        Constants.PipelineSettingsCreate
      );
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("PipelineSettingsCreate error", err);
    }
    //===============End Block===================

    // reading art_template_log from file and writing to dataStore.
    try {
      const vT = await fetch("templates/art_template_log.json");
      const vTd = await vT.json();
      let vTs = Constants.ArtLogTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("art_template_log error", err);
    }
    //===============End Block===================================

    // reading art_template_reg from file and writing to dataStore.
    try {
      const vT = await fetch("templates/art_template_reg.json");
      const vTd = await vT.json();
      let vTs = Constants.ArtRegTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("art_template_reg error", err);
    }
    //===============End Block===================================

    // reading ven_template from file and writing to dataStore.
    try {
      const vT = await fetch("templates/ven_template.json");
      const vTd = await vT.json();
      let vTs = Constants.VenTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("ven_template error", err);
    }
    //===============End Block===================================

    // reading lab_template from file and writing to dataStore.
    try {
      const vT = await fetch("templates/lab_template.json");
      const vTd = await vT.json();
      let vTs = Constants.LabTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("lab_template error", err);
    }
    //===============End Block===================================

    // reading cms_lab_template from file and writing to dataStore.
    try {
      const vT = await fetch("templates/cms_lab_template.json");
      const vTd = await vT.json();
      let vTs = Constants.CmsLabTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("cms_lab_template error", err);
    }
    //===============End Block===================================

    // reading cms_ven_template from file and writing to dataStore.
    try {
      const vT = await fetch("templates/cms_ven_template.json");
      const vTd = await vT.json();
      let vTs = Constants.CmsVenTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("cms_ven_template error", err);
    }
    //===============End Block===================================

    // reading pipeline_template from file and writing to dataStore.
    try {
      const vT = await fetch("templates/pipeline_template.json");
      const vTd = await vT.json();
      let vTs = Constants.PipelineTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("pipeline_template error", err);
    }
    //===============End Block===================================

    // reading lab_equipment from file and writing to dataStore.
    try {
      const vT = await fetch("templates/lab_equipment.json");
      const vTd = await vT.json();
      let vTs = Constants.LabEquipmentTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("lab_equipment error", err);
    }
    //===============End Block===================================

    // reading lab_test from file and writing to dataStore.
    try {
      const vT = await fetch("templates/lab_test.json");
      const vTd = await vT.json();
      let vTs = Constants.LabTestTemplateSettingsCreate;
      vTs.data = vTd;

      const mutationDataPromise = engine.mutate(vTs);
      const mutationData = await mutationDataPromise;
    } catch (err) {
      //console.log("lab_test error", err);
    }
    //===============End Block===================================
  };

  useEffect(() => {
    fetchInitialData();
  }, []);

  return <></>;
};

export default AppInitialSettings;
