import React, { Component } from 'react';
import { Button, Input, SingleSelectOption, SingleSelect } from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {DataQuery } from '@dhis2/app-runtime'
import LabEditSettings from './LabEditSettings';
import LabTemplateSettings from './LabTemplateSettings'

class LabSettingComponent extends Component {
	constructor( props ) {
		super( props );
		this.state = {
		}
	}
	render(){
		return(
			<>
				<LabEditSettings setMessageAndError = {this.props.setMessageAndError} />
				<LabTemplateSettings setMessageAndError = {this.props.setMessageAndError} />
			</>
		)
	}
}

export default LabSettingComponent;