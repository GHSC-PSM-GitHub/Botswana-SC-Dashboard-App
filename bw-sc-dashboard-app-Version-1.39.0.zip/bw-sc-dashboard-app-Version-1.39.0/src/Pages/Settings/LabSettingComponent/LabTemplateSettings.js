import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import { Button, Input, Divider, AlertBar} from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {SingleSelect, SingleSelectOption} from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';

const LabTemplateSettings = (props) => {
  const history = useHistory()

  const templateQuery = {
    "dataStore": {
        "resource": `dataStore/${Constants.namespace}/${Constants.LabTemplateKey}`
    }
  }

  const engine = useDataEngine()
  const [labTemplateSettings, setlabTemplateSettings] = useState([])

  const [res, setRes] = useState({})
  const [error, setError] = useState(0)

  useEffect(() => {
    engine.query(templateQuery, {
      onComplete: data => {
        setlabTemplateSettings(data);
      },
      onError: error => {
        setError(error.message);
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
  }, []);
  return (
    <>
    </>
  );
};

export default LabTemplateSettings;