import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import { Button, Input, Divider, AlertBar} from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {SingleSelect, SingleSelectOption} from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';

const GeneralEditSettings = (props) => {
  const history = useHistory()
  const query = {
    "dataStore": {
        "resource": `dataStore/${Constants.namespace}/${Constants.GeneralKey}`
    }
  }

  const adjustmentOptionQuery = {
    "optionSets": {
        "resource": "optionSets",
        "params": {            
			"paging":false
        }
    }
  }

  const adminRoleOptionQuery = {
    "me": {
        "resource": "userRoles",
        "params": {
            "fields": [
                "id",
                "name"
            ]
        }
    }
}

const operatorRoleOptionQuery = {
  "me": {
      "resource": "userRoles",
      "params": {
          "fields": [
              "id",
              "name"
          ]
      }
  }
}

  const lossTypeOptionQuery = {
    "optionSets": {
        "resource": "optionSets",
        "params": {            
			"paging":false
        }
    }
  }

  const orgUnitsByGroupQuery = {
    "orgUnitGroups": {
        "resource": "organisationUnitGroups",
        "params": {
          "paging": false
        }
    }
  }

  const dataSetsQuery = {
    "dataSets": {
        "resource": "dataSets",
        "params": {
          "false":false
        }
    }
}

  const legendSetsQuery = {
    "legendSets": {
        "resource": "legendSets",
        "params": {
          "false":false
        }
    }
}

  const engine = useDataEngine()
  const [state, setState] = useState({
    AdjustmentOptionSet:"I1wspo7Dzoq",
    LossOptionSet:"ZsaWeD2rYvk",
    AdminRole: "yrB6vc5Ip3r",
    OperatorRole: "wMduLvLoRbt",
  })

  const [res, setRes] = useState({})
  const [error, setError] = useState(0)

  useEffect(() => {
    engine.query(query, {
      onComplete: data => {
          setState(data.dataStore);
      },
      onError: error => {
        setError(error.message);
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
  }, []);

  const handleChange = (event) => {
    let temState = {...state};
    temState[event.name] = event.value
    setState(temState);
  }

  const handleDropDownChange = (event, key) => {
    // let key = "GENERALOrganisationUnitGroup"
    let temState = {...state};
    temState[key] = event.selected
    setState(temState);
  }

  const handleSave = (event) => {
    saveSettings();
  }

  const saveSettings = () => {
    const mutationJson = {
      "resource": `dataStore/${Constants.namespace}/${Constants.GeneralKey}`,
      "type": "update",
      "data": state
    }

    engine.mutate(mutationJson, {
      onComplete: res => {
        props.setMessageAndError(res, "success");
          setRes(res)
      },
      onError: error => {
        setError(error)
        console.error('error: ', error)
        props.setMessageAndError(error, "error");
      },
    })
  }

  return (
    <div className={styles.tabEditSettings}>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Adjustment Option Group
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={adjustmentOptionQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let optionSets =  data.optionSets.optionSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((orgUnit)=> orgUnit.id !== "default")
              optionSets.unshift({id: " ", displayName: "Select Option Group"})
              let selectedAdjustmentOption = " "
              if(optionSets.map((orgUnit)=> orgUnit.id).includes(state.AdjustmentOptionSet)){
                selectedAdjustmentOption = state.AdjustmentOptionSet
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedAdjustmentOption}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "AdjustmentOptionSet") }
                >
                  {optionSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />                                           
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Loss Option Group
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={lossTypeOptionQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let optionSets = data.optionSets.optionSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((dataSet)=> dataSet.id !== "default")
              optionSets.unshift({id: " ", displayName: "Select Option Group"})
              let selectedLossOption = " "
              if(optionSets.map((dataSet)=> dataSet.id).includes(state.LossOptionSet)){
                selectedLossOption = state.LossOptionSet
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedLossOption}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "LossOptionSet") }
                >
                  {optionSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Admin Role
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={adminRoleOptionQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let optionSets =  data.me.userRoles.filter((orgUnit)=> orgUnit.id !== "default")
              optionSets.unshift({id: " ", name: "Select Option Group"})
              let selectedAdminRole = " "
              if(optionSets.map((orgUnit)=> orgUnit.id).includes(state.AdminRole)){
                selectedAdminRole = state.AdminRole
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedAdminRole}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "AdminRole") }
                >
                  {optionSets.map(({ id, name }) => (
                      <SingleSelectOption key={id} label={name} value={id} />                                           
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
        Operator Role
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={operatorRoleOptionQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let optionSets =  data.me.userRoles.filter((orgUnit)=> orgUnit.id !== "default")
              optionSets.unshift({id: " ", name: "Select Option Group"})
              let selectedOperatorRole = " "
              if(optionSets.map((orgUnit)=> orgUnit.id).includes(state.OperatorRole)){
                selectedOperatorRole = state.OperatorRole
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedOperatorRole}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "OperatorRole") }
                >
                  {optionSets.map(({ id, name }) => (
                      <SingleSelectOption key={id} label={name} value={id} />                                           
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}> 
        <div className={styles.colMd4}>
        <Button large primary name="Primary button"  value="default" onClick={handleSave}>
          SAVE CHANGES
        </Button>
        </div>
      </div>
    </div>
  );
};

export default GeneralEditSettings;