import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import { Button, Input, Divider, AlertBar} from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {SingleSelect, SingleSelectOption} from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';

const VenEditSettings = (props) => {
  const history = useHistory()
  const query = {
    "dataStore": {
        "resource": `dataStore/${Constants.namespace}/${Constants.VenKey}`
    }
  }

  const orgUnitsByGroupQuery = {
    "orgUnitGroups": {
        "resource": "organisationUnitGroups",
        "params": {
          "paging": false
        }
    }
  }

  const dataSetsQuery = {
    "dataSets": {
        "resource": "dataSets",
        "params": {
          "false":false
        }
    }
}

  const legendSetsQuery = {
    "legendSets": {
        "resource": "legendSets",
        "params": {
          "false":false
        }
    }
}

  const engine = useDataEngine()
  const [state, setState] = useState({
    VENMasterTemplate:"",
    LMISWorksheetName:"",
    LMISWorksheetStartRow:"",
    VENOrganisationUnitGroup:"",
    VENDataset: "",
    VENLegend: ""
  })

  const [res, setRes] = useState({})
  const [error, setError] = useState(0)

  useEffect(() => {
    engine.query(query, {
      onComplete: data => {
          setState(data.dataStore);
      },
      onError: error => {
        setError(error.message);
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
  }, []);

  const handleChange = (event) => {
    let temState = {...state};
    temState[event.name] = event.value
    setState(temState);
  }

  const handleDropDownChange = (event, key) => {
    // let key = "VENOrganisationUnitGroup"
    let temState = {...state};
    temState[key] = event.selected
    setState(temState);
  }

  const handleSave = (event) => {
    saveSettings();
  }

  const saveSettings = () => {
    const mutationJson = {
      "resource": `dataStore/${Constants.namespace}/${Constants.VenKey}`,
      "type": "update",
      "data": state
    }

    engine.mutate(mutationJson, {
      onComplete: res => {
        props.setMessageAndError(res, "success");
          setRes(res)
      },
      onError: error => {
        setError(error)
        console.error('error: ', error)
        props.setMessageAndError(error, "error");
      },
    })
  }

  return (
    <div className={styles.tabEditSettings}>
      {/* <div className={styles.row}>
        <div className={styles.colMd4}>
          VEN Master Template
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.VENMasterTemplate}
            name = "VENMasterTemplate"
            onChange = { handleChange }
          />
        </div>
      </div> */}
      <div className={styles.row}>
        <div className={styles.colMd4}>
          LMIS Worksheet Name
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.LMISWorksheetName}
            name = "LMISWorksheetName"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          LMIS Worksheet Start Row
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.LMISWorksheetStartRow}
            name = "LMISWorksheetStartRow"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          VEN Organisation Unit Group
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={orgUnitsByGroupQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let orgUnits = data.orgUnitGroups.organisationUnitGroups.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((orgUnit)=> orgUnit.id !== "default")
              orgUnits.unshift({id: " ", displayName: "Select VEN Organisation Unit"})
              let selectedUnitGroup = " "
              if(orgUnits.map((orgUnit)=> orgUnit.id).includes(state.VENOrganisationUnitGroup)){
                selectedUnitGroup = state.VENOrganisationUnitGroup
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedUnitGroup}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "VENOrganisationUnitGroup") }
                >
                  {orgUnits.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />                                           
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          VEN Dataset
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={dataSetsQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let dataSets = data.dataSets.dataSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((dataSet)=> dataSet.id !== "default")
              dataSets.unshift({id: " ", displayName: "Select VEN Dataset"})
              let selectedVenDataset = " "
              if(dataSets.map((dataSet)=> dataSet.id).includes(state.VENDataset)){
                selectedVenDataset = state.VENDataset
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedVenDataset}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "VENDataset") }
                >
                  {dataSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          VEN Legend
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={legendSetsQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let legendSets = data.legendSets.legendSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((legendSet)=> legendSet.id !== "default")
              legendSets.unshift({id: " ", displayName: "Select VEN Legend"})
              let selectedVenLegend = " "
              if(legendSets.map((legendSet)=> legendSet.id).includes(state.VENLegend)){
                selectedVenLegend = state.VENLegend
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedVenLegend}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "VENLegend") }
                >
                  {legendSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      
    
    <div className={styles.row}> 
        <div className={styles.colMd4}>
        <Button large primary name="Primary button"  value="default" onClick={handleSave}>
          SAVE CHANGES
        </Button>
        </div>
      </div>
    </div>
  );
};

export default VenEditSettings;