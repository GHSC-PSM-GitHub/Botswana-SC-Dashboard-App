import React, { Component } from 'react';
import { Button, Input, SingleSelectOption, SingleSelect } from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {DataQuery } from '@dhis2/app-runtime'
import VenEditSettings from './VenEditSettings';

class VenSettingComponent extends Component {
	constructor( props ) {
		super( props );
		this.state = {
		}
	}
	render(){
		return(
			<>
				<VenEditSettings setMessageAndError = {this.props.setMessageAndError} />
			</>
		)
	}
}

export default VenSettingComponent;