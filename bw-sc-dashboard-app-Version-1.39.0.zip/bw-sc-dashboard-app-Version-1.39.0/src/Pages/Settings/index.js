import React, { Component } from 'react';
import ArtSettingComponent from './ArtSettingComponent';
import CmsSettingComponent from './CmsSettingComponent';
import LabSettingComponent from './LabSettingComponent';
import PipelineSettingComponent from './PipelineSettingComponent';
import VenSettingComponent from './VenSettingComponent';
import GeneralSettingComponent from './GeneralSettingComponent';
import styles from '../Pages.module.css';
import { GetAppSettings, SetAppSettings, GetAppSettingsNew, SetAppSettingsNew } from './settingComponentApi';
import { AlertBar } from '@dhis2/ui-core';
import { useConfig } from '@dhis2/app-runtime'
import { artInitialSettings } from '../../actions/settings';
import { Divider } from '@dhis2/ui-core';
import Constants from '../../helpers/constants';

class SettingComponent extends Component {
  constructor( props ) {
		super( props );
		this.state = {
			activeTab: "GENERAL",
			error: undefined,
			initializeSettings: true,
			getAppSettings: false,
			setAppSettings: false,
			getOrgUnits: true,
			mutation:{},
			success: undefined,
			resMessage: null,
		}
		this.changeTab = this.changeTab.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.handleChangeUnitGroup = this.handleChangeUnitGroup.bind(this);
		this.setAppSettingsResponse = this.setAppSettingsResponse.bind(this);
		this.saveSettingChanges = this.saveSettingChanges.bind(this);
		this.closeAlertBar = this.closeAlertBar.bind(this);
		this.setMessageAndError = this.setMessageAndError.bind(this);
	}

	changeTab(activeTab){
		

		this.setState({activeTab});
	}
	saveSettingChanges(){
		const { baseUrl, apiVersion } = useConfig();
    const Url = baseUrl + `/api/dataStore/${Constants.namespace}`
		const { loading, req, data, error } = artInitialSettings(Url, Constants.ArtSettingsCreate)
		if(!loading && req.status == 200){
				this.setState({resMessage: "Status: "+req.status +", Namespace and Keys are already exist"})
			}
			if(!loading && req.status == 404){
				this.setState({resMessage: "Status: "+req.status +", Namespace and Keys are created successfully."})
			}
			if(!loading && req.status == 200){
				this.setState({setAppSettings: true});
			}
	}

	setMessageAndError(message, type){
		if(type == "success")
			this.setState({success: message.message});
		else
		this.setState({error: message.message});
	}

	closeAlertBar(){
		this.setState({error: undefined, success: undefined});
	}

	setAppSettingsResponse(result){
		this.setState({setAppSettings: false, success: result.message});
	}

	handleChange(e){
		let artMutationData = this.state.artMutationData;
		artMutationData[e.name] = e.value
		this.setState({artMutationData});
	}

	handleChangeUnitGroup(e, fieldName){		
		let artMutationData = this.state.artMutationData;
		artMutationData[fieldName] = e.selected
		this.setState({artMutationData});
	}
	
  render() {
		const {activeTab} = this.state
    return (
      <>
				<div className={styles.setting}>
					{
						this.state.setAppSettings &&
						<SetAppSettingsNew mutation = {this.state.mutation} onComplete={this.setAppSettingsResponse}/>
					}
					{
						this.state.error &&
						<div className = {styles.alertBarBox}>
							<AlertBar
							permanent
							critical
							className = {styles.alertBar}
							onHidden={(payload, event) => {
								this.closeAlertBar();
							}}
							>
							{this.state.error}
							</AlertBar>
						</div>
						}
				{
					this.state.success &&
					<div className = {styles.alertBarBox}>
						<AlertBar
						permanent
						success
						className = {styles.alertBar}
						onHidden={(payload, event) => {
							this.closeAlertBar();
						}}
						>
						{this.state.success}
						</AlertBar>
					</div>
				}
				</div>
				<ul className = {styles.settingPages}>
					<li className = {activeTab == "GENERAL" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "GENERAL")}>GENERAL</li>
					<li className = {activeTab == "ART" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "ART")}>ARV</li>
					<li className = {activeTab == "VEN" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "VEN")}>VEN</li>
					<li className = {activeTab == "Lab" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "Lab")}>Lab</li>
					<li className = {activeTab == "CMS" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "CMS")}>CMS</li>
					<li className = {activeTab == "QAT" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "QAT")}>QAT</li>
				</ul>
				<div className={styles.tab}>
					{
						activeTab == "GENERAL" &&
						<GeneralSettingComponent
							handleChange = {this.handleChange}
							handleChangeUnitGroup = {this.handleChangeUnitGroup}
							saveSettingChanges = {this.saveSettingChanges}
							setMessageAndError = {this.setMessageAndError}
						/>
					}
					{
						activeTab == "ART" &&
						<ArtSettingComponent
							handleChange = {this.handleChange}
							handleChangeUnitGroup = {this.handleChangeUnitGroup}							
							saveSettingChanges = {this.saveSettingChanges}
							setMessageAndError = {this.setMessageAndError}
						/>
					}
					{
						activeTab == "VEN" &&
						<VenSettingComponent
							handleChange = {this.handleChange}
							handleChangeUnitGroup = {this.handleChangeUnitGroup}							
							saveSettingChanges = {this.saveSettingChanges}
							setMessageAndError = {this.setMessageAndError}
						/>
					}
					{
						activeTab == "Lab" &&
						<LabSettingComponent
							handleChange = {this.handleChange}
							handleChangeUnitGroup = {this.handleChangeUnitGroup}							
							saveSettingChanges = {this.saveSettingChanges}
							setMessageAndError = {this.setMessageAndError}
						/>
					}
					{
						activeTab == "CMS" &&
						<CmsSettingComponent
							handleChange = {this.handleChange}
							handleChangeUnitGroup = {this.handleChangeUnitGroup}							
							saveSettingChanges = {this.saveSettingChanges}
							setMessageAndError = {this.setMessageAndError}
						/>
					}
					{
						activeTab == "QAT" &&
						<PipelineSettingComponent
							handleChange = {this.handleChange}
							handleChangeUnitGroup = {this.handleChangeUnitGroup}							
							saveSettingChanges = {this.saveSettingChanges}
							setMessageAndError = {this.setMessageAndError}
						/>
					}
				</div>
      </>
    );
  }
}

export default SettingComponent;
