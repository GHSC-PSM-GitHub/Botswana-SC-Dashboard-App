import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import { Button, Input, Divider, AlertBar} from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {SingleSelect, SingleSelectOption} from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';

const ArtEditSettings = (props) => {
  const history = useHistory()
  const query = {
    "dataStore": {
        "resource": `dataStore/${Constants.namespace}/${Constants.ArtKey}`
    }
  }

  const orgUnitsByGroupQuery = {
    "orgUnitGroups": {
        "resource": "organisationUnitGroups",
        "params": {
          "paging": false
        }
    }
  }

  const dataSetsQuery = {
    "dataSets": {
        "resource": "dataSets",
        "params": {
          "false":false
        }
    }
}

  const legendSetsQuery = {
    "legendSets": {
        "resource": "legendSets",
        "params": {
          "false":false
        }
    }
}

  const engine = useDataEngine()
  const [state, setState] = useState({
      "ARTMasterTemplate": "",
      "LMISWorksheetName": "",
      "LMISWorksheetStartRow": "",      
      "RegimenWorksheetName": "",
      "RegimenWorksheetStartRow": "",
      "ARTOrganisationUnitGroup": "",
      "ARTDataset": "",
      "ARTLegend": ""
  })

  const [res, setRes] = useState({})
  const [error, setError] = useState(0)

  useEffect(() => {
    engine.query(query, {
      onComplete: data => {
          setState(data.dataStore);
      },
      onError: error => {
        setError(error.message);
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
  }, []);

  const handleChange = (event) => {
    let temState = {...state};
    temState[event.name] = event.value
    setState(temState);
  }

  const handleDropDownChange = (event, key) => {
    // let key = "ARTOrganisationUnitGroup"
    let temState = {...state};
    temState[key] = event.selected
    setState(temState);
  }

  const handleSave = (event) => {
    saveSettings();
  }

  const saveSettings = () => {
    const mutationJson = {
      "resource": `dataStore/${Constants.namespace}/${Constants.ArtKey}`,
      "type": "update",
      "data": state
    }

    engine.mutate(mutationJson, {
      onComplete: res => {
        props.setMessageAndError(res, "success");
          setRes(res)
      },
      onError: error => {
        setError(error)
        console.error('error: ', error)
        props.setMessageAndError(error, "error");
      },
    })
  }

  return (
    <div className={styles.tabEditSettings}>
      {/* <div className={styles.row}>
        <div className={styles.colMd4}>
          ARV Master Template
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.ARTMasterTemplate}
            name = "ARTMasterTemplate"
            onChange = { handleChange }
          />
        </div>
      </div> */}
      <div className={styles.row}>
        <div className={styles.colMd4}>
          LMIS Worksheet Name
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.LMISWorksheetName}
            name = "LMISWorksheetName"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          LMIS Worksheet Start Row
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.LMISWorksheetStartRow}
            name = "LMISWorksheetStartRow"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Regimen Worksheet Name
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.RegimenWorksheetName}
            name = "RegimenWorksheetName"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Regimen Worksheet Start Row
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.RegimenWorksheetStartRow}
            name = "RegimenWorksheetStartRow"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          ARV Organisation Unit Group
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={orgUnitsByGroupQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let orgUnits = data.orgUnitGroups.organisationUnitGroups.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((orgUnit)=> orgUnit.id !== "default")
              orgUnits.unshift({id: " ", displayName: "Select ARV Organisation Unit"})
              let selectedUnitGroup = " "
              if(orgUnits.map((orgUnit)=> orgUnit.id).includes(state.ARTOrganisationUnitGroup)){
                selectedUnitGroup = state.ARTOrganisationUnitGroup
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedUnitGroup}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "ARTOrganisationUnitGroup") }
                >
                  {orgUnits.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />                                           
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          ARV Dataset
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={dataSetsQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let dataSets = data.dataSets.dataSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((dataSet)=> dataSet.id !== "default")
              dataSets.unshift({id: " ", displayName: "Select ARV Dataset"})
              let selectedArtDataset = " "
              if(dataSets.map((dataSet)=> dataSet.id).includes(state.ARTDataset)){
                selectedArtDataset = state.ARTDataset
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedArtDataset}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "ARTDataset") }
                >
                  {dataSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          ARV Legend
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={legendSetsQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let legendSets = data.legendSets.legendSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((legendSet)=> legendSet.id !== "default")
              legendSets.unshift({id: " ", displayName: "Select ARV Legend"})
              let selectedArtLegend = " "
              if(legendSets.map((legendSet)=> legendSet.id).includes(state.ARTLegend)){
                selectedArtLegend = state.ARTLegend
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedArtLegend}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "ARTLegend") }
                >
                  {legendSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}> 
        <div className={styles.colMd4}>
        <Button large primary name="Primary button"  value="default" onClick={handleSave}>
          SAVE CHANGES
        </Button>
        </div>
      </div>
    </div>
  );
};

export default ArtEditSettings;