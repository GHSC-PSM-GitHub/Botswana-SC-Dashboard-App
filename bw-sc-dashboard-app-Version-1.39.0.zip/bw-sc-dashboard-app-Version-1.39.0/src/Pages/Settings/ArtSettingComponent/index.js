import React, { Component } from 'react';
import { Button, Input, SingleSelectOption, SingleSelect } from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {DataQuery } from '@dhis2/app-runtime'
import ArtEditSettings from './ArtEditSettings';

class ArtSettingComponent extends Component {
	constructor( props ) {
		super( props );
		this.state = {
		}
	}
	render(){
		return(
			<>
				<ArtEditSettings setMessageAndError = {this.props.setMessageAndError} />
			</>
		)
	}
}

export default ArtSettingComponent;