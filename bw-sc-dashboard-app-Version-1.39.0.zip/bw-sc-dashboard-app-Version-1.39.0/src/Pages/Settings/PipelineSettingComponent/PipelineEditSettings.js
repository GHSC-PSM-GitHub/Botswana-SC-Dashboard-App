import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import { Button, Input, Divider, AlertBar} from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {SingleSelect, SingleSelectOption} from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';

const PipelineEditSettings = (props) => {
  const history = useHistory()
  const query = {
    "dataStore": {
        "resource": `dataStore/${Constants.namespace}/${Constants.PipelineKey}`
    }
  }

  const orgUnitsByGroupQuery = {
    "orgUnitGroups": {
        "resource": "organisationUnitGroups",
        "params": {
          "paging": false
        }
    }
  }

  const dataSetsQuery = {
    "dataSets": {
        "resource": "dataSets",
        "params": {
          "false":false
        }
    }
}

  const legendSetsQuery = {
    "legendSets": {
        "resource": "legendSets",
        "params": {
          "false":false
        }
    }
}

  const engine = useDataEngine()
  const [state, setState] = useState({
    PipelineMasterTemplate:"",
    PipelineWorksheetName:"",
    PipelineWorksheetStartRow:"",
    PipelineOrganisationUnitGroup:"",
    PipelineDataset: "",
    PipelineLegend: ""
  })

  const [res, setRes] = useState({})
  const [error, setError] = useState(0)

  useEffect(() => {
    engine.query(query, {
      onComplete: data => {
        setState(data.dataStore);
      },
      onError: error => {
        setError(error.message);
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
  }, []);

  const handleChange = (event) => {
    let temState = {...state};
    temState[event.name] = event.value
    setState(temState);
  }

  const handleDropDownChange = (event, key) => {
    let temState = {...state};
    temState[key] = event.selected
    setState(temState);
  }

  const handleSave = (event) => {
    saveSettings();
  }

  const saveSettings = () => {
    const mutationJson = {
      "resource": `dataStore/${Constants.namespace}/${Constants.PipelineKey}`,
      "type": "update",
      "data": state
    }

    engine.mutate(mutationJson, {
      onComplete: res => {
        props.setMessageAndError(res, "success");
          setRes(res)
      },
      onError: error => {
        setError(error)
        console.error('error: ', error)
        props.setMessageAndError(error, "error");
      },
    })
  }

  return (
    <div className={styles.tabEditSettings}>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Worksheet Name
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.PipelineWorksheetName}
            name = "PipelineWorksheetName"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Worksheet Start Row
        </div>
        <div className={styles.colMd8}>
          <Input
            value={state.PipelineWorksheetStartRow}
            name = "PipelineWorksheetStartRow"
            onChange = { handleChange }
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Organisation Unit Group
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={orgUnitsByGroupQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let orgUnits = data.orgUnitGroups.organisationUnitGroups.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((orgUnit)=> orgUnit.id !== "default")
              orgUnits.unshift({id: " ", displayName: "Select Organisation Unit"})
              let selectedUnitGroup = " "
              if(orgUnits.map((orgUnit)=> orgUnit.id).includes(state.PipelineOrganisationUnitGroup)){
                selectedUnitGroup = state.PipelineOrganisationUnitGroup
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedUnitGroup}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "PipelineOrganisationUnitGroup") }
                >
                  {orgUnits.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />                                           
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Dataset
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={dataSetsQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let dataSets = data.dataSets.dataSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((dataSet)=> dataSet.id !== "default")
              dataSets.unshift({id: " ", displayName: "Select Dataset"})
              let selectedVenDataset = " "
              if(dataSets.map((dataSet)=> dataSet.id).includes(state.PipelineDataset)){
                selectedVenDataset = state.PipelineDataset
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedVenDataset}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "PipelineDataset") }
                >
                  {dataSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.colMd4}>
          Legend
        </div>
        <div className={styles.colMd8}>
          <DataQuery query={legendSetsQuery}>
            {({ error, loading, data }) => {
              if (error) return <span>ERROR</span>;
              if (loading) return <span>...</span>;
              let legendSets = data.legendSets.legendSets.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((legendSet)=> legendSet.id !== "default")
              legendSets.unshift({id: " ", displayName: "Select Legend"})
              let selectedVenLegend = " "
              if(legendSets.map((legendSet)=> legendSet.id).includes(state.PipelineLegend)){
                selectedVenLegend = state.PipelineLegend
              }
              return (<>
                <SingleSelect
                  className="select"
                  selected={selectedVenLegend}
                  filterable
                  noMatchText="No match found"
                  onChange = {(e)=> handleDropDownChange(e, "PipelineLegend") }
                >
                  {legendSets.map(({ id, displayName }) => (
                      <SingleSelectOption key={id} label={displayName} value={id} />
                  ))}
                </SingleSelect>
              </>)
              }}
          </DataQuery>
        </div>
      </div>
      
    
    <div className={styles.row}> 
        <div className={styles.colMd4}>
        <Button large primary name="Primary button"  value="default" onClick={handleSave}>
          SAVE CHANGES
        </Button>
        </div>
      </div>
    </div>
  );
};

export default PipelineEditSettings;