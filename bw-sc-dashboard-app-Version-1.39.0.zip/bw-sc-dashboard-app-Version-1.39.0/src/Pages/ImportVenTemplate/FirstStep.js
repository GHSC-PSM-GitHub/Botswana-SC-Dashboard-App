import React, { Component } from "react";
import {
  Button,
  CircularLoader,
  SingleSelect,
  SingleSelectOption,
  AlertBar,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRowHead,
  TableCellHead,
  TableRow,
  Input,
} from "@dhis2/ui-core";
import styles from "../Pages.module.css";

class FirstStep extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <>
        <div
          style={{
            backgroundColor: "#fff",
            padding: "0px 20px 20px 20px",
            height: "95%",
          }}
        >
          {this.props.loading && (
            <center>
              <CircularLoader
                className={styles.loading_icon}
                dataTest="dhis2-uicore-circularloader"
                large
              />
            </center>
          )}
          {this.props.error && (
            <div className={styles.alertBarBox}>
              <AlertBar
                permanent
                critical
                className={styles.alertBar}
                onHidden={(payload, event) => {
                  this.props.closeAlertBar();
                }}
              >
                {this.props.error}
              </AlertBar>
            </div>
          )}
          <div className={styles.row}>
            <div className={styles.leftContainer}>
              <h2>Import VEN LMIS Report</h2>
              <p>
                Shows the list of facilities and their VEN LMIS Report upload
                status for the selected month-year
              </p>
              <div className={styles.container}>
                <div className={styles.monthYear}>Month-Year</div>
                <div className={styles.monthYearSelect}>
                  <SingleSelect
                    selected={this.props.selectedMonthYear}
                    onChange={(e) =>
                      this.props.handleChangeFacility(e, "monthYear")
                    }
                  >
                    {this.props.periods.map((unit) => {
                      return (
                        <SingleSelectOption value={unit.id} label={unit.name} />
                      );
                    })}
                  </SingleSelect>
                </div>
                <div className={styles.previousYear}>
                  <Button
                    name="Basic button"
                    value=""
                    onClick={() => this.props.setPeriods("previous")}
                  >
                    Prev Year
                  </Button>
                </div>
                <div className={styles.nextYear}>
                  <Button
                    name="Basic button"
                    value="default"
                    onClick={() => this.props.setPeriods("next")}
                  >
                    Next Year
                  </Button>
                </div>
              </div>
            </div>
            <div>
              <div className={styles.importStatusBox}>
                <p>{this.props.calculateImportStatus()}</p>
                <p>Import Status</p>
              </div>
            </div>
          </div>
          <div>
            <Input
              name="searchFacility"
              className={styles.searchFacilityField}
              value={this.props.searchFacility}
              placeholder="Search Facility"
              onChange={(e) => this.props.handleSearchFacility(e)}
            />
          </div>
          <div className={styles.facilityGridTable}>
            <Table>
              <TableHead>
                <TableRowHead>
                  <TableCellHead>SI#</TableCellHead>
                  <TableCellHead>Facility</TableCellHead>
                  <TableCellHead>Import Date</TableCellHead>
                  <TableCellHead>Action</TableCellHead>
                </TableRowHead>
              </TableHead>
              <TableBody>
                {this.props.facilityGridData().map((orgUnit, i) => {
                  return (
                    <TableRow>
                      <TableCell>{i + 1}</TableCell>
                      <TableCell>{orgUnit.displayName}</TableCell>
                      <TableCell>
                        {orgUnit.completed == true && orgUnit.date}
                      </TableCell>
                      <TableCell dense>
                        {orgUnit.completed == false ? (
                          <Button
                            name="Primary button"
                            onClick={() => this.props.handleFirstStep(orgUnit)}
                            primary
                            value="default"
                          >
                            Import
                          </Button>
                        ) : (
                          <div>
                            <Button
                              name="destructive button"
                              onClick={() =>
                                this.props.deleteUploadedFile(orgUnit)
                              }
                              destructive
                              value="default"
                            >
                              Delete
                            </Button>{" "}                            
                            {(this.props.fixDataValues[orgUnit.id] ==
                              undefined ||
                              this.props.fixDataValues[orgUnit.id].value ==
                                "0") && (
                              <Button
                                name="Primary button"
                                onClick={() =>
                                  this.props.handleDataFixFirstStep(orgUnit)
                                }
                                primary
                                value="default"
                              >
                                Fix MOS
                              </Button>
                            )}
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      </>
    );
  }
}

export default FirstStep;
