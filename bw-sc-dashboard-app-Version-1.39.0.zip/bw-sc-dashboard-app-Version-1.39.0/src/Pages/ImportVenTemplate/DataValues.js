import { useEffect } from "react";
import { useDataEngine, DataQuery } from "@dhis2/app-runtime";

const DataValues = (props) => {
  const engine = useDataEngine();

  //http://bwscdashboard.com:8080/api/36/dataValueSets.json?dataElementGroup=ii0UdowS11m&orgUnitGroup=MxzepEFEDWd&period=202304&includeDeleted=true

  const query = {
    dataValueSets: {
      resource: "dataValueSets",
      params: {
        dataElementGroup: "ii0UdowS11m",
        orgUnitGroup: "MxzepEFEDWd",
        period: props.selectedMonthYear,
        //period: "202304",
        //includeDeleted: true,
      },
    },
  };

  const getDataValues = async () => {
    // console.log('getDataValues: ', this.state.venMutationData);

    // if(!this.state.venMutationData.VENDataset){
    //   return;
    // }
    // const dataValueSetsQuery = {
    //   dataValueSets: {
    //     resource: `dataValueSets.json?dataSet=${this.state.venMutationData.VENDataset}&orgUnit=${this.state.selectedFacility}&period=${this.state.selectedMonthYear}`,
    //   }
    // }

    //console.log("dataValueSetsQuery: ", query);
    const dataValueSetsResult = await engine.query(query);
    //console.log("dataValueSetsResult: ", dataValueSetsResult);

    let dataValues = [];
    let obj = {};
    if (dataValueSetsResult.dataValueSets.dataValues !== undefined) {
      dataValues = dataValueSetsResult.dataValueSets.dataValues;

      obj = dataValues.reduce(function (acc, cur, i) {
        acc[cur.orgUnit] = cur;
        return acc;
      }, {});

      //console.log("obj: ", obj);
    }

    props.handleDataValuesResponse(obj);

    // engine.query(query, {
    //   onComplete: (data) => {

    //     console.log('End getDataValues: ', Math. round(Date. now() / 1000));

    //   },

    //   onError: (error) => {},
    // });
  };

  useEffect(() => {
    getDataValues();
  }, []);

return <></>;
//   return (
//     <DataQuery query={query}>
//       {({ loading, error, data }) => {
//         console.log("data369: ", data);
//         return (
//           <>
//             <h3>Indicators</h3>
//             {loading && <span>...</span>}
//             {error && <span></span>}
//             {data && <pre></pre>}
//           </>
//         );
//       }}
//     </DataQuery>
//   );
};

export { DataValues };
