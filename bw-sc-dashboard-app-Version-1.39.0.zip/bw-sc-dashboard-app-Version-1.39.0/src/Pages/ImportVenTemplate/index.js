import React, { Component } from "react";
import SecondStep from "./SecondStep";
import FirstStep from "./FirstStep";
import ImportProgressVenTemplate from "./ImportProgressVenTemplate";
import { DeleteDataValues } from "../../helpers/commonTemplateApi";
import {
  InsertDataValueSets,
  GetOrgUnitGroups,
  SetCompleteDataSetRegistrations,
  GetCompleteDataSetRegistrations,
  GetVenTemplateSettings,
} from "./venTemplateApi";
import XLSX from "xlsx";
import Constants from "../../helpers/constants";
import {
  GetAppSettingsNew,
  GetOptionSets,
} from "../Settings/settingComponentApi";
import { CalculateAmcMos } from "./Calculation";
import { ExcelImportAppLogsJson } from "../../actions/auditLog";
import ShowDuplicateProducts from "./ShowDuplicateProducts";
import DataFixSecondStep from "./DataFixSecondStep";
import { DataFixCalculation } from "./DataFixCalculation";
import { DataValues } from "./DataValues";
import constants from "../../helpers/constants";

const orgUnitsQuery = {
  orgUnitGroups: {
    resource: "organisationUnitGroups",
    id: "AxB3vV3yUrN",
    params: {
      fields: "organisationUnits[id,displayName]",
      paging: false,
    },
  },
};

const dataSetRegistrationQuery = {
  result: {
    resource: "completeDataSetRegistrations",
    params: {
      dataSet: "",
      period: "",
      orgUnitGroup: "",
    },
  },
};

const mutationDatasetRegJson = {
  resource: "completeDataSetRegistrations",
  type: "create",
  data: {
    completeDataSetRegistrations: [
      {
        dataSet: "",
        period: "",
        organisationUnit: "",
        completed: true,
      },
    ],
  },
};

const getAppSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.VenKey}`,
  },
};
const getGeneralSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.GeneralKey}`,
  },
};
const getOptionSetsQuery = {
  options: {
    resource: "optionSets",
    id: "",
    params: {
      fields: "id, displayName, options[code,displayName]",
    },
  },
};

const venTemplateQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.VenTemplateKey}`,
  },
};

const getCmsVenTemplateSettingsQuery = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.CmsVenTemplateKey}`,
  },
};

let today = new Date();
let date =
  today.getFullYear() +
  "-" +
  String(today.getMonth() + 1).padStart(2, "0") +
  "-" +
  String(today.getDate()).padStart(2, "0");
const mutationExcelImportAppLogsJson = {
  resource: "dataStore/Excel-Import-App-Logs/" + date,
  type: "create",
  data: [],
};

class ImportVenTemplate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultMonth: new Date().getMonth(),
      defaultYear: new Date().getFullYear(),
      getAppSettings: true,
      getOrgUnits: false,
      firstStep: true,
      secondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      loading: false,
      vTemplateData: [],
      saveJsonData: false,
      resGriedData: {},
      error: undefined,
      successMsg: undefined,
      headingTitle: {},
      resultStatus: null,
      conflictKeyList: [],
      gridDataValues: [],
      missingProducts: [],
      fileName: null,
      statusBtnIcon: null,
      resInsertData: {},
      selectedFacility: null,
      selectedMonthYear: null,
      uploadedFile: null,
      orgUnits: [],
      setDataSetRegistration: false,
      dataSetRegistrations: [],
      getDataSetRegistrations: false,
      periods: [],
      masterTemplateError: false,
      conflictStatus: false,
      venMutationData: {
        VENMasterTemplate: "",
        LMISWorksheetName: "",
        LMISWorksheetStartRow: "",
        VENOrganisationUnitGroup: "",
        VENDataset: "",
        VENLegend: "",
      },
      AMCs: [],
      MOSs: [],
      searchFacility: "",
      deleteUploadedFile: false,
      templateEmptyKeys: [],
      importTemplateLogsJson: [],
      user: this.props.user,
      getGeneralSettings: false,
      getOptionSets: false,
      generalMutationData: {},
      optionSetsData: [],
      getVenTemplateData: false,
      showDuplicateProducts: false,
      gridHeadingTitle: null,
      duplicateProducts: [],
      blankOrNegativeRocords: [],
      getCmsVenTemplateSettings: false,
      vTemplateCmsVenData: [],
      vTemplateCmsVenDataList: [],
      dataFixSecondStep: false,
      bShowDataFixCalculation: false,
      dataFixBtnDisabled: false,
      dataFixBtnBack: false,
      bFixed: false,
      bDataValuesResponsed: true,
      bDataValuesLoaded: false,
      fixDataValues: {},
    };
    this.readExcel = this.readExcel.bind(this);
    this.changePanel = this.changePanel.bind(this);
    this.handleFirstStep = this.handleFirstStep.bind(this);
    this.deleteUploadedFile = this.deleteUploadedFile.bind(this);
    this.handleSecondStep = this.handleSecondStep.bind(this);
    this.generateJson = this.generateJson.bind(this);
    this.closeAlertBar = this.closeAlertBar.bind(this);
    this.closeAlertBarMsg = this.closeAlertBarMsg.bind(this);
    this.resposeSaveJson = this.resposeSaveJson.bind(this);
    this.readDataFromExcel = this.readDataFromExcel.bind(this);
    this.handleChangeFacility = this.handleChangeFacility.bind(this);
    this.redirectToFirstStep = this.redirectToFirstStep.bind(this);
    this.getOrgUnitGroups = this.getOrgUnitGroups.bind(this);
    this.getCompleteDataSet = this.getCompleteDataSet.bind(this);
    this.saveDataSetRegistration = this.saveDataSetRegistration.bind(this);
    this.generatePeriods = this.generatePeriods.bind(this);
    this.setPeriods = this.setPeriods.bind(this);
    this.calculateImportStatus = this.calculateImportStatus.bind(this);
    this.facilityGridData = this.facilityGridData.bind(this);
    this.getAppSettingsResponse = this.getAppSettingsResponse.bind(this);
    this.uploadAmcMosResponse = this.uploadAmcMosResponse.bind(this);
    this.dataFixUploadAmcMosResponse =
      this.dataFixUploadAmcMosResponse.bind(this);
    this.handleSearchFacility = this.handleSearchFacility.bind(this);
    this.getExcelImportAppLogsJson = this.getExcelImportAppLogsJson.bind(this);
    this.handleError = this.handleError.bind(this);
    this.getNextPeriod = this.getNextPeriod.bind(this);
    this.getGeneralSettingsResponse =
      this.getGeneralSettingsResponse.bind(this);
    this.getOptionSetsResponse = this.getOptionSetsResponse.bind(this);
    this.getVenTemplateSettings = this.getVenTemplateSettings.bind(this);
    this.deleteJsonData = this.deleteJsonData.bind(this);
    this.getCmsVenTemplateSettingsResponse =
      this.getCmsVenTemplateSettingsResponse.bind(this);
    this.handleDataFixFirstStep = this.handleDataFixFirstStep.bind(this);
    this.handleDataFixSecondStep = this.handleDataFixSecondStep.bind(this);
    this.handleDataValuesResponse = this.handleDataValuesResponse.bind(this);
  }

  componentWillMount() {
    this.generatePeriods(this.state.defaultYear, this.state.defaultMonth);
  }

  handleSearchFacility(e) {
    this.setState({ searchFacility: e.value.toLowerCase() });
  }

  getCmsVenTemplateSettingsResponse(data) {
    if (data && data.dataStore) {
      let vTemplateCmsVenData = [];
      if (data.dataStore.length > 0) {
        let itemKeys = Object.keys(data.dataStore[0]);
        data.dataStore.filter((item) => {
          if (
            (item["Code"] && item["Code"] != "Code") ||
            (item["Code "] && item["Code "] != "Code ")
          ) {
            let flag = false;
            let newItem = {};
            itemKeys.map((itemKey) => {
              if (itemKey.includes("Code") || itemKey.includes("Code ")) {
                newItem["Code"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Unit Price")) {
                newItem["UnitPrice"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Current stock")) {
                newItem["CurrentStock"] = item[itemKey];
                flag = true;
              }
              if (itemKey.includes("Current Price")) {
                newItem["CurrentPrice"] = item[itemKey];
                flag = true;
              }
            });
            if (flag) {
              vTemplateCmsVenData.push(newItem);
            }
          }
        });
      }
      this.setState({
        vTemplateCmsVenData,
        vTemplateCmsVenDataList: data.dataStore,
        getOptionSets: true,
        getCmsVenTemplateSettings: false,
      });
    }
  }

  handleError(error) {
    this.setState({ error });
  }

  getExcelImportAppLogsJson(called, loading, error, data) {
    if (called && loading && error) {
      this.setState({ fourthStep: false, loading: false, error });
    }
  }

  deleteJsonData() {
    let dataValues = [];

    const period = this.state.selectedMonthYear;
    const orgUnit = this.state.selectedFacility;

    let csvLine = constants.CSV_HEADER;

    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[2].__EMPTY_9 &&
      this.state.vTemplateData[2].__EMPTY_21 &&
      this.state.vTemplateData[2].__EMPTY_22
    ) {
      let receiveDateKey = this.state.vTemplateData[2].__EMPTY_9;
      let reportTimelyStatus = this.state.vTemplateData[2].__EMPTY_21;
      let reportLateStatus = this.state.vTemplateData[2].__EMPTY_22;

      if (receiveDateKey && reportTimelyStatus && reportLateStatus) {
        // dataValues.push({
        //   dataElement: receiveDateKey.split("-")[0],
        //   categoryOptionCombo: receiveDateKey.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${receiveDateKey.split("-")[0]},${period},${orgUnit},${
          receiveDateKey.split("-")[1]
        },,,,,,,true\n`;
        // dataValues.push({
        //   dataElement: reportTimelyStatus.split("-")[0],
        //   categoryOptionCombo: reportTimelyStatus.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${reportTimelyStatus.split("-")[0]},${period},${orgUnit},${
          reportTimelyStatus.split("-")[1]
        },,,,,,,true\n`;
        // dataValues.push({
        //   dataElement: reportLateStatus.split("-")[0],
        //   categoryOptionCombo: reportLateStatus.split("-")[1],
        //   deleted: true,
        // });
        csvLine += `${reportLateStatus.split("-")[0]},${period},${orgUnit},${
          reportLateStatus.split("-")[1]
        },,,,,,,true\n`;
      }
    }
    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[2].__EMPTY_23 &&
      this.state.vTemplateData[2].__EMPTY_24 &&
      this.state.vTemplateData[2].__EMPTY_25 &&
      this.state.vTemplateData[2].__EMPTY_26
    ) {
      let totalLossKey = this.state.vTemplateData[2].__EMPTY_23;
      let totalBalanceKey = this.state.vTemplateData[2].__EMPTY_24;
      let countAllProductKey = this.state.vTemplateData[2].__EMPTY_25;
      let countNonZeroKey = this.state.vTemplateData[2].__EMPTY_26;

      // dataValues.push({
      //   dataElement: totalLossKey.split("-")[0],
      //   categoryOptionCombo: totalLossKey.split("-")[1],
      //   deleted: true,
      // });
      csvLine += `${totalLossKey.split("-")[0]},${period},${orgUnit},${
        totalLossKey.split("-")[1]
      },,,,,,,true\n`;
      // dataValues.push({
      //   dataElement: totalBalanceKey.split("-")[0],
      //   categoryOptionCombo: totalBalanceKey.split("-")[1],
      //   deleted: true,
      // });
      csvLine += `${totalBalanceKey.split("-")[0]},${period},${orgUnit},${
        totalBalanceKey.split("-")[1]
      },,,,,,,true\n`;
      // dataValues.push({
      //   dataElement: countAllProductKey.split("-")[0],
      //   categoryOptionCombo: countAllProductKey.split("-")[1],
      //   deleted: true,
      // });
      csvLine += `${countAllProductKey.split("-")[0]},${period},${orgUnit},${
        countAllProductKey.split("-")[1]
      },,,,,,,true\n`;
      // dataValues.push({
      //   dataElement: countNonZeroKey.split("-")[0],
      //   categoryOptionCombo: countNonZeroKey.split("-")[1],
      //   deleted: true,
      // });
      csvLine += `${countNonZeroKey.split("-")[0]},${period},${orgUnit},${
        countNonZeroKey.split("-")[1]
      },,,,,,,true\n`;
    }

    let vTemplateData = this.state.vTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );
    let columnList = [];
    if (vTemplateData && vTemplateData.length > 0) {
      columnList = Object.keys(vTemplateData[0]);
    }

    vTemplateData.map((logTemplate) => {
      columnList.map((col) => {
        if (
          logTemplate[col] &&
          logTemplate[col].toString().split("-").length > 1
        ) {
          const de = logTemplate[col].split("-")[0];
          const cc = logTemplate[col].split("-")[1];

          if (col == "__EMPTY_17") {
            csvLine += `${de},${period},${orgUnit},${cc},,0,,,,,\n`;
          } else {
            if (
              !(
                col === "__EMPTY_23" ||
                col === "__EMPTY_24" ||
                col === "__EMPTY_32" ||
                col === "__EMPTY_33"
              )
            ) {
              csvLine += `${de},${period},${orgUnit},${cc},,,,,,,true\n`;
            }
          }
        }
      });
    });

    // let mutation = {
    //   resource: "dataValueSets",
    //   type: "create",
    //   data: {
    //     period: this.state.selectedMonthYear,
    //     orgUnit: this.state.selectedFacility,
    //     dataValues: dataValues,
    //   },
    // };

    //return mutation;

    // return  "dataelement,period,orgunit,categoryoptioncombo,attributeoptioncombo,value,storedby,lastupdated,comment,followup,deleted\n"+
    // "tAy4VENAVWJ,202310,NkSHKrlCUho,f8tqseFk9CK,,,,,,,true\n"+
    // "pA6CFxovxdh,202310,NkSHKrlCUho,X8TZ8BA9Q5w,,,,,,,true\n"+
    // "LboUxEvXXDW,202310,NkSHKrlCUho,XxPpu51hMrn,,0,,,,,\n";

    // console.log("csvLine: ", csvLine);

    return csvLine;
  }

  facilityGridData() {
    let searchFacility = this.state.searchFacility;
    let orgUnits = this.state.orgUnits.filter((orgUnit) => {
      if (
        orgUnit.id != "default" &&
        orgUnit.displayName.toLowerCase().includes(searchFacility)
      ) {
        return orgUnit;
      }
    });
    let dataSetRegistrations = this.state.dataSetRegistrations;

    let GridData = orgUnits.map((orgUnit) => {
      let newOrgUnit = {
        period: "",
        dataSet: "",
        organisationUnit: "",
        attributeOptionCombo: "",
        date: "",
        storedBy: "",
        completed: false,
        id: orgUnit.id,
        displayName: orgUnit.displayName,
      };

      dataSetRegistrations.map((dataSet) => {
        if (orgUnit.id == dataSet.organisationUnit) {
          newOrgUnit["period"] = dataSet.period;
          newOrgUnit["dataSet"] = dataSet.dataSet;
          newOrgUnit["organisationUnit"] = dataSet.organisationUnit;
          newOrgUnit["attributeOptionCombo"] = dataSet.attributeOptionCombo;
          newOrgUnit["date"] = dataSet.date;
          newOrgUnit["storedBy"] = dataSet.storedBy;
          newOrgUnit["completed"] = dataSet.completed;
        }
      });
      return newOrgUnit;
    });
    return GridData;
  }

  calculateImportStatus() {
    if (this.state.orgUnits.length > 1) {
      let facilityCount = this.state.orgUnits.filter(
        (orgUnit) => orgUnit.id != "default"
      ).length;
      let importStatusCount = 0;
      if (
        this.state.dataSetRegistrations &&
        this.state.dataSetRegistrations.length
      ) {
        importStatusCount = this.state.dataSetRegistrations.filter(
          (dataSet) => dataSet.completed === true
        ).length;
      }
      let percentage = 0;
      try {
        percentage = ((importStatusCount / facilityCount) * 100).toFixed(1);
      } catch {
        percentage = 0;
      }
      return (
        percentage +
        "% (" +
        importStatusCount +
        "/" +
        facilityCount +
        " Facilities)"
      );
    }
  }

  getOrgUnitGroups(res) {
    res.unshift({ id: "default", displayName: "Select VEN Organisation Unit" });
    this.setState({
      getOrgUnits: false,
      orgUnits: res,
    });
  }

  redirectToFirstStep() {
    this.setState({
      firstStep: true,
      secondStep: false,
      dataFixSecondStep: false,
      thirdStep: false,
      fourthStep: false,
      fifthStep: false,
      items: [],
      resultStatus: null,
      fileName: null,
      selectedFacility: this.state.venMutationData.VENOrganisationUnitGroup,
      uploadedFile: null,
      getOrgUnits: true,
      getDataSetRegistrations: true,
      dataSetRegistrations: [],
      AMCs: [],
      MOSs: [],
      showDuplicateProducts: false,
      gridHeadingTitle: null,
      loading: false,
      duplicateProducts: [],
      blankOrNegativeRocords: [],
      bDataValuesResponsed: true,
    });
  }

  handleFirstStep(selectedOrgUnit) {
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      secondStep: true,
      selectedFacility: selectedOrgUnit.id,
    });
  }

  handleDataFixFirstStep(selectedOrgUnit) {
    // if (this.validateFirstStep()==false) {
    //   return true
    // }
    this.setState({
      firstStep: false,
      dataFixSecondStep: true,
      selectedFacility: selectedOrgUnit.id,
    });
  }

  handleDataValuesResponse(data) {
    console.log("handleDataValuesResponse: ", data);
    this.setState({
      fixDataValues: data,
      bDataValuesResponsed: false,
      bDataValuesLoaded: true,
    });
  }

  deleteUploadedFile(selectedOrgUnit) {
    this.setState({
      getDataSetRegistrations: true,
      deleteUploadedFile: true,
      selectedFacility: selectedOrgUnit.id,
      loading: true,
    });
  }

  handleSecondStep() {
    if (this.state.selectedFacility == "default") {
      let error = "Please select a facility";
      this.setState({ error });
      return true;
    }
    if (this.state.uploadedFile == null) {
      let error = "Please upload the Excel file you want to import";
      this.setState({ error });
      return true;
    }
    this.readDataFromExcel();
    this.setState({
      loading: true,
    });
  }

  handleDataFixSecondStep() {
    console.log("handleDataFixSecondStep");
    if (this.state.selectedFacility == "default") {
      let error = "Please select a facility";
      this.setState({ error });
      return true;
    }
    this.setState({
      loading: true,
      bShowDataFixCalculation: true,
      dataFixBtnDisabled: true,
      dataFixBtnBack: true,
    });
  }

  handleChangeFacility(e, name) {
    if (name == "selectFacility") {
      this.setState({ selectedFacility: e.selected, error: null });
    } else {
      this.setState({
        selectedMonthYear: e.selected,
        error: null,
        getDataSetRegistrations: true,
        dataSetRegistrations: [],
        bDataValuesResponsed: true,
      });
    }
  }
  resposeSaveJson(called, loading, error) {
    if (loading && called && error) {
      this.setState({ error });
    }
  }

  saveDataSetRegistration(response) {
    this.setState({
      getDataSetRegistrations: true,
      setDataSetRegistration: false,
      deleteUploadedFile: false,
      afterDeleteUploadedFile: false,
      loading: false,
    });
  }

  getCompleteDataSet(response) {
    this.setState({ getDataSetRegistrations: false });
    if (
      response &&
      response.result &&
      response.result.completeDataSetRegistrations
    ) {
      this.setState({
        dataSetRegistrations: response.result.completeDataSetRegistrations,
      });
    }
  }

  closeAlertBar() {
    this.setState({ error: null });
  }

  closeAlertBarMsg() {
    this.setState({ successMsg: null });
  }

  validate() {
    let flag = true;
    let error = null;

    if (this.state.uploadedFile == null) {
      flag = false;
      error = "Please upload the Excel file you want to import";
    }

    if (this.state.selectedFacility == "default") {
      flag = false;
      error = "Please select a facility";
    }
    if (flag == false) {
      this.setState({ error });
    }
    return flag;
  }

  validateFirstStep() {
    let flag = true;
    if (this.state.masterTemplateError) {
      this.setState({
        error:
          "Template file " +
          this.state.venMutationData.VENMasterTemplate +
          " does not exist",
      });
      flag = false;
    }
    return flag;
  }

  changePanel() {
    if (this.validate() == false) {
      return true;
    }
    if (this.state.secondStep) {
      this.setState({
        secondStep: !this.state.secondStep,
        items: [],
        resultStatus: null,
        fileName: null,
        selectedFacility: this.state.venMutationData.VENOrganisationUnitGroup,
        selectedMonthYear: null,
        uploadedFile: null,
      });
    } else {
      this.readDataFromExcel();
      this.setState({
        loading: true,
      });
    }
  }

  readExcel(file) {
    this.setState({
      uploadedFile: file,
      fileName: file.name,
      error: null,
    });
  }
  readDataFromExcel() {
    const promise = new Promise((resolve, reject) => {
      let file = this.state.uploadedFile;
      let selectedMonthYear = this.state.selectedMonthYear;
      const fileReader = new FileReader();

      fileReader.readAsArrayBuffer(file);

      let months = [
        "JANUARY",
        "FEBRUARY",
        "MARCH",
        "APRIL",
        "MAY",
        "JUNE",
        "JULY",
        "AUGUST",
        "SEPTEMBER",
        "OCTOBER",
        "NOVEMBER",
        "DECEMBER",
      ];

      let year = selectedMonthYear.substring(0, 4);
      let workSheetFormat = this.state.venMutationData.LMISWorksheetName;
      var yCount = 0;
      for (var position = 0; position < workSheetFormat.length; position++) {
        if (workSheetFormat.charAt(position).toUpperCase() == "Y") {
          yCount += 1;
        }
      }
      if (yCount != 4) {
        year = year.substring(2);
      }

      var mCount = 0;
      for (var position = 0; position < workSheetFormat.length; position++) {
        if (workSheetFormat.charAt(position).toUpperCase() == "M") {
          mCount += 1;
        }
      }
      let monthName = months[
        parseInt(selectedMonthYear.substring(4, 6)) - 1
      ].substring(0, mCount);
      let sheetName = workSheetFormat
        .replace("{MMM}", monthName)
        .replace("{MM}", monthName)
        .replace("{YYYY}", year)
        .replace("{YY}", year)
        .toUpperCase();
      let _this = this;

      // File reading
      fileReader.onload = (e) => {
        const bufferArray = e.target.result;
        let wb = null;
        let sheetNames = null;
        let wsname = null;

        try {
          wb = XLSX.read(bufferArray, { type: "buffer", cellStyles: true });
        } catch (error) {
          this.setState({
            error: "Password protected files are not allowed",
            loading: false,
          });
        }

        if (wb) {
          sheetNames = wb.SheetNames.map((sheet) => sheet.toUpperCase());
        }

        const customHeaders = [
          "__EMPTY",
          "__EMPTY_1",
          "__EMPTY_2",
          "__EMPTY_3",
          "__EMPTY_4",
          "__EMPTY_5",
          "__EMPTY_6",
          "__EMPTY_7",
          "__EMPTY_8",
          "__EMPTY_9",
          "__EMPTY_10",
          "__EMPTY_11",
          "__EMPTY_12",
          "__EMPTY_13",
          "__EMPTY_14",
          "__EMPTY_15",
          "__EMPTY_16",
          "__EMPTY_17",
          "__EMPTY_18",
        ];

        if (sheetName && sheetNames && sheetNames.indexOf(sheetName) != -1) {
          wsname = wb.SheetNames[sheetNames.indexOf(sheetName)];
          const ws = wb.Sheets[wsname];
          const data = XLSX.utils.sheet_to_json(ws, {
            range: 1,
            header: customHeaders,
          });
          resolve(data);
        } else {
          this.setState({
            error:
              "File does not contain " +
              sheetName +
              " worksheet. Unable to proceed",
            loading: false,
          });
        }
      };

      fileReader.onerror = (error) => {
        reject(error);
      };
    });

    promise.then((items) => {
      let headingTitle = {
        facilityName: "Facility Name",
        monthName: "Month",
        year: "Year",
      };

      // // Finding the key with "Facility Name", the row index, and the next key-value pair (Facility Name value)
      // let facilityNameKey = null;
      // let facilityNameRowIndex = -1;
      // let nextKeyValueOfFacility = null;

      // for (let i = 0; i < items.length; i++) {
      //   const row = items[i];
      //   const keys = Object.keys(row);

      //   for (let j = 0; j < keys.length; j++) {
      //     if (row[keys[j]] === "Facility Name") {

      //       facilityNameKey = keys[j];
      //       console.log('facilityNameKey999999: ', facilityNameKey);
      //       facilityNameRowIndex = i;

      //       // Check if the next key exists
      //       if (j + 1 < keys.length) {
      //         const nextKey = keys[j + 1];
      //         nextKeyValueOfFacility = { key: nextKey, value: row[nextKey] };
      //       }
      //       break;
      //     }
      //   }
      //   if (facilityNameRowIndex !== -1) break;
      // }

      // console.log("Facility Name Key:", facilityNameKey);
      // console.log("Facility Name Row Index:", facilityNameRowIndex);
      // console.log("Next Key-Value Pair Facility Name:", nextKeyValueOfFacility);

      // if (!nextKeyValueOfFacility) {
      //   this.setState({
      //     loading: false,
      //     error: "Facility Name is missing in uploaded file",
      //   });
      //   return true;
      // }

      // const facilityName = nextKeyValueOfFacility.value;
      // console.log("facilityName: ", facilityName);

      // // Finding the key with "Date Received", the row index, and the next key-value pair (Date Received value)
      // let dateReceivedKey = null;
      // let dateReceivedRowIndex = -1;
      // let nextKeyValueOfDateReceived = null;

      // for (let i = 0; i < items.length; i++) {
      //   const row = items[i];
      //   const keys = Object.keys(row);

      //   for (let j = 0; j < keys.length; j++) {
      //     if (row[keys[j]] === "Date Received") {
      //       dateReceivedKey = keys[j];
      //       dateReceivedRowIndex = i;

      //       // Check if the next key exists
      //       if (j + 1 < keys.length) {
      //         const nextKey = keys[j + 1];
      //         nextKeyValueOfDateReceived = {
      //           key: nextKey,
      //           value: row[nextKey],
      //         };
      //       }
      //       break;
      //     }
      //   }
      //   if (dateReceivedRowIndex !== -1) break;
      // }

      // console.log("Date Received Key:", dateReceivedKey);
      // console.log("Date Received Row Index:", dateReceivedRowIndex);
      // console.log(
      //   "Next Key-Value Pair Date Received:",
      //   nextKeyValueOfDateReceived
      // );

      // if (!nextKeyValueOfDateReceived) {
      //   this.setState({
      //     loading: false,
      //     error: "Date Received is missing in uploaded file",
      //   });
      //   return true;
      // }

      // const dateReceived = nextKeyValueOfDateReceived.value;
      // console.log("dateReceived: ", dateReceived);

      // // Finding the key with "Reporting Period \n(Month & Year)", the row index, and the next key-value pair (Month value, Year value)
      // let reportingPeriodKey = null;
      // let reportingPeriodRowIndex = -1;
      // let nextKeyValueOfReportingPeriod = null;
      // let nextKeyValue2OfReportingPeriod = null;

      // for (let i = 0; i < items.length; i++) {
      //   const row = items[i];
      //   const keys = Object.keys(row);

      //   for (let j = 0; j < keys.length; j++) {
      //     if (row[keys[j]] === "Reporting Period \n(Month & Year)") {
      //       reportingPeriodKey = keys[j];
      //       reportingPeriodRowIndex = i;

      //       // Check if the next key exists
      //       if (j + 1 < keys.length) {
      //         const nextKey = keys[j + 1];
      //         const nextKey2 = keys[j + 2];
      //         nextKeyValueOfReportingPeriod = {
      //           key: nextKey,
      //           value: row[nextKey],
      //         };
      //         nextKeyValue2OfReportingPeriod = {
      //           key: nextKey2,
      //           value: row[nextKey2],
      //         };
      //       }
      //       break;
      //     }
      //   }
      //   if (reportingPeriodRowIndex !== -1) break;
      // }

      // console.log("Reporting Period Key:", reportingPeriodKey);
      // console.log("Reporting Period Row Index:", reportingPeriodRowIndex);
      // console.log(
      //   "Next Key-Value Pair of Year:",
      //   nextKeyValueOfReportingPeriod
      // );
      // console.log(
      //   "Next Key-Value Pair of MonthName:",
      //   nextKeyValue2OfReportingPeriod
      // );

      // if (!nextKeyValueOfReportingPeriod) {
      //   this.setState({
      //     loading: false,
      //     error: "Year is missing in uploaded file",
      //   });
      //   return true;
      // }
      // if (!nextKeyValue2OfReportingPeriod) {
      //   this.setState({
      //     loading: false,
      //     error: "Month is missing in uploaded file",
      //   });
      //   return true;
      // }

      // const year = nextKeyValueOfReportingPeriod.value;
      // console.log("year: ", year);
      // const monthName = nextKeyValue2OfReportingPeriod.value;
      // console.log("monthName: ", monthName);
      //////////////////////////////

      const facilityNameObject = items.find(
        (item) => item.__EMPTY_1 === "Facility Name"
      );

      if (!facilityNameObject) {
        this.setState({
          loading: false,
          error: "Facility Name text is missing in uploaded file",
        });
        return true;
      }

      const facilityName = facilityNameObject
        ? facilityNameObject.__EMPTY_2
        : "";

      if (!facilityName) {
        this.setState({
          loading: false,
          error: "Facility Name value is missing in uploaded file",
        });
        return true;
      }

      const dateReceivedObject = items.find(
        (item) => item.__EMPTY_8 === "Date Received"
      );
      if (!dateReceivedObject) {
        this.setState({
          loading: false,
          error: "Date Received text is missing in uploaded file",
        });
        return true;
      }
      const dateReceived = dateReceivedObject
        ? dateReceivedObject.__EMPTY_9
        : "Not found";
      if (!dateReceived) {
        this.setState({
          loading: false,
          error: "Date Received value is missing in uploaded file",
        });
        return true;
      }

      const year = dateReceivedObject
        ? dateReceivedObject.__EMPTY_14
        : "Not found";
      if (!year) {
        this.setState({
          loading: false,
          error: "Year value is missing in uploaded file",
        });
        return true;
      }

      const monthName = dateReceivedObject
        ? dateReceivedObject.__EMPTY_12
        : "Not found";
      if (!monthName) {
        this.setState({
          loading: false,
          error: "Month Name value is missing in uploaded file",
        });
        return true;
      }

      console.log("facilityName: ", facilityName);
      console.log("Date Received:", dateReceived);
      console.log("year: ", year);
      console.log("monthName: ", monthName);

      if (items && items.length && facilityName && monthName) {
        headingTitle = {
          facilityName: facilityName,
          monthName: monthName,
          year: year,
        };
      }
      // let start_row_number = 6
      // if(this.state.venMutationData.LMISWorksheetStartRow){
      //   start_row_number = parseInt(this.state.venMutationData.LMISWorksheetStartRow.replace(/\D/g,''))
      // }
      let receiveDateValue = "";

      console.log("All rows in items: ", items);

      if (items && items.length && items[2] && /^\d+$/.test(dateReceived)) {
        let baseDate = new Date("1900-01-01");
        baseDate.setDate(baseDate.getDate() + (parseInt(dateReceived) - 2));
        receiveDateValue =
          baseDate.getFullYear() +
          "-" +
          String(baseDate.getMonth() + 1).padStart(2, "0") +
          "-" +
          String(baseDate.getDate()).padStart(2, "0");
      }
      // items = items.slice(start_row_number,items.length);

      const codeIndex = items.findIndex((item) => item.__EMPTY === "Code");
      const nextEmptyIndex = items
        .slice(codeIndex + 1)
        .findIndex((item) => item.__EMPTY !== undefined);

      if (codeIndex === -1) {
        this.setState({
          loading: false,
          error: "Code text is missing in uploaded file",
        });
        return true;
      }

      const prodRowIndex =
        nextEmptyIndex !== -1 ? codeIndex + 1 + nextEmptyIndex : "Not found";

      console.log("Next row index with __EMPTY after 'Code':", prodRowIndex);

      // Remove all rows before prodRowIndex
      items = items.slice(prodRowIndex);

      console.log("Filtered items:", items);

      // items = items.filter(
      //   (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
      // );

      if (items.length == 0) {
        this.setState({ error: "Data not available in file", loading: false });
        return true;
      }

      this.setState({
        headingTitle,
        items,
      });
      this.generateJson(items, receiveDateValue);
    });
  }

  generateJson(items, receiveDateValue) {
    if (!receiveDateValue) {
      this.setState({
        loading: false,
        error: "'Receive Date is missing in uploaded file",
      });
      return true;
    }

    let receiveDate = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    let timelyStatus = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    let lateStatus = {
      dataElement: "",
      categoryOptionCombo: "",
      value: "",
    };

    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[2].__EMPTY_9 &&
      this.state.vTemplateData[2].__EMPTY_21 &&
      this.state.vTemplateData[2].__EMPTY_22
    ) {
      let receiveDateKey = this.state.vTemplateData[2].__EMPTY_9;
      let reportTimelyStatus = this.state.vTemplateData[2].__EMPTY_21;
      let reportLateStatus = this.state.vTemplateData[2].__EMPTY_22;

      if (receiveDateKey && reportTimelyStatus && reportLateStatus) {
        receiveDate["dataElement"] = receiveDateKey.split("-")[0];
        receiveDate["categoryOptionCombo"] = receiveDateKey.split("-")[1];
        receiveDate["value"] = receiveDateValue;

        let year = receiveDateValue.split("-")[0];
        let month = receiveDateValue.split("-")[1];
        let day = receiveDateValue.split("-")[2];

        let receiveDt = new Date(year, month, day);

        let nextMonthYear = this.getNextPeriod(this.state.selectedMonthYear);

        let nxtYear = parseInt(nextMonthYear.substring(0, 4));
        let nxtMonth = parseInt(nextMonthYear.substring(4));

        let lastSubmissionDt = new Date(nxtYear, nxtMonth, 10);

        timelyStatus["dataElement"] = reportTimelyStatus.split("-")[0];
        timelyStatus["categoryOptionCombo"] = reportTimelyStatus.split("-")[1];

        lateStatus["dataElement"] = reportLateStatus.split("-")[0];
        lateStatus["categoryOptionCombo"] = reportLateStatus.split("-")[1];

        const one = 1;
        const zero = 0;

        if (receiveDt <= lastSubmissionDt) {
          timelyStatus["value"] = one.toFixed(1);
          lateStatus["value"] = zero.toFixed(1);
        } else {
          timelyStatus["value"] = zero.toFixed(1);
          lateStatus["value"] = one.toFixed(1);
        }
      }
    }

    let totalLossKey = null;
    let totalBalanceKey = null;
    let countAllProductKey = null;
    let countNonZeroKey = null;
    let totalLossValue = [];
    let totalBalanceValue = [];
    let countAllProductValue = null;
    let countNonZeroValue = null;

    if (
      this.state.vTemplateData &&
      this.state.vTemplateData[2] &&
      this.state.vTemplateData[2].__EMPTY_23 &&
      this.state.vTemplateData[2].__EMPTY_24 &&
      this.state.vTemplateData[2].__EMPTY_25 &&
      this.state.vTemplateData[2].__EMPTY_26
    ) {
      totalBalanceKey = this.state.vTemplateData[2].__EMPTY_23;
      totalLossKey = this.state.vTemplateData[2].__EMPTY_24;
      countAllProductKey = this.state.vTemplateData[2].__EMPTY_25;
      countNonZeroKey = this.state.vTemplateData[2].__EMPTY_26;
      items.map((item) => {
        let currentPrice = this.state.vTemplateCmsVenData.find(
          (vtemplateItem) => vtemplateItem["Code"] == item["__EMPTY"]
        );

        if (
          currentPrice &&
          (currentPrice["CurrentPrice"] || currentPrice["CurrentPrice"] == 0)
        ) {
          totalLossValue.push(
            parseFloat(item["__EMPTY_8"]) *
              parseFloat(currentPrice["CurrentPrice"])
          );
          totalBalanceValue.push(
            parseFloat(item["__EMPTY_11"]) *
              parseFloat(currentPrice["CurrentPrice"])
          );
        }
      });
      totalLossValue = Math.round(totalLossValue.reduce((a, b) => a + b, 0));
      totalBalanceValue = Math.round(
        totalBalanceValue.reduce((a, b) => a + b, 0)
      );
      countAllProductValue = items.length;
      countNonZeroValue = items.filter(
        (logItem) => logItem["__EMPTY_11"] != 0
      ).length;
    }

    let vTemplateData = this.state.vTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );

    let columnList = [
      "__EMPTY_5",
      "__EMPTY_6",
      "__EMPTY_7",
      "__EMPTY_8",
      "__EMPTY_9",
      "__EMPTY_10",
      "__EMPTY_11",
      "__EMPTY_12",
      "__EMPTY_13",
      "__EMPTY_14",
      "__EMPTY_15",
      "__EMPTY_16",
      "__EMPTY_17",
    ];

    // "__EMPTY": "Code",
    // "__EMPTY_1": "Product Description / Specifications",
    // "__EMPTY_2": "class",
    // "__EMPTY_3": "VEN",
    // "__EMPTY_4": "Unit of Issue",
    // "__EMPTY_5": "Beginning Balance",
    // "__EMPTY_6": "Quantity received during the reporting period",
    // "__EMPTY_7": "Quantity Issued  during the reporting period",
    // "__EMPTY_8": "Losses  ",
    // "__EMPTY_9": "Adjustments"
    // "__EMPTY_10": "Ending Balance (Book)",
    // "__EMPTY_11": "Ending Balance (Physical)",
    // "__EMPTY_12": "Stock quantity with less than 3 months shelf life ",
    // "__EMPTY_13": "No. of Days Stocked Out",
    // "__EMPTY_14": "Quantity Required/ ordered",
    // "__EMPTY_15": "Comments",
    // "__EMPTY_16": "AMC",
    // "__EMPTY_17": "Adjustment Type",
    // "__EMPTY_21": "Price",
    // "__EMPTY_22": "MOS",
    // "__EMPTY_23": "Quantity Issued PreMonth",
    // "__EMPTY_24": "Quantity Issued PrePreMonth",
    // "__EMPTY_25": "Stockout",
    // "__EMPTY_26": "Emergency",
    // "__EMPTY_27": "Understock",
    // "__EMPTY_28": "Adequate",
    // "__EMPTY_29": "Overstock",
    // "__EMPTY_30": "Closing Zero Stock",
    // "__EMPTY_31": "Non-Use",

    let dataValues = [];
    let gridDataValues = [];
    let templateEmptyKeys = [];
    let _this = this;

    if (
      totalLossKey &&
      totalBalanceKey &&
      countAllProductKey &&
      countNonZeroKey
    ) {
      dataValues.push({
        dataElement: totalLossKey.split("-")[0],
        categoryOptionCombo: totalLossKey.split("-")[1],
        value: totalLossValue,
      });
      dataValues.push({
        dataElement: totalBalanceKey.split("-")[0],
        categoryOptionCombo: totalBalanceKey.split("-")[1],
        value: totalBalanceValue,
      });
      dataValues.push({
        dataElement: countAllProductKey.split("-")[0],
        categoryOptionCombo: countAllProductKey.split("-")[1],
        value: countAllProductValue,
      });
      dataValues.push({
        dataElement: countNonZeroKey.split("-")[0],
        categoryOptionCombo: countNonZeroKey.split("-")[1],
        value: countNonZeroValue,
      });
    }

    items.forEach((item) => {
      let flag = true;

      if (!item.hasOwnProperty("__EMPTY")) {
        return;
      }

      vTemplateData.forEach((vTemplate) => {
        if (vTemplate["__EMPTY"] == item["__EMPTY"]) {
          flag = false;
          let newItem = {};
          newItem["__EMPTY"] = item["__EMPTY"];
          newItem["__EMPTY_1"] = item["__EMPTY_1"];
          newItem["__EMPTY_2"] = item["__EMPTY_2"];
          newItem["__EMPTY_3"] = item["__EMPTY_3"];
          newItem["__EMPTY_4"] = item["__EMPTY_4"];
          columnList.map((col) => {
            if (col == "__EMPTY_14" || col == "__EMPTY_16") {
              if (item[col]) {
                item[col] = Math.round(item[col]);
              }
            }
            newItem[col] = item[col];
            if (
              typeof vTemplate[col] == "string" &&
              vTemplate[col].split("-").length > 1
            ) {
              if (col != "__EMPTY_17") {
                if (col == "__EMPTY_14" && item[col] < 0) {
                  item[col] = 0;
                }
                if (item[col] || item[col] == 0) {
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: item[col],
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                } else {
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    deleted: true,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                }
              } else {
                if (item[col] || item[col] == 0) {
                  let adjustmentType = item[col].trim();
                  let adjustmentValue = 0;
                  let option = {};
                  if (
                    _this.state.optionSetsData &&
                    _this.state.optionSetsData.length > 0
                  ) {
                    option = _this.state.optionSetsData.find((option) =>
                      option.displayName
                        .toLowerCase()
                        .includes(adjustmentType.toLowerCase())
                    );
                  }
                  if (option && option.code) {
                    adjustmentValue = parseInt(option.code);
                  } else {
                    adjustmentValue = item[col].toString().trim();
                  }
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: adjustmentValue,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                } else {
                  // If "Adjustment Type" is Empty
                  dataValues.push({
                    dataElement: vTemplate[col].split("-")[0],
                    categoryOptionCombo: vTemplate[col].split("-")[1],
                    value: 0,
                  });
                  newItem[col] = { key: vTemplate[col], value: item[col] };
                }
              }
            }
          });
          gridDataValues.push(newItem);
        }
      });

      if (flag) {       
        let newItem = {};
        newItem["__EMPTY"] = item["__EMPTY"];
        newItem["__EMPTY_1"] = item["__EMPTY_1"];
        newItem["__EMPTY_2"] = item["__EMPTY_2"];
        newItem["__EMPTY_3"] = item["__EMPTY_3"];
        newItem["__EMPTY_4"] = item["__EMPTY_4"];
        columnList.map((col) => {
          if (col == "__EMPTY_14" || col == "__EMPTY_16") {
            if (item[col]) {
              item[col] = Math.round(item[col]);
            }
          }
          newItem[col] = item[col];
        });
        templateEmptyKeys.push(newItem.__EMPTY);
        gridDataValues.push(newItem);
      }
    });

    dataValues.push(receiveDate);
    dataValues.push(timelyStatus);
    dataValues.push(lateStatus);

    if (dataValues.length > 0 && gridDataValues.length > 0) {
      // for found blank/negative products
      let checkColumns = [
        "__EMPTY_5",
        "__EMPTY_6",
        "__EMPTY_7",
        "__EMPTY_8",
        "__EMPTY_9",
        "__EMPTY_10",
        "__EMPTY_11",
        "__EMPTY_13",
        "__EMPTY_16",
      ];
      let blankOrNegativeRocords = gridDataValues.filter((item) => {
        let flag = false;
        checkColumns.map((col) => {
          if (
            item[col] &&
            typeof item[col] == "object" &&
            (item[col].value == undefined ||
              (col != "__EMPTY_9" &&
                item[col].value &&
                Math.sign(item[col].value) == -1))
          ) {
            flag = true;
          }
        });
        if (flag) {
          return item;
        }
      });

      // for found duplicate products
      let dataValuesCode = gridDataValues.map((item) => item["__EMPTY"]);
      let counts = {};
      let duplicateRecords = [];
      for (let i = 0; i < dataValuesCode.length; i++) {
        if (counts[dataValuesCode[i]]) {
          counts[dataValuesCode[i]] += 1;
        } else {
          counts[dataValuesCode[i]] = 1;
        }
      }
      for (let prop in counts) {
        if (counts[prop] >= 2) {
          duplicateRecords.push(prop);
        }
      }
      if (duplicateRecords.length == 0 && blankOrNegativeRocords.length == 0) {
        let vJsonData = {
          resource: "dataValueSets",
          type: "create",
          data: {
            period: this.state.selectedMonthYear,
            orgUnit: this.state.selectedFacility,
            dataValues: dataValues,
          },
        };

        this.setState({
          templateEmptyKeys,
          gridDataValues: gridDataValues.filter(
            (item) =>
              !(item["__EMPTY"] && templateEmptyKeys.includes(item["__EMPTY"]))
          ),
          missingProducts: gridDataValues.filter(
            (item) =>
              item["__EMPTY"] && templateEmptyKeys.includes(item["__EMPTY"])
          ),
          vJsonData,
          saveJsonData: true,
        });
      } else {
        this.setState({
          templateEmptyKeys,
          gridDataValues,
          blankOrNegativeRocords,
          duplicateProducts: gridDataValues.filter((item) =>
            duplicateRecords.includes(item["__EMPTY"])
          ),
          showDuplicateProducts: true,
          conflictKeyList: duplicateRecords,
          conflictStatus: true,
          gridHeadingTitle: "Duplicate Products",
          firstStep: false,
          secondStep: false,
          loading: false,
        });
      }
    } else {
      this.setState({
        error: "Template file key's didn't match with uploaded file",
        loading: false,
      });
    }
  }

  generatePeriods(defaultYear, defaultMonth) {
    if (defaultMonth == 0) {
      defaultYear = defaultYear - 1;
      defaultMonth = 12;
    }
    let months = Constants.MONTH_NAME;
    let periods = [];
    let currentyear = new Date().getFullYear();
    if (currentyear !== defaultYear) {
      defaultMonth = 12;
    }
    for (let i = defaultMonth - 1; i >= 0; i--) {
      let option = {};
      option["name"] = months[i] + " " + defaultYear;
      option["id"] = defaultYear + String(i + 1).padStart(2, "0");
      periods.push(option);
    }
    if (this.state.deleteUploadedFile) {
      this.setState({
        periods,
        dataSetRegistrations: [],
      });
    } else {
      this.setState({
        periods,
        selectedMonthYear: periods[0].id,
        dataSetRegistrations: [],
      });
    }
  }

  setPeriods(year) {
    if (year == "previous") {
      this.setState({
        defaultYear: this.state.defaultYear - 1,
        getDataSetRegistrations: true,
        bDataValuesResponsed: true,
      });
      this.generatePeriods(this.state.defaultYear - 1, this.state.defaultMonth);
    } else {
      let currentyear = new Date().getFullYear();
      if (currentyear !== this.state.defaultYear) {
        this.setState({
          defaultYear: this.state.defaultYear + 1,
          getDataSetRegistrations: true,
          bDataValuesResponsed: true,
        });
        this.generatePeriods(
          this.state.defaultYear + 1,
          this.state.defaultMonth
        );
      }
    }
  }

  getOptionSetsResponse(data) {
    if (data && data.options) {
      this.setState({
        getOptionSets: false,
        optionSetsData: data.options.options,
        getOrgUnits: true,
        getDataSetRegistrations: true,
      });
    }
  }

  getGeneralSettingsResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        generalMutationData: data.dataStore,
        getGeneralSettings: false,
        getVenTemplateData: true,
        // getOptionSets: true
      });
    }
  }

  getAppSettingsResponse(data) {
    if (data && data.dataStore) {
      this.setState({
        venMutationData: data.dataStore,
        selectedFacility: data.dataStore.VENOrganisationUnitGroup,
        getAppSettings: false,
        getGeneralSettings: true,
      });
    }
  }

  getVenTemplateSettings(data) {
    if (data && data.dataStore) {
      this.setState({
        vTemplateData: data.dataStore,
        getVenTemplateData: false,
        // getOptionSets: true,
        getCmsVenTemplateSettings: true,
      });
    } else {
      this.setState({
        loading: false,
        error: "Ven Template JSON missing!",
      });
    }
  }

  uploadAmcMosResponse = (response, AMCs, MOSs) => {
    console.log("response: ", response);
    if (response.conflicts.length > 0) {
      alert(
        "Uploading AMC and MOS has coflicts: " +
          JSON.stringify(response.conflicts)
      );
      this.setState({
        loading: false,
        error: "Uploading AMC and MOS has coflicts",
      });
    } else {
      this.setState({
        fourthStep: true,
        thirdStep: false,
        loading: false,
        AMCs,
        MOSs,
      });
    }
  };

  dataFixUploadAmcMosResponse = (response, AMCs, MOSs) => {
    console.log("response: ", response);
    if (response.conflicts.length > 0) {
      this.setState({
        loading: false,
        bShowDataFixCalculation: false,
        error: JSON.stringify(response.conflicts),
      });
    } else {
      this.setState({
        loading: false,
        bShowDataFixCalculation: false,
        successMsg: "Data fixation completed",
        dataFixBtnDisabled: false,
        dataFixBtnBack: false,
      });
    }
  };
  getNextPeriod = (ym) => {
    //ym = "202103";
    let year = parseInt(ym.substring(0, 4));
    let month = parseInt(ym.substring(4));

    if (month == 12) {
      month = 1;
      year = year + 1;
    } else {
      month = month + 1;
    }

    ym = year + month.toString().padStart(2, "0");

    return ym;
  };

  render() {
    return (
      <>
        {this.state.getAppSettings && (
          <GetAppSettingsNew
            query={getAppSettingsQuery}
            onResponse={this.getAppSettingsResponse}
          />
        )}
        {this.state.getVenTemplateData && (
          <GetVenTemplateSettings
            query={venTemplateQuery}
            onResponse={this.getVenTemplateSettings}
          />
        )}
        {this.state.getCmsVenTemplateSettings && (
          <GetAppSettingsNew
            query={getCmsVenTemplateSettingsQuery}
            onResponse={this.getCmsVenTemplateSettingsResponse}
          />
        )}
        {this.state.getGeneralSettings && (
          <GetAppSettingsNew
            query={getGeneralSettingsQuery}
            onResponse={this.getGeneralSettingsResponse}
          />
        )}

        {this.state.getOptionSets && (
          <GetOptionSets
            query={getOptionSetsQuery}
            optionSetId={this.state.generalMutationData.AdjustmentOptionSet}
            onResponse={this.getOptionSetsResponse}
          />
        )}
        {this.state.fourthStep && (
          <ExcelImportAppLogsJson
            onComplete={(result) => {
              this.setState({
                fourthStep: false,
                fifthStep: true,
                loading: false,
              });
            }}
            query={mutationExcelImportAppLogsJson}
            importTemplateLogsJson={this.state.importTemplateLogsJson}
            onResponse={this.getExcelImportAppLogsJson}
          />
        )}
        {this.state.saveJsonData && (
          <InsertDataValueSets
            onComplete={(result) => {
              let conflictKeyList = [];
              let statusBtnIcon = null;
              let conflictStatus = false;
              if (result.conflicts && result.conflicts.length > 0) {
                conflictStatus = true;
              }
              result.conflicts.map((conflict) => {
                if (conflict.value) {
                  conflictKeyList.push(conflict.object.trim());
                }
              });
              let selectedFacility = this.state.orgUnits.find(
                (item) => item.id === this.state.selectedFacility
              );
              let importTemplateLogsJson = this.props.importTemplateLogs || [];
              importTemplateLogsJson.push({
                User: this.state.user.displayName,
                DateTime: new Date().toISOString(),
                FileName: this.state.fileName,
                FacilityName: selectedFacility
                  ? selectedFacility.displayName
                  : "",
                MonthYear: this.state.selectedMonthYear,
                Status: {
                  Message:
                    conflictKeyList.length == 0
                      ? "Import process completed successfully"
                      : "Import process completed with error",
                  conflicts: result.conflicts,
                },
              });
              this.setState({
                importTemplateLogsJson,
                conflictStatus,
                statusBtnIcon,
                conflictKeyList,
                saveJsonData: false,
                resultStatus: result.status,
                resInsertData: result,
                firstStep: false,
                secondStep: false,
                thirdStep: true,
                setDataSetRegistration: true,
              });
            }}
            vJsonData={this.state.vJsonData}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {/* {this.state.deleteUploadedFile && (
          <InsertDataValueSets
            onComplete={(result) => {
              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: false,
                afterDeleteUploadedFile: true,
              });
            }}
            vJsonData={this.deleteJsonData()}
            resposeSaveJson={this.resposeSaveJson}
          />
        )} */}
        {this.state.deleteUploadedFile && (
          <DeleteDataValues
            onComplete={(result) => {
              console.log("onComplete run....");

              this.setState({
                deleteUploadedFile: false,
                getDataSetRegistrations: false,
                afterDeleteUploadedFile: true,
              });
            }}
            vJsonData={this.deleteJsonData()}
            resposeSaveJson={this.resposeSaveJson}
          />
        )}
        {this.state.afterDeleteUploadedFile && (
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson={mutationDatasetRegJson}
            orgUnitId={this.state.selectedFacility}
            period={this.state.selectedMonthYear}
            completed={false}
            venMutationData={this.state.venMutationData}
            saveDataSetRegistration={this.saveDataSetRegistration}
          />
        )}
        {this.state.bDataValuesResponsed && (
          <DataValues
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            venMutationData={this.state.venMutationData}
            handleDataValuesResponse={this.handleDataValuesResponse}
          />
        )}
        {this.state.firstStep && (
          <FirstStep
            deleteUploadedFile={this.deleteUploadedFile}
            searchFacility={this.state.searchFacility}
            handleSearchFacility={this.handleSearchFacility}
            handleFirstStep={this.handleFirstStep}
            readExcel={this.readExcel}
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            dataSetRegistrations={this.state.dataSetRegistrations}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
            calculateImportStatus={this.calculateImportStatus}
            facilityGridData={this.facilityGridData}
            handleDataFixFirstStep={this.handleDataFixFirstStep}
            fixDataValues={this.state.fixDataValues}
          />
        )}
        {this.state.firstStep && this.state.getOrgUnits && (
          <GetOrgUnitGroups
            response={this.getOrgUnitGroups}
            orgUnitsQuery={orgUnitsQuery}
            venMutationData={this.state.venMutationData}
            selectedFacility={this.state.selectedFacility}
            handleError={this.handleError}
            stateError={this.state.error}
          />
        )}
        {this.state.firstStep && this.state.getDataSetRegistrations && (
          <GetCompleteDataSetRegistrations
            dataSetRegistrationQuery={dataSetRegistrationQuery}
            selectedMonthYear={this.state.selectedMonthYear}
            venMutationData={this.state.venMutationData}
            response={this.getCompleteDataSet}
            handleError={this.handleError}
            stateError={this.state.error}
          />
        )}
        {this.state.setDataSetRegistration && (
          <SetCompleteDataSetRegistrations
            mutationDatasetRegJson={mutationDatasetRegJson}
            orgUnitId={this.state.selectedFacility}
            period={this.state.selectedMonthYear}
            completed={true}
            venMutationData={this.state.venMutationData}
            saveDataSetRegistration={this.saveDataSetRegistration}
          />
        )}
        {(this.state.secondStep ||
          this.state.thirdStep ||
          this.state.fourthStep) && (
          <SecondStep
            handleSecondStep={this.handleSecondStep}
            readExcel={this.readExcel}
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
          />
        )}
        {this.state.thirdStep && this.state.resultStatus && (
          <CalculateAmcMos
            items={this.state.items}
            vTemplateData={this.state.vTemplateData}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            venMutationData={this.state.venMutationData}
            uploadAmcMosResponse={this.uploadAmcMosResponse}
          />
        )}
        {this.state.fifthStep && (
          <ImportProgressVenTemplate
            changePanel={this.changePanel}
            items={this.state.items}
            vJsonData={this.state.vJsonData}
            loading={this.state.loading}
            headingTitle={this.state.headingTitle}
            resInsertData={this.state.resInsertData}
            resultStatus={this.state.resultStatus}
            conflictStatus={this.state.conflictStatus}
            conflictKeyList={this.state.conflictKeyList}
            gridDataValues={this.state.gridDataValues}
            missingProducts={this.state.missingProducts}
            templateEmptyKeys={this.state.templateEmptyKeys}
            fileName={this.state.fileName}
            statusBtnIcon={this.state.statusBtnIcon}
            redirectToFirstStep={this.redirectToFirstStep}
            AMCs={this.state.AMCs}
            MOSs={this.state.MOSs}
          />
        )}
        {this.state.showDuplicateProducts && (
          <ShowDuplicateProducts
            duplicateProducts={this.state.duplicateProducts}
            blankOrNegativeRocords={this.state.blankOrNegativeRocords}
            showDuplicateProducts={this.state.showDuplicateProducts}
            redirectToFirstStep={this.redirectToFirstStep}
            gridHeadingTitle={this.state.gridHeadingTitle}
            gridDataValues={this.state.gridDataValues}
            changePanel={this.changePanel}
            resultStatus="ERROR"
            loading={this.state.loading}
            headingTitle={this.state.headingTitle}
            conflictStatus={this.state.conflictStatus}
            conflictKeyList={this.state.conflictKeyList}
            templateEmptyKeys={this.state.templateEmptyKeys}
            fileName={this.state.fileName}
          />
        )}

        {this.state.dataFixSecondStep && (
          <DataFixSecondStep
            loading={this.state.loading}
            error={this.state.error}
            closeAlertBar={this.closeAlertBar}
            successMsg={this.state.successMsg}
            closeAlertBarMsg={this.closeAlertBarMsg}
            handleChangeFacility={this.handleChangeFacility}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            orgUnits={this.state.orgUnits}
            defaultMonth={this.state.defaultMonth}
            defaultYear={this.state.defaultYear}
            periods={this.state.periods}
            setPeriods={this.setPeriods}
            handleDataFixSecondStep={this.handleDataFixSecondStep}
            redirectToFirstStep={this.redirectToFirstStep}
            dataFixBtnDisabled={this.state.dataFixBtnDisabled}
            dataFixBtnBack={this.state.dataFixBtnBack}
          />
        )}
        {this.state.bShowDataFixCalculation && (
          <DataFixCalculation
            items={this.state.items}
            vTemplateData={this.state.vTemplateData}
            selectedFacility={this.state.selectedFacility}
            selectedMonthYear={this.state.selectedMonthYear}
            venMutationData={this.state.venMutationData}
            dataFixUploadAmcMosResponse={this.dataFixUploadAmcMosResponse}
          />
        )}
      </>
    );
  }
}

export default ImportVenTemplate;
