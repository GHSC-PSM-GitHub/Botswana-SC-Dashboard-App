import React,  {useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import { useDataMutation, useDataQuery, DataQuery, useDataEngine } from '@dhis2/app-runtime';
import { useConfig } from "@dhis2/app-runtime";
import { postData } from '../../helpers/common'

const InsertDataValueSets = ({ onComplete, vJsonData, resposeSaveJson }) => {
  const [mutate, { called, loading, error, data }] = useDataMutation(vJsonData, {
      onComplete: onComplete
  })
	useEffect(() => {
    mutate();
  }, []);
  resposeSaveJson(called, loading, error);
  return (
    <>
    </>
  )
}

// const DeleteDataValues = ({ onComplete, vJsonData, resposeSaveJson }) => {
//   const { baseUrl } = useConfig();

//   const apiUrl = baseUrl + "/api/dataValueSets";

//   const [loading, setLoading] = useState(false);
//   const [called, setCalled] = useState(true);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     postData(apiUrl, vJsonData).then((data) => {
//       console.log('DeleteDataValues dhis2 respose: ', data);
//       onComplete();
//       resposeSaveJson(called, loading, error);
//     });
//   }, []);
//   return <></>;
// };

const GetOrgUnitGroups = ({ orgUnitsQuery, selectedFacility, venMutationData, response, handleError, stateError }) => {
  orgUnitsQuery.orgUnitGroups.id = venMutationData.VENOrganisationUnitGroup
  return(
    <DataQuery query={orgUnitsQuery}>
      {({ error, loading, data }) => {
        if (error && loading == false && (!stateError)){
          handleError("organisationUnitGroups... " + error.message);
        };
        if (loading) return <span>...</span>;
        if(error == undefined && loading == false && data && data.orgUnitGroups && data.orgUnitGroups.organisationUnits){
          let orgUnits = data.orgUnitGroups.organisationUnits.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1).filter((orgUnit)=> orgUnit.id !== "default")
          handleError(undefined);
          response(orgUnits);
        }
        return (
          <></>
        )
        }}
    </DataQuery>
  )
}

const GetCompleteDataSetRegistrations = ({ dataSetRegistrationQuery, selectedMonthYear, venMutationData, response, handleError, stateError}) => {
  dataSetRegistrationQuery.result.params.dataSet = venMutationData.VENDataset
  dataSetRegistrationQuery.result.params.period = selectedMonthYear
  dataSetRegistrationQuery.result.params.orgUnitGroup = venMutationData.VENOrganisationUnitGroup
  return(
    <DataQuery query={dataSetRegistrationQuery}>
      {({ error, loading, data }) => {
        if (error && loading == false && (!stateError)){
          handleError("completeDataSetRegistrations... "+ error.message);
        };
        if (loading) return <span>...</span>;
        if(error == undefined && loading == false && data){
          handleError(undefined);
          response(data);
        }
        return (<>
        </>)
        }}
    </DataQuery>
  )
}

const FetchDataValueSets = ({ reqGriedData, responceGriedData }) => {
  const { loading, error, data, refetch } = useDataQuery(reqGriedData)
  responceGriedData(loading, error, data, refetch );
  return (
    <>
    </>
  )
}

const SetCompleteDataSetRegistrations = ({mutationDatasetRegJson, orgUnitId, period, completed, venMutationData, saveDataSetRegistration}) => {
	mutationDatasetRegJson.data.completeDataSetRegistrations[0].organisationUnit = orgUnitId;
  mutationDatasetRegJson.data.completeDataSetRegistrations[0].period = period;
  mutationDatasetRegJson.data.completeDataSetRegistrations[0].dataSet = venMutationData.VENDataset;
  mutationDatasetRegJson.data.completeDataSetRegistrations[0].completed = completed;
  const engine = useDataEngine();
	engine.mutate(mutationDatasetRegJson, {
		onComplete: res => {
      saveDataSetRegistration(res);
		},
		onError: error => {
		},
	})
  return (
    <>
    </>
  )
}

const GetVenTemplateSettings = ({ query, onResponse }) => {
  const engine = useDataEngine()  
  engine.query(query, {
    onComplete: data => {
        onResponse(data);
    },
    onError: error => {
      console.error('error: ', error.message);
      if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
        location.reload();
      }
    },
  })
  return (
      <></>
  );
}

InsertDataValueSets.propTypes = {
    onComplete: PropTypes.func.isRequired,
}
FetchDataValueSets.propTypes = {
  onComplete: PropTypes.func.isRequired,
}

export {
  InsertDataValueSets,
  FetchDataValueSets,
  GetOrgUnitGroups,
  SetCompleteDataSetRegistrations,
  GetCompleteDataSetRegistrations,
  GetVenTemplateSettings
}