import { useEffect } from "react";
import { useDataEngine, useConfig } from "@dhis2/app-runtime";
import moment from "moment";
import { getNextPeriod, GetSortOrder } from "../../helpers/common";
import { postData } from "../../helpers/common";
import { CircularLoader } from "@dhis2/ui-core";
import styles from "../Pages.module.css";

const LEGENDS_MAP = [
  "Non-use",
  "Stockout",
  "Potential Stockout",
  "Understock",
  "Satisfactory",
  "Risk of Expiry",
];

const CalculateAmcMos = (props) => {
  // console.log("CalculateAmcMos props: ", props);

  const { baseUrl } = useConfig();

  const apiUrl = baseUrl + "/api/dataValueSets";

  const engine = useDataEngine();

  const query = {
    dataValueSets: {
      resource: "dataValueSets",
      params: {
        dataSet: props.venMutationData.VENDataset,
        period: props.selectedMonthYear,
        orgUnit: props.selectedFacility,
        includeDeleted: true,
      },
    },
  };

  const mutationJson = {
    resource: "dataValueSets",
    type: "create",
    data: {
      dataValues: [],
    },
  };

  const queryLegendSetsById = {
    legendsSets: {
      resource: "legendSets",
      id: props.venMutationData.VENLegend,
      params: {
        fields:
          "id, displayName, legends[id,displayName, startValue, endValue]",
      },
    },
  };

  let itemsExcelTemplate = [];
  let legends = [];

  const AMCs = [];
  const MOSs = [];

  const getTemplateExcelElements = () => {
    // const vTemplateData = props.vTemplateData.slice(props.venMutationData.LMISWorksheetStartRow, props.vTemplateData.length);

    const vTemplateData = props.vTemplateData.filter(
      (item) => item["__EMPTY"] && item["__EMPTY"] != "Code"
    );
    // console.log("Ven Tempate for dataset cell: ", vTemplateData);

    const items = props.items;
    // console.log("items: ", items);

    const itemsByCode = {};

    items.map((item) => {
      itemsByCode[item["__EMPTY"]] = item;
    });

    vTemplateData.map((vTemplate, index) => {
      let code = vTemplate["__EMPTY"];

      if (itemsByCode[code] != undefined) {
        if (code == itemsByCode[code]["__EMPTY"]) {
          itemsExcelTemplate[index] = {
            ItemCode: vTemplate["__EMPTY"],
            ConsumptionUID: vTemplate["__EMPTY_7"],
            ClosingUID: vTemplate["__EMPTY_11"],
            AmcUID: vTemplate["__EMPTY_16"],
            MosUID: vTemplate["__EMPTY_22"],
            PreMonthUID: vTemplate["__EMPTY_23"],
            PrePreMonthUID: vTemplate["__EMPTY_24"],
            PreMonthSODUID: vTemplate["__EMPTY_32"],
            PrePreMonthSODUID: vTemplate["__EMPTY_33"],

            StockoutUID: vTemplate["__EMPTY_25"],
            Potential_StockoutUID: vTemplate["__EMPTY_26"],
            UnderstockUID: vTemplate["__EMPTY_27"],
            SatisfactoryUID: vTemplate["__EMPTY_28"],
            Risk_of_ExpiryUID: vTemplate["__EMPTY_29"],
            Non_UseUID: vTemplate["__EMPTY_31"],

            Closing_Zero_Stock: vTemplate["__EMPTY_30"],

            Consumption: itemsByCode[code]["__EMPTY_7"],
            Closing: itemsByCode[code]["__EMPTY_11"],
            NoStockOutDaysUID: vTemplate["__EMPTY_13"],
          };
        }
      }
    });
    // console.log("t2 getTemplateExcelElements: ", Math.round(Date.now() / 1000));
    getLegends();
  };

  const getCrossMatchedData = (data) => {
    let dValuesByEID = {};
    if (data && data.dataValueSets && data.dataValueSets.dataValues) {
      data.dataValueSets.dataValues.map((d) => {
        dValuesByEID[d.dataElement + "-" + d.categoryOptionCombo] = {
          dataElement: d.dataElement,
          categoryOptionCombo: d.categoryOptionCombo,
          value: d.value,
        };
      });
    }
    const items = [];

    itemsExcelTemplate.map((uids, index) => {
      let consumption_eid = "";
      let closing_eid = "";
      let amc_eid = "";
      let mos_eid = "";
      let premonth_eid = "";
      let prepremonth_eid = "";
      let premonth_sod_eid = "";
      let prepremonth_sod_eid = "";

      let stockout_eid = "";
      let potential_stockout_eid = "";
      let understock_eid = "";
      let satisfactory_eid = "";
      let risk_of_expiry_eid = "";
      let non_use_eid = "";
      let closing_zero_stock_eid = "";
      let sod_eid = "";

      let consumption_cc = "";
      let closing_cc = "";
      let amc_cc = "";
      let mos_cc = "";
      let premonth_cc = "";
      let prepremonth_cc = "";
      let premonth_sod_cc = "";
      let prepremonth_sod_cc = "";

      let stockout_cc = "";
      let potential_stockout_cc = "";
      let understock_cc = "";
      let satisfactory_cc = "";
      let risk_of_expiry_cc = "";
      let non_use_cc = "";
      let closing_zero_stock_cc = "";
      let sod_cc = "";

      let consumption_value = 0;
      let closing_value = 0;
      let amc_value = 0;
      let mos_value = 0;
      let premonth_value = 0;
      let prepremonth_value = 0;
      let premonth_sod_value = 0;
      let prepremonth_sod_value = 0;

      let stockout_value = 0;
      let potential_stockout_value = 0;
      let understock_value = 0;
      let satisfactory_value = 0;
      let risk_of_expiry_value = 0;
      let non_use_value = 0;
      let closing_zero_stock_value = 0;
      let sod_value = 0;

      if (dValuesByEID[uids.ConsumptionUID] != undefined) {
        consumption_eid = dValuesByEID[uids.ConsumptionUID].dataElement;
        consumption_cc = dValuesByEID[uids.ConsumptionUID].categoryOptionCombo;
        consumption_value = dValuesByEID[uids.ConsumptionUID].value;
      }

      if (dValuesByEID[uids.ClosingUID] != undefined) {
        closing_eid = dValuesByEID[uids.ClosingUID].dataElement;
        closing_cc = dValuesByEID[uids.ClosingUID].categoryOptionCombo;
        closing_value = dValuesByEID[uids.ClosingUID].value;
      }

      if (dValuesByEID[uids.NoStockOutDaysUID] != undefined) {
        sod_eid = dValuesByEID[uids.NoStockOutDaysUID].dataElement;
        sod_cc = dValuesByEID[uids.NoStockOutDaysUID].categoryOptionCombo;
        sod_value = dValuesByEID[uids.NoStockOutDaysUID].value;
      }

      if (uids.AmcUID != undefined) {
        amc_eid = uids.AmcUID.split("-")[0];
        amc_cc = uids.AmcUID.split("-")[1];
        amc_value = 0;
      }

      if (uids.MosUID != undefined) {
        mos_eid = uids.MosUID.split("-")[0];
        mos_cc = uids.MosUID.split("-")[1];
        mos_value = 0.0;
      }

      if (uids.PreMonthUID != undefined) {
        if (dValuesByEID[uids.PreMonthUID] != undefined) {
          premonth_eid = dValuesByEID[uids.PreMonthUID].dataElement;
          premonth_cc = dValuesByEID[uids.PreMonthUID].categoryOptionCombo;
          premonth_value = dValuesByEID[uids.PreMonthUID].value;
        } else {
          premonth_eid = uids.PreMonthUID.split("-")[0];
          premonth_cc = uids.PreMonthUID.split("-")[1];
          premonth_value = 0;
        }
      }

      if (uids.PrePreMonthUID != undefined) {
        if (dValuesByEID[uids.PrePreMonthUID] != undefined) {
          prepremonth_eid = dValuesByEID[uids.PrePreMonthUID].dataElement;
          prepremonth_cc =
            dValuesByEID[uids.PrePreMonthUID].categoryOptionCombo;
          prepremonth_value = dValuesByEID[uids.PrePreMonthUID].value;
        } else {
          prepremonth_eid = uids.PrePreMonthUID.split("-")[0];
          prepremonth_cc = uids.PrePreMonthUID.split("-")[1];
          prepremonth_value = 0;
        }
      }

      if (uids.PreMonthSODUID != undefined) {
        if (dValuesByEID[uids.PreMonthSODUID] != undefined) {
          premonth_sod_eid = dValuesByEID[uids.PreMonthSODUID].dataElement;
          premonth_sod_cc =
            dValuesByEID[uids.PreMonthSODUID].categoryOptionCombo;
          premonth_sod_value = dValuesByEID[uids.PreMonthSODUID].value;
        } else {
          premonth_sod_eid = uids.PreMonthSODUID.split("-")[0];
          premonth_sod_cc = uids.PreMonthSODUID.split("-")[1];
          premonth_sod_value = 0;
        }
      }

      if (uids.PrePreMonthSODUID != undefined) {
        if (dValuesByEID[uids.PrePreMonthSODUID] != undefined) {
          prepremonth_sod_eid =
            dValuesByEID[uids.PrePreMonthSODUID].dataElement;
          prepremonth_sod_cc =
            dValuesByEID[uids.PrePreMonthSODUID].categoryOptionCombo;
          prepremonth_sod_value = dValuesByEID[uids.PrePreMonthSODUID].value;
        } else {
          prepremonth_sod_eid = uids.PrePreMonthSODUID.split("-")[0];
          prepremonth_sod_cc = uids.PrePreMonthSODUID.split("-")[1];
          prepremonth_sod_value = 0;
        }
      }

      if (uids.StockoutUID != undefined) {
        stockout_eid = uids.StockoutUID.split("-")[0];
        stockout_cc = uids.StockoutUID.split("-")[1];
        stockout_value = 0;
      }

      if (uids.Potential_StockoutUID != undefined) {
        potential_stockout_eid = uids.Potential_StockoutUID.split("-")[0];
        potential_stockout_cc = uids.Potential_StockoutUID.split("-")[1];
        potential_stockout_value = 0;
      }

      if (uids.UnderstockUID != undefined) {
        understock_eid = uids.UnderstockUID.split("-")[0];
        understock_cc = uids.UnderstockUID.split("-")[1];
        understock_value = 0;
      }

      if (uids.SatisfactoryUID != undefined) {
        satisfactory_eid = uids.SatisfactoryUID.split("-")[0];
        satisfactory_cc = uids.SatisfactoryUID.split("-")[1];
        satisfactory_value = 0;
      }

      if (uids.Risk_of_ExpiryUID != undefined) {
        risk_of_expiry_eid = uids.Risk_of_ExpiryUID.split("-")[0];
        risk_of_expiry_cc = uids.Risk_of_ExpiryUID.split("-")[1];
        risk_of_expiry_value = 0;
      }

      if (uids.Non_UseUID != undefined) {
        non_use_eid = uids.Non_UseUID.split("-")[0];
        non_use_cc = uids.Non_UseUID.split("-")[1];
        non_use_value = 0;
      }

      if (uids.Closing_Zero_Stock != undefined) {
        closing_zero_stock_eid = uids.Closing_Zero_Stock.split("-")[0];
        closing_zero_stock_cc = uids.Closing_Zero_Stock.split("-")[1];

        if (closing_value == 0) {
          closing_zero_stock_value = 1;
        } else {
          closing_zero_stock_value = 0;
        }
      }

      items[index] = {
        ItemCode: uids.ItemCode,
        Consumption_InExcel: uids.Consumption,
        Closing_InExcel: uids.Closing,
        Consumption_InDataset: {
          eid: consumption_eid,
          cc: consumption_cc,
          value: consumption_value,
        },
        Closing_InDataset: {
          eid: closing_eid,
          cc: closing_eid,
          value: closing_value,
        },
        Amc_InDataset: { eid: amc_eid, cc: amc_cc, value: amc_value },
        MOS_InDataset: { eid: mos_eid, cc: mos_cc, value: mos_value },
        PreMonth_InDataset: {
          eid: premonth_eid,
          cc: premonth_cc,
          value: premonth_value,
        },
        PrePreMonth_InDataset: {
          eid: prepremonth_eid,
          cc: prepremonth_cc,
          value: prepremonth_value,
        },
        PreMonthSOD_InDataset: {
          eid: premonth_sod_eid,
          cc: premonth_sod_cc,
          value: premonth_sod_value,
        },
        PrePreMonthSOD_InDataset: {
          eid: prepremonth_sod_eid,
          cc: prepremonth_sod_cc,
          value: prepremonth_sod_value,
        },
        Closing_Zero_Stock_InExcel: {
          eid: closing_zero_stock_eid,
          cc: closing_zero_stock_cc,
          value: closing_zero_stock_value,
        },
        SOD_InDataset: {
          eid: sod_eid,
          cc: sod_cc,
          value: sod_value,
        },

        Legends: {
          Stockout: {
            eid: stockout_eid,
            cc: stockout_cc,
            value: stockout_value,
          },
          "Potential Stockout": {
            eid: potential_stockout_eid,
            cc: potential_stockout_cc,
            value: potential_stockout_value,
          },
          Understock: {
            eid: understock_eid,
            cc: understock_cc,
            value: understock_value,
          },
          Satisfactory: {
            eid: satisfactory_eid,
            cc: satisfactory_cc,
            value: satisfactory_value,
          },
          "Risk of Expiry": {
            eid: risk_of_expiry_eid,
            cc: risk_of_expiry_cc,
            value: risk_of_expiry_value,
          },
          "Non-use": { eid: non_use_eid, cc: non_use_cc, value: non_use_value },
        },
      };
    });

    // console.log("t4 getCrossMatchedData: ", Math.round(Date.now() / 1000));

    const newItems = createAmcMos(items);
    // console.log("newItems: ", newItems);

    uploadAmcMos(newItems);
  };

  const getLegends = () => {
    engine.query(queryLegendSetsById, {
      onComplete: (res) => {
        // console.log("t3 getLegends: ", Math.round(Date.now() / 1000));

        legends = res.legendsSets.legends.sort(GetSortOrder("startValue"));

        // // remove first element 'Non-use'
        // legends.shift();

        getDataValues();
      },

      onError: (error) => {},
    });
  };

  const getDataValues = () => {
    engine.query(query, {
      onComplete: (data) => {
        // console.log("t4 getDataValues: ", Math.round(Date.now() / 1000));

        getCrossMatchedData(data);
      },

      onError: (error) => {},
    });
  };

  const createAmcMos = (items) => {
    let idx = 0;
    const newItems = [];

    let idxAmc = 0;
    let idxMos = 0;

    const period = props.selectedMonthYear;
    const orgUnitId = props.selectedFacility;

    let csvLine =
      "dataelement,period,orgunit,categoryoptioncombo,attributeoptioncombo,value,storedby,lastupdated,comment,followup,deleted\n";

    items.map((item) => {
      let divisor = 0;
      let newItem = {};
      //let sum_3months = 0;
      let amc = 0;
      let mos = 0;

      let prepreIssued = 0;
      let preIssued = 0;
      let issued = 0;

      let prepreSOD = 0;
      let preSOD = 0;
      let SOD = 0;

      // Aggregating (PrePre + Pre + Current month) distributions
      if (
        !(
          item.PrePreMonth_InDataset.value == 0 ||
          item.PrePreMonth_InDataset.value == undefined
        )
      ) {
        console.log(
          "item.PrePreMonth_InDataset.value: ",
          item.PrePreMonth_InDataset.value
        );
        divisor++;
        //sum_3months = sum_3months + parseInt(item.PrePreMonth_InDataset.value);
        prepreIssued = +(item.PrePreMonth_InDataset.value ?? 0);
        prepreSOD = +(item.PrePreMonthSOD_InDataset.value ?? 0);
      }

      if (
        !(
          item.PreMonth_InDataset.value == 0 ||
          item.PreMonth_InDataset.value == undefined
        )
      ) {
        divisor++;
        //sum_3months = sum_3months + parseInt(item.PreMonth_InDataset.value);
        preIssued = +(item.PreMonth_InDataset.value ?? 0);
        preSOD = +(item.PreMonthSOD_InDataset.value ?? 0);
      }

      if (
        !(
          item.Consumption_InDataset.value == 0 ||
          item.Consumption_InDataset.value == undefined
        )
      ) {
        divisor++;
        //sum_3months = sum_3months + parseInt(item.Consumption_InDataset.value);
        issued = +(item.Consumption_InDataset.value ?? 0);
        SOD = +(item.SOD_InDataset.value ?? 0);
      }

      // =('Aug-2023 Log'!H8/(100%-('Aug-2023 Log'!N8/31)*100%)+'Sep-2023 Log'!H8/(100%-('Sep-2023 Log'!N8/30)*100%)+H8/(100%-(N8/31))*100%)/3

      // = (AugIssued/(100%-(AugNoStockOutDays/31)*100%)+
      //   (SepIssued/(100%-(SepNoStockOutDays/30)*100%)+
      //   (Issued/(100%-(NoStockOutDays/31)*100%))/3

      // = (prePreIssued/(100%-(prePreSOD/31)*100%)+
      //   (preIssued/(100%-(preSOD/30)*100%)+
      //   (issued/(100%-(SOD/31)*100%))/3

      const ymd = period + "01";

      const daysInMonth = moment(ymd, "YYYYMMDD").daysInMonth();
      const preDaysInMonth = moment(ymd, "YYYYMMDD")
        .subtract(1, "months")
        .daysInMonth();
      const prepreDaysInMonth = moment(ymd, "YYYYMMDD")
        .subtract(2, "months")
        .daysInMonth();

      // creating AMC
      if (divisor > 0) {
        amc = Math.round(
          (prepreIssued / (1 - prepreSOD / prepreDaysInMonth) +
            preIssued / (1 - preSOD / preDaysInMonth) +
            issued / (1 - SOD / daysInMonth)) /
            divisor
        );

        amc = amc == Infinity ? 0 : amc;

        console.log(
          "Creating AMC: ",
          item.ItemCode,
          "= prepreIssued / (1 - prepreSOD / prepreDaysInMonth) + preIssued / (1 - preSOD / preDaysInMonth) + issued / (1 - SOD / daysInMonth)) / 3",
          `= ${prepreIssued} / (1 - ${prepreSOD} / ${prepreDaysInMonth}) + ${preIssued} / (1 - ${preSOD} / ${preDaysInMonth}) + ${issued} / (1 - ${SOD} / ${daysInMonth})) / 3`,
          `= ${amc}`
        );
      }

      // creating AMC
      //amc = Math.round(divisor > 0 ? sum_3months / divisor : 0);

      // creating MOS
      mos = amc > 0 ? parseInt(item.Closing_InDataset.value) / amc : 0;

      mos = isNaN(mos) ? 0 : mos;

      // creating dataValues for AMC
      // newItem = {
      //   dataElement: item.Amc_InDataset.eid,
      //   categoryOptionCombo: item.Amc_InDataset.cc,
      //   period: period,
      //   orgUnit: orgUnitId,
      //   value: amc,
      // };
      // newItems[idx++] = newItem;

      csvLine += `${item.Amc_InDataset.eid},${period},${orgUnitId},${item.Amc_InDataset.cc},,${amc},,,,,\n`;

      mos = mos.toFixed(2);

      AMCs[idxAmc++] = {
        ItemCode: item.ItemCode,
        AMC: amc,
      };

      MOSs[idxMos++] = {
        ItemCode: item.ItemCode,
        MOS: mos,
      };

      // creating dataValues for MOS
      // newItem = {
      //   dataElement: item.MOS_InDataset.eid,
      //   categoryOptionCombo: item.MOS_InDataset.cc,
      //   period: period,
      //   orgUnit: orgUnitId,
      //   value: mos,
      // };
      // newItems[idx++] = newItem;

      csvLine += `${item.MOS_InDataset.eid},${period},${orgUnitId},${item.MOS_InDataset.cc},,${mos},,,,,\n`;

      // creating dataValues for Closing Zero Stock
      // newItem = {
      //   dataElement: item.Closing_Zero_Stock_InExcel.eid,
      //   categoryOptionCombo: item.Closing_Zero_Stock_InExcel.cc,
      //   period: period,
      //   orgUnit: orgUnitId,
      //   value: item.Closing_Zero_Stock_InExcel.value,
      // };
      // newItems[idx++] = newItem;
      csvLine += `${item.Closing_Zero_Stock_InExcel.eid},${period},${orgUnitId},${item.Closing_Zero_Stock_InExcel.cc},,${item.Closing_Zero_Stock_InExcel.value},,,,,\n`;

      const nextPeriod = getNextPeriod(period);

      // creating dataValues for [Quantity Issued PreMonth] of next month
      // newItem = {
      //   dataElement: item.PreMonth_InDataset.eid,
      //   categoryOptionCombo: item.PreMonth_InDataset.cc,
      //   period: nextPeriod,
      //   orgUnit: orgUnitId,
      //   value: item.Consumption_InDataset.value ?? 0,
      // };
      // newItems[idx++] = newItem;
      csvLine += `${item.PreMonth_InDataset.eid},${nextPeriod},${orgUnitId},${
        item.PreMonth_InDataset.cc
      },,${item.Consumption_InDataset.value ?? 0},,,,,\n`;

      // creating dataValues for [Quantity Issued PrePreMonth] of next month
      // newItem = {
      //   dataElement: item.PrePreMonth_InDataset.eid,
      //   categoryOptionCombo: item.PrePreMonth_InDataset.cc,
      //   period: nextPeriod,
      //   orgUnit: orgUnitId,
      //   value: item.PreMonth_InDataset.value ?? 0,
      // };
      // newItems[idx++] = newItem;
      csvLine += `${
        item.PrePreMonth_InDataset.eid
      },${nextPeriod},${orgUnitId},${item.PrePreMonth_InDataset.cc},,${
        item.PreMonth_InDataset.value ?? 0
      },,,,,\n`;

      // creating dataValues for [No. of Days Stocked Out PreMonth] of next month
      // newItem = {
      //   dataElement: item.PreMonthSOD_InDataset.eid,
      //   categoryOptionCombo: item.PreMonthSOD_InDataset.cc,
      //   period: nextPeriod,
      //   orgUnit: orgUnitId,
      //   value: item.SOD_InDataset.value ?? 0,
      // };
      // newItems[idx++] = newItem;
      csvLine += `${
        item.PreMonthSOD_InDataset.eid
      },${nextPeriod},${orgUnitId},${item.PreMonthSOD_InDataset.cc},,${
        item.SOD_InDataset.value ?? 0
      },,,,,\n`;

      // creating dataValues for [No. of Days Stocked Out PrePreMonth	] of next month
      // newItem = {
      //   dataElement: item.PrePreMonthSOD_InDataset.eid,
      //   categoryOptionCombo: item.PrePreMonthSOD_InDataset.cc,
      //   period: nextPeriod,
      //   orgUnit: orgUnitId,
      //   value: item.PreMonthSOD_InDataset.value ?? 0,
      // };
      // newItems[idx++] = newItem;
      csvLine += `${
        item.PrePreMonthSOD_InDataset.eid
      },${nextPeriod},${orgUnitId},${item.PrePreMonthSOD_InDataset.cc},,${
        item.PreMonthSOD_InDataset.value ?? 0
      },,,,,\n`;

      let status = "";

      mos = parseFloat(mos);

      if (amc === 0) {
        // for Non-use = 1
        status = { ...item.Legends[LEGENDS_MAP[0]], legend: LEGENDS_MAP[0] };
        // newItem = {
        //   dataElement: status.eid,
        //   categoryOptionCombo: status.cc,
        //   period: period,
        //   orgUnit: orgUnitId,
        //   value: 1,
        // };
        // newItems[idx++] = newItem;
        csvLine += `${status.eid},${period},${orgUnitId},${
          status.cc
        },,${1},,,,,\n`;

        let itemLegends = JSON.parse(JSON.stringify(item.Legends));
        delete itemLegends[LEGENDS_MAP[0]];
        Object.keys(itemLegends).map((key) => {
          if (status.legend != key) {
            //creting dataValues 0 for others legends in the same row without Non-use
            // newItem = {
            //   dataElement: item.Legends[key].eid,
            //   categoryOptionCombo: item.Legends[key].cc,
            //   period: period,
            //   orgUnit: orgUnitId,
            //   value: 0,
            // };
            // newItems[idx++] = newItem;
            csvLine += `${item.Legends[key].eid},${period},${orgUnitId},${
              item.Legends[key].cc
            },,${0},,,,,\n`;
          }
        });
      } else {
        // wihtout Non-use
        legends.map((l, index) => {
          if (mos >= l.startValue && mos < l.endValue) {
            status = {
              ...item.Legends[LEGENDS_MAP[index]],
              legend: LEGENDS_MAP[index],
            };
            // creating dataValues for exact matched legend
            // newItem = {
            //   dataElement: status.eid,
            //   categoryOptionCombo: status.cc,
            //   period: period,
            //   orgUnit: orgUnitId,
            //   value: 1,
            // };
            // newItems[idx++] = newItem;
            csvLine += `${status.eid},${period},${orgUnitId},${
              status.cc
            },,${1},,,,,\n`;

            Object.keys(item.Legends).map((key) => {
              if (status.legend !== key) {
                //creting dataValues 0 for others legends in the same row
                // newItem = {
                //   dataElement: item.Legends[key].eid,
                //   categoryOptionCombo: item.Legends[key].cc,
                //   period: period,
                //   orgUnit: orgUnitId,
                //   value: 0,
                // };
                // newItems[idx++] = newItem;
                csvLine += `${item.Legends[key].eid},${period},${orgUnitId},${
                  item.Legends[key].cc
                },,${0},,,,,\n`;
              }
            });
          }
        });
      }
    });

    //return newItems;
    return csvLine;
  };

  // const uploadAmcMos = (dataValues) => {
  //   mutationJson.data.dataValues = dataValues;

  //   console.log("Calculation VEN dataValues for PlayGround: ", mutationJson);

  //   engine.mutate(mutationJson, {
  //     onComplete: (res) => {
  //       console.log("t5 uploadAmcMos: ", Math.round(Date.now() / 1000));
  //       props.uploadAmcMosResponse(res, AMCs, MOSs);
  //     },

  //     onError: (error) => {},
  //   });
  // };

  const uploadAmcMos = (csvData) => {
    postData(apiUrl, csvData).then((data) => {
      // console.log("uploadAmcMos dhis2 respose: ", data);
      props.uploadAmcMosResponse(data, AMCs, MOSs);
    });
  };

  useEffect(() => {
    // console.log("t1 getTemplateExcelElements: ", Math.round(Date.now() / 1000));
    getTemplateExcelElements();
  }, []);

  return (
    <>
      <center>
        <CircularLoader
          className={styles.loading_icon}
          dataTest="dhis2-uicore-circularloader"
          large
        />
      </center>
    </>
  );
};

export { CalculateAmcMos };
