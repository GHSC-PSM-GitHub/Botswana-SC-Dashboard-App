import React, { Component } from "react";
import {
  Button,
  CircularLoader,
  SingleSelect,
  SingleSelectOption,
  AlertBar,
} from "@dhis2/ui-core";
import Dropzone from "react-dropzone";
import Uploader from "./Uploader";
import styles from "../Pages.module.css";
import Constant from "../../helpers/constants";
import { DataQuery } from "@dhis2/app-runtime";

class DataFixSecondStep extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <>
        <div
          style={{ backgroundColor: "#fff", padding: "20px", height: "95%" }}
        >
          {this.props.loading && (
            <center>
              <CircularLoader
                className={styles.loading_icon}
                dataTest="dhis2-uicore-circularloader"
                large
              />
            </center>
          )}
          {this.props.error && (
            <div className={styles.alertBarBox}>
              <AlertBar
                permanent
                critical
                className={styles.alertBar}
                onHidden={(payload, event) => {
                  this.props.closeAlertBar();
                }}
              >
                {this.props.error}
              </AlertBar>
            </div>
          )}
          {this.props.successMsg && (
            <div className={styles.alertBarBox}>
              <AlertBar
                permanent
                success
                className={styles.alertBar}
                onHidden={(payload, event) => {
                  this.props.closeAlertBarMsg();
                }}
              >
                {this.props.successMsg}
              </AlertBar>
            </div>
          )}
          <h2>Import VEN LMIS Report - Select Template</h2>
          <p>
            Step 1 of 2: Select facility, month-year and the Excel file you want
            to upload - then press IMPORT DATA button
          </p>
          <div className={styles.container}>
            <div className={styles.selectedFacility}>
              <label>Select facility</label>
            </div>
            <div className={styles.selectedFxacilitySelect}>
              <SingleSelect
                className="select"
                selected={this.props.selectedFacility}
                filterable
                noMatchText="No match found"
                onChange={(e) =>
                  this.props.handleChangeFacility(e, "selectFacility")
                }
              >
                {this.props.orgUnits.map(({ id, displayName }) => (
                  <SingleSelectOption key={id} label={displayName} value={id} />
                ))}
              </SingleSelect>
            </div>
            <div className={styles.monthYear}>Month-Year</div>
            <div className={styles.monthYearSelect}>
              <SingleSelect
                selected={this.props.selectedMonthYear}
                onChange={(e) =>
                  this.props.handleChangeFacility(e, "monthYear")
                }
              >
                {this.props.periods.map((unit) => {
                  return (
                    <SingleSelectOption value={unit.id} label={unit.name} />
                  );
                })}
              </SingleSelect>
            </div>
            <div className={styles.previousYear}>
              <Button
                name="Basic button"
                value="default"
                onClick={() => this.props.setPeriods("previous")}
              >
                Prev Year
              </Button>
            </div>
            <div className={styles.nextYear}>
              <Button
                name="Basic button"
                value="default"
                onClick={() => this.props.setPeriods("next")}
              >
                Next Year
              </Button>
            </div>
          </div>
          <div>
            <div style={{ textAlign: "center", padding: 20 }}>
              <Button
                dataTest="dhis2-uicore-button"
                name="Primary button"
                primary
                type="button"
                value="default"
                onClick={this.props.handleDataFixSecondStep}
                disabled={this.props.dataFixBtnDisabled}
              >
                FIX MOS
              </Button>
              {' '}
              <Button
                dataTest="dhis2-uicore-button"              
                name="Primary button"
                onClick={this.props.redirectToFirstStep}
                primary
                type="button"
                value="default"
                className={styles.upload_another_template}
                disabled={this.props.dataFixBtnBack}
              >
                Back
              </Button>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default DataFixSecondStep;
