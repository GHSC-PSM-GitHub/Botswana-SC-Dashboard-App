import { useEffect } from 'react';
import { useDataMutation, useDataQuery, DataQuery, useDataEngine } from '@dhis2/app-runtime'

const GetAppSettings = ({ query, onResponse }) => {
    const { loading, error, data, refetch } = useDataQuery(query)
    onResponse(loading, error, data, refetch );
    return (
        <></>
    );    
  }

  const GetAppSettingsNew = ({ query, onResponse }) => {
    const engine = useDataEngine()
    engine.query(query, {
      onComplete: data => {
          // setState(data.dataStore);
          onResponse(data);
      },
      onError: error => {
        // setError(error.message);
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
    return (
        <></>
    );
  }

const SetAppSettings = ({ mutation, onComplete }) => {
    const [mutate, { called, loading, error, data }] = useDataMutation(mutation, {
        onComplete: onComplete,
        onError: error => {
          setError(error)
          console.error('error: ', error)
      }
    });
    useEffect(() => {
      mutate();
    }, []);
    return (<></>);
  }

  const SetAppSettingsNew = ({ mutation, onComplete }) => {
    const engine = useDataEngine() 
    const [mutate, { called, loading, error, data }] = engine.mutate(mutation, {
        onComplete: onComplete,
        onError: error => {
          setError(error)
          console.error('error: ', error)
      }
    });
    useEffect(() => {
      mutate();
    }, []);
    return (<></>);
  }

  const GetOptionSets = ({ query, optionSetId, onResponse }) => {
    query.options.id = optionSetId
    const engine = useDataEngine()
    engine.query(query, {
      onComplete: data => {
          onResponse(data);
      },
      onError: error => {
        console.error('error: ', error.message);
        if(error && error.details && error.details.httpStatusCode && error.details.httpStatusCode == 404){
          location.reload();
        }
      },
    })
    return (
        <></>
    );
  }

  export {
    GetAppSettings,
    SetAppSettings,
    GetAppSettingsNew,
    SetAppSettingsNew,
    GetOptionSets
  }