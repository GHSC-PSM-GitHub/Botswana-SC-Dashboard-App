import React, { Component } from 'react';
import ArtSettingComponent from './ArtSettingComponent';
// import CmsSettingComponent from './CmsSettingComponent';
import LabSettingComponent from './LabSettingComponent';
// import PipelineSettingComponent from './PipelineSettingComponent';
import VenSettingComponent from './VenSettingComponent';
// import GeneralSettingComponent from './GeneralSettingComponent';
import styles from '../Pages.module.css';
import { GetAppSettings, SetAppSettings, GetAppSettingsNew, SetAppSettingsNew } from './settingComponentApi';
import { AlertBar } from '@dhis2/ui-core';
import { useConfig } from '@dhis2/app-runtime'
import { artInitialSettings } from '../../actions/settings';
import { Divider } from '@dhis2/ui-core';
import Constants from '../../helpers/constants';

class SettingComponent extends Component {
  constructor( props ) {
		super( props );
		this.state = {
			activeTab: "ART",
		}
		this.changeTab = this.changeTab.bind(this);
		this.closeAlertBar = this.closeAlertBar.bind(this);
	}

	changeTab(activeTab){
		this.setState({activeTab});
	}
	closeAlertBar(){
		this.setState({error: undefined, success: undefined});
	}

  render() {
		const {activeTab} = this.state
    return (
      <>
				<div className={styles.setting}>

				</div>
				<ul className = {styles.settingPages}>
					<li className = {activeTab == "ART" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "ART")}>ARV</li>
					<li className = {activeTab == "VEN" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "VEN")}>VEN</li>
					<li className = {activeTab == "Lab" ? styles.activeTab : styles.settingPage} onClick = {this.changeTab.bind(this, "Lab")}>Lab</li>
				</ul>
				<div className={styles.tab}>
					{
						activeTab == "ART" &&
						<ArtSettingComponent
						/>
					}
					{
						activeTab == "VEN" &&
						<VenSettingComponent
						/>
					}
					{
						activeTab == "Lab" &&
						<LabSettingComponent
						/>
					}
				</div>
      </>
    );
  }
}

export default SettingComponent;
