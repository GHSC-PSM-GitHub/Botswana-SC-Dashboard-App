import React, { Component } from 'react';
import styles from '../Pages.module.css';

class PipelineSettingComponent extends Component {
	constructor( props ) {
		super( props );
		this.state = {
			loading: false
		}
	}
	render(){
		return(
			<>
				<div className={styles.tabContainer}>
				PipelineSettingComponent
				</div>
			</>
		)
	}
}

export default PipelineSettingComponent;