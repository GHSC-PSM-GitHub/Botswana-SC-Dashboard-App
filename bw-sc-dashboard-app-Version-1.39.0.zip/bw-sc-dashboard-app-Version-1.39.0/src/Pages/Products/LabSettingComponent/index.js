import React, { Component } from 'react';
import { Button, Input, SingleSelectOption, SingleSelect, CircularLoader } from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {DataQuery } from '@dhis2/app-runtime'
import LabProductsList from './LabProductsList';
import ProductDetail from './ProductDetail';
import UpdateProduct from './UpdateProduct';

import Constants from '../../../helpers/constants';
import { GetLabTemplateSettings, GetCmsLabTemplateSettings } from '../../ImportLabTemplate/labTemplateApi';

const labTemplateQuery = {
  "dataStore": {
      "resource": `dataStore/${Constants.namespace}/${Constants.LabTemplateKey}`
  }
}

const cmsLabTemplateQuery = {
  "dataStore": {
      "resource": `dataStore/${Constants.namespace}/${Constants.CmsLabTemplateKey}`
  }
}

class LabSettingComponent extends Component {
	constructor( props ) {
		super( props );
		this.state = {
			getLabTemplateData: true,
			labTemplateData:[],
			labTemplateDataList: [],
			LabProductJsonFormat: {},
			labTemplateDataItems: [],
			cmsLabTemplateData:[],
			CmsLabProductJsonFormat: {},
			getCmsLabTemplateData: true,
			productEdit: false,
			productAdd: false,
			showProductList: true,
			productCode: null,
			productDetail: null,
			updateProduct: false,
			saveProduct: false,
			saveCmsLabProduct: false,
			updateCmsLabProduct: false,
			searchText: null,
			loading: true
		}
		this.getLabTemplateSettings = this.getLabTemplateSettings.bind(this);
		this.getCmsLabTemplateSettings = this.getCmsLabTemplateSettings.bind(this);
		this.productEditView = this.productEditView.bind(this);
		this.productUpdate = this.productUpdate.bind(this);
		this.productAdd = this.productAdd.bind(this);
		this.searchProducts = this.searchProducts.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.pressCancel = this.pressCancel.bind(this);
		this.deleteProduct = this.deleteProduct.bind(this);
		this.productUpdateResponse = this.productUpdateResponse.bind(this);
		this.cmsLabProductUpdateResponse = this.cmsLabProductUpdateResponse.bind(this);
		this.labProductSave = this.labProductSave.bind(this);
		this.cmsLabProductSave = this.cmsLabProductSave.bind(this);
	}

	labProductSave(isEdit = false){
		let LabProductJsonFormat = Constants.LabProductJsonFormat
		let productDetail = this.state.productDetail || {}
		
		LabProductJsonFormat["__EMPTY"] = productDetail.productCode
		LabProductJsonFormat["__EMPTY_2"] = productDetail.productName
		LabProductJsonFormat["__EMPTY_4"] = productDetail.numericElementId+"-dWTgv7nQzp3"
		LabProductJsonFormat["__EMPTY_5"] = productDetail.numericElementId+"-cqr9Qz4S9ir"
		LabProductJsonFormat["__EMPTY_6"] = productDetail.numericElementId+"-d1ha3qv5NVz"
		LabProductJsonFormat["__EMPTY_7"] = productDetail.numericElementId+"-H8wShkXgdh5"
		LabProductJsonFormat["__EMPTY_8"] = productDetail.numericElementId+"-BH0lye2amGG"
		LabProductJsonFormat["__EMPTY_9"] = productDetail.numericElementId+"-gdfxU93ELmJ"
		LabProductJsonFormat["__EMPTY_10"] = productDetail.numericElementId+"-eJcatASNrDD"
		LabProductJsonFormat["__EMPTY_11"] = productDetail.numericElementId+"-sgMj8LBiFW2"
		LabProductJsonFormat["__EMPTY_12"] = productDetail.numericElementId+"-Tyf7CmHd2jz"
		LabProductJsonFormat["__EMPTY_13"] = productDetail.commentsElementId+"-f8tqseFk9CK"
		LabProductJsonFormat["__EMPTY_14"] = productDetail.lossTypeElementID+"-bHUWbZL2cYn"
		LabProductJsonFormat["__EMPTY_15"] = productDetail.numericElementId+"-qmKxrGMLfcL"
		LabProductJsonFormat["__EMPTY_16"] = productDetail.adjustmentTypeElementId+"-XxPpu51hMrn"
		LabProductJsonFormat["__EMPTY_21"] = productDetail.numericElementId+"-UXUSOHc5zOq"
		LabProductJsonFormat["__EMPTY_22"] = productDetail.numericElementId+"-sUKxIAlbTae"
		LabProductJsonFormat["__EMPTY_23"] = productDetail.numericElementId+"-PRUXDoeBnuF"
		LabProductJsonFormat["__EMPTY_24"] = productDetail.numericElementId+"-twup75lNJpt"
		LabProductJsonFormat["__EMPTY_25"] = productDetail.numericElementId+"-CN2fhPx8zAL"
		LabProductJsonFormat["__EMPTY_26"] = productDetail.numericElementId+"-JiiluEpMlcp"
		LabProductJsonFormat["__EMPTY_27"] = productDetail.numericElementId+"-ahPxmw900L3"
		LabProductJsonFormat["__EMPTY_28"] = productDetail.numericElementId+"-VP94GszpMBM"
		LabProductJsonFormat["__EMPTY_29"] = productDetail.numericElementId+"-f1kqIsBp0Y5"
		LabProductJsonFormat["__EMPTY_30"] = productDetail.numericElementId+"-fFivozbWLLH"

		LabProductJsonFormat["__EMPTY_32"] = productDetail.numericElementId + "-GRbijGRY1aU"
		LabProductJsonFormat["__EMPTY_33"] = productDetail.numericElementId + "-Q2eOWHcvLYE"

		let labTemplateDataItems = this.state.labTemplateDataItems;
		
		if(isEdit === true){
			labTemplateDataItems = labTemplateDataItems.map((template)=>{
				if(template["__EMPTY"] == productDetail.productCode){
						return LabProductJsonFormat
				}else{
						return template
				}
			})
		}else{
			labTemplateDataItems.push(LabProductJsonFormat)
		}
		this.setState({
			labTemplateDataItems,
			LabProductJsonFormat,
			saveProduct: true,
			loading: true
		})
	}

	cmsLabProductSave(isEdit = false){		
		let CmsLabProductJsonFormat = Constants.CmsLabProductJsonFormat
		let productDetail = this.state.productDetail || {}
		let currentStock = CmsLabProductJsonFormat && Object.keys(CmsLabProductJsonFormat).filter((data) => data.includes("Current stock"))[0]

			CmsLabProductJsonFormat["Code "] = productDetail.productCode
			CmsLabProductJsonFormat["Product Description "] = productDetail.productName
			CmsLabProductJsonFormat["Unit Price (bwp)"] = productDetail.numericElementId+"-UXUSOHc5zOq"
			if(currentStock){
				CmsLabProductJsonFormat[currentStock] = productDetail.numericElementId+"-gdfxU93ELmJ"
			}
	
		let cmsLabTemplateData = this.state.cmsLabTemplateData;		
		if(isEdit === true){
			cmsLabTemplateData = cmsLabTemplateData.map((template)=>{
				if(template["Code "] == productDetail.productCode){
						return CmsLabProductJsonFormat
				}else{
						return template
				}
			})
		}else{
			cmsLabTemplateData.push(CmsLabProductJsonFormat)
		}
		this.setState({
			cmsLabTemplateData,
			CmsLabProductJsonFormat,
			saveCmsLabProduct: true,
			loading: true
		})
	}

	deleteProduct(productCode){
		let labTemplateDataItems = this.state.labTemplateDataItems.filter((item) => item["__EMPTY"] !== productCode)

		let cmsLabTemplateData = this.state.cmsLabTemplateData.filter((item) => item["Code "] !== productCode)
		this.setState({labTemplateDataItems, cmsLabTemplateData, updateProduct: true, loading: true});
	}
	productUpdateResponse(labTemplate_data){
		if(labTemplate_data.httpStatusCode==200){
			this.setState({
				saveProduct: false,
				updateProduct: false,
				productEdit: false,
				productAdd: false,
				getLabTemplateData: true,
				showProductList: true,
				productDetail: null,
			});			
			this.cmsLabProductSave(this.state.updateProduct || this.state.productEdit);
		}
	}

	cmsLabProductUpdateResponse(cmsLabTemplate_data){		
		if(cmsLabTemplate_data.httpStatusCode==200){
			this.setState({
				loading: false,
				saveCmsLabProduct: false,
				updateCmsLabProduct: false,
				productEdit: false,
				productAdd: false,
				getLabTemplateData: false,
				showProductList: true,
				productDetail: null,
			});
		}
	}


	pressCancel(){
		this.setState({
			productEdit: false,
			productAdd: false,
			showProductList: true,
			productDetail: null,
			productCode: null,
		})
	}
	productAdd(){
		this.setState({
			productAdd: true,
			showProductList: false
		})
	}

	handleChange(e){
		let productDetail = this.state.productDetail || {}
		productDetail[e.name] = e.value
		this.setState({productDetail});
	}

	searchProducts(e){
		let labTemplateData = []
		let searchText = e.value.toLowerCase()
		if(searchText){
			labTemplateData = this.state.labTemplateDataList.filter((item) => {
				if(item["__EMPTY"].toLowerCase().includes(searchText) || item["__EMPTY_2"].toLowerCase().includes(searchText)){
					return item
				}
			})
		}else{
			labTemplateData = this.state.labTemplateDataList
		}
		this.setState({labTemplateData, searchText});
	}

	productUpdate(){
		this.labProductSave(true);
	}

	productEditView(product){
		let productDetail = this.state.productDetail || {}

		productDetail["productCode"] = product["__EMPTY"]
		productDetail["productName"] = product["__EMPTY_2"]
		productDetail["numericElementId"] = (product["__EMPTY_4"] ? product["__EMPTY_4"].split("-")[0] : "")
		productDetail["commentsElementId"] =  (product["__EMPTY_13"] ? product["__EMPTY_13"].split("-")[0] : "")
		productDetail["lossTypeElementID"] =  (product["__EMPTY_14"] ? product["__EMPTY_14"].split("-")[0] : "")
		productDetail["adjustmentTypeElementId"] =  (product["__EMPTY_16"] ? product["__EMPTY_16"].split("-")[0] : "")

		this.setState({
			productDetail: productDetail,
			productCode: product["__EMPTY"],
			productEdit: true,
			showProductList: false
		})
	}

	getLabTemplateSettings(data){
		if(data && data.dataStore){
			let labTemplateData = data.dataStore.filter((item)=> (item["__EMPTY"] && item["__EMPTY_2"] && item["__EMPTY"].trim() !== "Product Code"))
			let searchText = this.state.searchText || ""
			this.setState({
				loading: false,
				getLabTemplateData: false,
				labTemplateDataItems: data.dataStore,
				labTemplateDataList: labTemplateData,
				labTemplateData: labTemplateData.filter((item) => {
					if(item["__EMPTY"].toLowerCase().includes(searchText) || item["__EMPTY_2"].toLowerCase().includes(searchText)){
						return item
					}
				}),
			});
		}
	}

	getCmsLabTemplateSettings(data){
		if(data && data.dataStore){
			this.setState({
				loading: false,
				getCmsLabTemplateData: false,
				cmsLabTemplateData: data.dataStore
			});
		}
	}

	render(){
		return(
			<>
				{
					this.state.loading && <center>
						<CircularLoader className={styles.loading_icon}  dataTest="dhis2-uicore-circularloader" large />
					</center>
				}
				{
					this.state.getLabTemplateData &&
					<GetLabTemplateSettings query = {labTemplateQuery} onResponse = {this.getLabTemplateSettings}
					/>
				}
				{
					this.state.getCmsLabTemplateData &&
					<GetCmsLabTemplateSettings query = {cmsLabTemplateQuery} onResponse = {this.getCmsLabTemplateSettings}
					/>
				}
				{
					(this.state.updateProduct || this.state.saveProduct) &&
					<UpdateProduct
						labTemplateData = {this.state.labTemplateDataItems}
						productUpdateResponse = {this.productUpdateResponse}
						updateProduct = {this.state.updateProduct}
						type = "lab"
					/>
				}
				{
					(this.state.updateCmsLabProduct || this.state.saveCmsLabProduct) &&
					<UpdateProduct
						labTemplateData = {this.state.cmsLabTemplateData}
						productUpdateResponse = {this.cmsLabProductUpdateResponse}
						updateProduct = {this.state.updateCmsLabProduct}
						type = "cmsLab"
					/>
				}

				{
					this.state.showProductList &&
						<LabProductsList
						setMessageAndError = {this.props.setMessageAndError}
						labTemplateData = {this.state.labTemplateData}	
						productEditView = {this.productEditView}
						searchProducts = {this.searchProducts}
						productAdd = {this.productAdd}
						deleteProduct = {this.deleteProduct}
						searchText = {this.state.searchText}
						labTemplateDataList = {this.state.labTemplateDataList}
					/>
				}
				{
					(this.state.productEdit || this.state.productAdd) &&
					<ProductDetail
						productDetail = {this.state.productDetail}
						setMessageAndError = {this.props.setMessageAndError}
						productEditView = {this.productEditView}
						handleChange = {this.handleChange}
						pressCancel = {this.pressCancel}
						labProductSave = {this.labProductSave}
						productUpdate = {this.productUpdate}
						productEdit = {this.state.productEdit}
					/>
				}
			</>
		)
	}
}

export default LabSettingComponent;