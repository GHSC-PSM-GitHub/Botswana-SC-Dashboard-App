import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import styles from '../../Pages.module.css';
import {SingleSelect, SingleSelectOption} from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';
import { Input, Divider, AlertBar, Menu, MenuItem, Button, Table, TableHead, TableBody, TableRow, TableRowHead, TableCellHead, TableCell, CircularLoader } from '@dhis2/ui-core';

const ProductDetail = (props) => {
  return (
    <div className={styles.tabProductDetail}>
      <div className={styles.row}>
        <div className={styles.colMd3}>
          <label>Product Code</label>
          <Input
            value={(props.productDetail && props.productDetail.productCode) || ""}
            name = "productCode"
            onChange = {(e) => props.handleChange(e) }
            readOnly = {props.productEdit ? true : false}
          />
        </div>
        <div className={styles.colMd10}>
          <label>Product Name</label>
          <Input
            value={(props.productDetail && props.productDetail.productName) || ""}
            name = "productName"
            onChange = {(e) => props.handleChange(e) }
          />
        </div>
      </div>
      <br/>

      <div className={styles.row}>
        <div className={styles.colMd3}>
          <label>Numeric Element ID</label>
          <Input
            value={(props.productDetail && props.productDetail.numericElementId) || ""}
            name = "numericElementId"
            onChange = {(e) => props.handleChange(e) }
          />
        </div>
        <div className={styles.colMd3}>
          <label>Comments Element ID</label>
          <Input
            value={(props.productDetail && props.productDetail.commentsElementId) || ""}
            name = "commentsElementId"
            onChange = {(e) => props.handleChange(e) }
          />
        </div>
        <div className={styles.colMd3}>
          <label>Adjustment Type Element ID</label>
          <Input
            value={(props.productDetail && props.productDetail.adjustmentTypeElementId) || ""}
            name = "adjustmentTypeElementId"
            onChange = {(e) => props.handleChange(e) }
          />
        </div>
        <div className={styles.colMd3}>
          <label>Loss Type Element ID</label>
          <Input
            value={(props.productDetail && props.productDetail.lossTypeElementID) || ""}
            name = "lossTypeElementID"
            onChange = {(e) => props.handleChange(e) }
          />
        </div>
      </div>
      <br/>

      <div className={styles.row}>
        <div className={styles.colMd2}>
        </div>
        <div className={styles.colMd2}>
          <Button onClick={props.productEdit ? props.productUpdate : props.labProductSave} large name="Primary button" primary value="default">
            SAVE
          </Button>
        </div>
        <div className={styles.colMd2}>
        <Button large name="Basic button" onClick={props.pressCancel} value="default">
          CANCEL
        </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;