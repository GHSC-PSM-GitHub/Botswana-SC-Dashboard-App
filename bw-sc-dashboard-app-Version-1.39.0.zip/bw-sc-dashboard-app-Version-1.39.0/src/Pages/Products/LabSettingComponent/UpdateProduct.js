import React from 'react';
import { useState, useEffect } from 'react'
import { useConfig } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants';
import { labTemplateUpdateSettings, cmsLabTemplateUpdateSettings } from '../../../actions/settings';

const UpdateProduct = (props) => {
  const { baseUrl, apiVersion } = useConfig();  
  useEffect(() => {    
  }, []);

  if(props.type == "lab"){
    let labTemplateSettings = Constants.LabTemplateSettingsCreate
    labTemplateSettings["data"] = props.labTemplateData
    labTemplateSettings["type"] = "update"
  
    const { labTemplate_update_loading, labTemplate_update_req, labTemplate_update_data, labTemplate_update_error } = labTemplateSettings && labTemplateSettings.data && labTemplateUpdateSettings(labTemplateSettings)
  
    if(labTemplate_update_data && labTemplate_update_data.httpStatusCode && labTemplate_update_data.httpStatusCode==200){
      props.productUpdateResponse(labTemplate_update_data)
    }  
  }

  if(props.type == "cmsLab"){
    let cmsLabTemplateSettings = Constants.CmsLabTemplateSettingsCreate
    cmsLabTemplateSettings["data"] = props.labTemplateData
    cmsLabTemplateSettings["type"] = "update"
  
    const { cmsLabTemplate_update_loading, cmsLabTemplate_update_req, cmsLabTemplate_update_data, cmsLabTemplate_update_error } = cmsLabTemplateSettings && cmsLabTemplateSettings.data && cmsLabTemplateUpdateSettings(cmsLabTemplateSettings)
  
    if(cmsLabTemplate_update_data && cmsLabTemplate_update_data.httpStatusCode && cmsLabTemplate_update_data.httpStatusCode==200){
      props.productUpdateResponse(cmsLabTemplate_update_data)
    } 
  }

  return (
    <>
    </>
  );
};

export default UpdateProduct;