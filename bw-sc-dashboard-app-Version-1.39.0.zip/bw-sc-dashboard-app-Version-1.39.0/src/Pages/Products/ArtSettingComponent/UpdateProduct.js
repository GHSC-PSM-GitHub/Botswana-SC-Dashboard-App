import React from 'react';
import { useState, useEffect } from 'react'
import { useConfig } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants';
import { artTemplateUpdateSettings, cmsVenTemplateUpdateSettings } from '../../../actions/settings';

const UpdateProduct = (props) => {
  const { baseUrl, apiVersion } = useConfig();  
  useEffect(() => {    
  }, []);

  if(props.type == "art"){
    let artTemplateSettings = Constants.ArtLogTemplateSettingsCreate;
    artTemplateSettings["data"] = props.artTemplateData
    artTemplateSettings["type"] = "update"

    const { artTemplate_update_loading, artTemplate_update_req, artTemplate_update_data, artTemplate_update_error } = artTemplateSettings && artTemplateSettings.data && artTemplateUpdateSettings(artTemplateSettings)

    if(artTemplate_update_data && artTemplate_update_data.httpStatusCode && artTemplate_update_data.httpStatusCode==200){
      props.productUpdateResponse(artTemplate_update_data)
    }
  }

  if(props.type == "cmsArt"){
    let cmsArtTemplateSettings = Constants.CmsArtTemplateSettingsCreate
    cmsArtTemplateSettings["data"] = props.artTemplateData
    cmsArtTemplateSettings["type"] = "update"

    const { cmsVenTemplate_update_loading, cmsVenTemplate_update_req, cmsVenTemplate_update_data, cmsVenTemplate_update_error } = cmsArtTemplateSettings && cmsArtTemplateSettings.data && cmsVenTemplateUpdateSettings(cmsArtTemplateSettings)

    if(cmsVenTemplate_update_data && cmsVenTemplate_update_data.httpStatusCode && cmsVenTemplate_update_data.httpStatusCode==200){
      props.productUpdateResponse(cmsVenTemplate_update_data)
    }
  }
  return (
    <>
    </>
  );
};

export default UpdateProduct;