import React, { Component } from 'react';
import { Button, Input, SingleSelectOption, SingleSelect, CircularLoader } from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import { DataQuery } from '@dhis2/app-runtime'
import ArtProductsList from './ArtProductsList';
import ProductDetail from './ProductDetail';
import UpdateProduct from './UpdateProduct';

import Constants from '../../../helpers/constants';
import { GetArtTemplateSettings } from '../../ImportArtTemplate/artTemplateApi';

const artTemplateQuery = {
	"dataStore": {
		"resource": `dataStore/${Constants.namespace}/${Constants.ArtLogTemplateKey}`
	}
}
const cmsArtTemplateQuery = {
	"dataStore": {
		"resource": `dataStore/${Constants.namespace}/${Constants.CmsArtTemplateKey}`
	}
}

class ArtSettingComponent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			getArtTemplateData: true,
			getCmsArtTemplateData: false,
			cmsArtTemplateData: [],
			artTemplateData: [],
			artTemplateDataList: [],
			artTemplateDataItems: [],
			ArtProductJsonFormat: {},
			CmsArtProductJsonFormat: {},
			productEdit: false,
			productAdd: false,
			showProductList: true,
			productCode: null,
			productDetail: null,
			updateProduct: false,
			saveProduct: false,
			updateCmsArtProduct: false,
			saveCmsArtProduct: false,
			searchText: null,
			loading: true
		}
		this.getArtTemplateSettings = this.getArtTemplateSettings.bind(this);
		this.getCmsArtTemplateSettings = this.getCmsArtTemplateSettings.bind(this);
		this.productEditView = this.productEditView.bind(this);
		this.productUpdate = this.productUpdate.bind(this);
		this.productAdd = this.productAdd.bind(this);
		this.searchProducts = this.searchProducts.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.pressCancel = this.pressCancel.bind(this);
		this.deleteProduct = this.deleteProduct.bind(this);
		this.productUpdateResponse = this.productUpdateResponse.bind(this);
		this.cmdArtProductUpdateResponse = this.cmdArtProductUpdateResponse.bind(this);
		this.productSave = this.productSave.bind(this);
		this.cmsArtProductSave = this.cmsArtProductSave.bind(this);
	}

	productSave(isEdit = false) {
		let ArtProductJsonFormat = Constants.ArtProductJsonFormat
		let productDetail = this.state.productDetail || {}
		ArtProductJsonFormat["__EMPTY"] = productDetail.productCode
		ArtProductJsonFormat["__EMPTY_1"] = productDetail.productName
		ArtProductJsonFormat["__EMPTY_5"] = productDetail.numericElementId + "-dWTgv7nQzp3"
		ArtProductJsonFormat["__EMPTY_6"] = productDetail.numericElementId + "-cqr9Qz4S9ir"
		ArtProductJsonFormat["__EMPTY_7"] = productDetail.numericElementId + "-d1ha3qv5NVz"
		ArtProductJsonFormat["__EMPTY_8"] = productDetail.numericElementId + "-H8wShkXgdh5"
		ArtProductJsonFormat["__EMPTY_9"] = productDetail.numericElementId + "-BH0lye2amGG"
		ArtProductJsonFormat["__EMPTY_10"] = productDetail.numericElementId + "-lNjhiBWostD"
		ArtProductJsonFormat["__EMPTY_11"] = productDetail.numericElementId + "-gdfxU93ELmJ"
		ArtProductJsonFormat["__EMPTY_12"] = productDetail.numericElementId + "-eJcatASNrDD"
		
		ArtProductJsonFormat["__EMPTY_13"] = productDetail.numericElementId + "-sgMj8LBiFW2"

		ArtProductJsonFormat["__EMPTY_14"] = productDetail.numericElementId + "-X8TZ8BA9Q5w"
		ArtProductJsonFormat["__EMPTY_15"] = productDetail.commentsElementId + "-f8tqseFk9CK"
		ArtProductJsonFormat["__EMPTY_16"] = productDetail.numericElementId + "-qmKxrGMLfcL"
		ArtProductJsonFormat["__EMPTY_17"] = productDetail.adjustmentTypeElementId + "-XxPpu51hMrn"

		ArtProductJsonFormat["__EMPTY_21"] = productDetail.numericElementId + "-UXUSOHc5zOq"
		ArtProductJsonFormat["__EMPTY_22"] = productDetail.numericElementId + "-sUKxIAlbTae"
		ArtProductJsonFormat["__EMPTY_23"] = productDetail.numericElementId + "-PRUXDoeBnuF"
		ArtProductJsonFormat["__EMPTY_24"] = productDetail.numericElementId + "-twup75lNJpt"
		ArtProductJsonFormat["__EMPTY_25"] = productDetail.numericElementId + "-CN2fhPx8zAL"
		ArtProductJsonFormat["__EMPTY_26"] = productDetail.numericElementId + "-JiiluEpMlcp"
		ArtProductJsonFormat["__EMPTY_27"] = productDetail.numericElementId + "-ahPxmw900L3"
		ArtProductJsonFormat["__EMPTY_28"] = productDetail.numericElementId + "-VP94GszpMBM"
		ArtProductJsonFormat["__EMPTY_29"] = productDetail.numericElementId + "-f1kqIsBp0Y5"
		ArtProductJsonFormat["__EMPTY_30"] = productDetail.numericElementId + "-fFivozbWLLH"
		ArtProductJsonFormat["__EMPTY_31"] = productDetail.numericElementId + "-OBwuZ6rUKwU"

		ArtProductJsonFormat["__EMPTY_32"] = productDetail.numericElementId + "-GRbijGRY1aU"
		ArtProductJsonFormat["__EMPTY_33"] = productDetail.numericElementId + "-Q2eOWHcvLYE"

		let artTemplateDataItems = this.state.artTemplateDataItems;
		if (isEdit === true) {
			artTemplateDataItems = artTemplateDataItems.map((template) => {
				if (template["__EMPTY"] == productDetail.productCode) {
					return ArtProductJsonFormat
				} else {
					return template
				}
			})
		} else {
			artTemplateDataItems.push(ArtProductJsonFormat)
		}
		this.setState({
			artTemplateDataItems,
			ArtProductJsonFormat,
			saveProduct: true,
			loading: true
		})
	}

	cmsArtProductSave(isEdit = false) {
		let CmsArtProductJsonFormat = Constants.CmsArtProductJsonFormat
		let productDetail = this.state.productDetail || {}
		let currentStock = CmsArtProductJsonFormat && Object.keys(CmsArtProductJsonFormat).filter((data) => data.includes("Current stock"))[0]

		CmsArtProductJsonFormat["Code"] = productDetail.productCode
		CmsArtProductJsonFormat["Description"] = productDetail.productName
		CmsArtProductJsonFormat[" Unit Price (bwp) "] = productDetail.numericElementId + "-UXUSOHc5zOq"
		CmsArtProductJsonFormat[currentStock] = productDetail.numericElementId + "-gdfxU93ELmJ"
		let cmsArtTemplateData = this.state.cmsArtTemplateData;
		if (isEdit === true) {
			cmsArtTemplateData = cmsArtTemplateData.map((template) => {
				if (template["Code"] == productDetail.productCode) {
					return CmsArtProductJsonFormat
				} else {
					return template
				}
			})
		} else {
			cmsArtTemplateData.push(CmsArtProductJsonFormat)
		}
		this.setState({
			cmsArtTemplateData,
			CmsArtProductJsonFormat,
			saveCmsArtProduct: true,
			loading: true
		})
	}

	deleteProduct(productCode) {
		let artTemplateDataItems = this.state.artTemplateDataItems.filter((item) => item["__EMPTY"] !== productCode)

		let cmsArtTemplateData = this.state.cmsArtTemplateData.filter((item) => item["Code"] !== productCode)
		this.setState({ artTemplateDataItems, cmsArtTemplateData, updateProduct: true, loading: true });
	}
	productUpdateResponse(artTemplateData) {
		if (artTemplateData.httpStatusCode == 200) {
			this.setState({
				saveProduct: false,
				updateProduct: false,
				productEdit: false,
				productAdd: false,
				saveCmsArtProduct: true,
				// getArtTemplateData: true,
				// showProductList: true,
				// productDetail: null,
			});
			this.cmsArtProductSave(this.state.updateProduct || this.state.productEdit);
		}
	}

	cmdArtProductUpdateResponse(cmsArtTemplateData) {
		if (cmsArtTemplateData.httpStatusCode == 200) {
			this.setState({
				saveCmsArtProduct: false,
				updateCmsArtProduct: false,
				productEdit: false,
				productAdd: false,
				getArtTemplateData: true,
				showProductList: true,
				productDetail: null,
			});
		}
	}

	pressCancel() {
		this.setState({
			productEdit: false,
			productAdd: false,
			showProductList: true,
			productDetail: null,
			productCode: null,
		})
	}
	productAdd() {
		this.setState({
			productAdd: true,
			showProductList: false
		})
	}

	handleChange(e) {
		let productDetail = this.state.productDetail || {}
		productDetail[e.name] = e.value
		this.setState({ productDetail });
	}

	searchProducts(e) {
		let artTemplateData = []
		let searchText = e.value.toLowerCase()
		if (searchText) {
			artTemplateData = this.state.artTemplateDataList.filter((item) => {
				if (item["__EMPTY"].toLowerCase().includes(searchText) || item["__EMPTY_1"].toLowerCase().includes(searchText)) {
					return item
				}
			})
		} else {
			artTemplateData = this.state.artTemplateDataList
		}
		this.setState({ artTemplateData, searchText });
	}

	productUpdate() {
		this.productSave(true);
	}

	productEditView(product) {
		let productDetail = this.state.productDetail || {}

		productDetail["productCode"] = product["__EMPTY"]
		productDetail["productName"] = product["__EMPTY_1"]
		productDetail["numericElementId"] = (product["__EMPTY_5"] ? product["__EMPTY_5"].split("-")[0] : "")
		productDetail["commentsElementId"] = (product["__EMPTY_14"] ? product["__EMPTY_14"].split("-")[0] : "")
		productDetail["adjustmentTypeElementId"] = (product["__EMPTY_16"] ? product["__EMPTY_16"].split("-")[0] : "")

		this.setState({
			productDetail: productDetail,
			productCode: product["__EMPTY"],
			productEdit: true,
			showProductList: false
		})
	}

	getArtTemplateSettings(data) {
		if (data && data.dataStore) {
			let artTemplateData = data.dataStore.filter((item) => (item["__EMPTY"] && item["__EMPTY_1"] && item["__EMPTY"].trim() !== "Code"))
			let searchText = this.state.searchText || ""
			this.setState({
				getCmsArtTemplateData: true,
				getArtTemplateData: false,
				artTemplateDataItems: data.dataStore,
				artTemplateDataList: artTemplateData,
				artTemplateData: artTemplateData.filter((item) => {
					if (item["__EMPTY"].toLowerCase().includes(searchText) || item["__EMPTY_1"].toLowerCase().includes(searchText)) {
						return item
					}
				}),
			});
		}
	}

	getCmsArtTemplateSettings(data) {
		if (data && data.dataStore) {
			this.setState({
				getCmsArtTemplateData: false,
				loading: false,
				getArtTemplateData: false,
				cmsArtTemplateData: data.dataStore,
			});
		}
	}

	render() {
		return (
			<>
				{
					this.state.loading && <center>
						<CircularLoader className={styles.loading_icon} dataTest="dhis2-uicore-circularloader" large />
					</center>
				}
				{
					this.state.getArtTemplateData &&
					<GetArtTemplateSettings query={artTemplateQuery} onResponse={this.getArtTemplateSettings}
					/>
				}
				{
					this.state.getCmsArtTemplateData &&
					<GetArtTemplateSettings query={cmsArtTemplateQuery} onResponse={this.getCmsArtTemplateSettings}
					/>
				}
				{
					(this.state.updateProduct || this.state.saveProduct) &&
					<UpdateProduct
						artTemplateData={this.state.artTemplateDataItems}
						productUpdateResponse={this.productUpdateResponse}
						updateProduct={this.state.updateProduct}
						type="art"
					/>
				}
				{
					(this.state.updateCmsArtProduct || this.state.saveCmsArtProduct) &&
					<UpdateProduct
						artTemplateData={this.state.cmsArtTemplateData}
						productUpdateResponse={this.cmdArtProductUpdateResponse}
						updateProduct={this.state.updateCmsArtProduct}
						type="cmsArt"
					/>
				}
				{
					this.state.showProductList &&
					<ArtProductsList
						setMessageAndError={this.props.setMessageAndError}
						artTemplateData={this.state.artTemplateData}
						productEditView={this.productEditView}
						searchProducts={this.searchProducts}
						productAdd={this.productAdd}
						deleteProduct={this.deleteProduct}
						searchText={this.state.searchText}
						artTemplateDataList={this.state.artTemplateDataList}
					/>
				}
				{
					(this.state.productEdit || this.state.productAdd) &&
					<ProductDetail
						productDetail={this.state.productDetail}
						setMessageAndError={this.props.setMessageAndError}
						productEditView={this.productEditView}
						handleChange={this.handleChange}
						pressCancel={this.pressCancel}
						productSave={this.productSave}
						productUpdate={this.productUpdate}
						productEdit={this.state.productEdit}
					/>
				}
			</>
		)
	}
}

export default ArtSettingComponent;