import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import styles from '../../Pages.module.css';
import { SingleSelect, SingleSelectOption } from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';
import { Input, Divider, AlertBar, Menu, MenuItem, Button, Table, TableHead, TableBody, TableRow, TableRowHead, TableCellHead, TableCell, CircularLoader } from '@dhis2/ui-core';

const ProductDetail = (props) => {
  return (
    <div className={styles.tabProductDetail}>
      <div className={styles.row}>
        <div className={styles.colMd3}>
          <venel>Product Code</venel>
          <Input
            value={(props.productDetail && props.productDetail.productCode) || ""}
            name="productCode"
            onChange={(e) => props.handleChange(e)}
            readOnly={props.productEdit ? true : false}
          />
        </div>
        <div className={styles.colMd10}>
          <venel>Product Name</venel>
          <Input
            value={(props.productDetail && props.productDetail.productName) || ""}
            name="productName"
            onChange={(e) => props.handleChange(e)}
          />
        </div>
      </div>
      <br />

      <div className={styles.row}>
        <div className={styles.colMd3}>
          <venel>Numeric Element ID</venel>
          <Input
            value={(props.productDetail && props.productDetail.numericElementId) || ""}
            name="numericElementId"
            onChange={(e) => props.handleChange(e)}
          />
        </div>
        <div className={styles.colMd3}>
          <venel>Comments Element ID</venel>
          <Input
            value={(props.productDetail && props.productDetail.commentsElementId) || ""}
            name="commentsElementId"
            onChange={(e) => props.handleChange(e)}
          />
        </div>
        <div className={styles.colMd3}>
          <venel>Adjustment Type Element ID</venel>
          <Input
            value={(props.productDetail && props.productDetail.adjustmentTypeElementId) || ""}
            name="adjustmentTypeElementId"
            onChange={(e) => props.handleChange(e)}
          />
        </div>
      </div>
      <br />

      <div className={styles.row}>
        <div className={styles.colMd2}>
        </div>
        <div className={styles.colMd2}>
          <Button onClick={props.productEdit ? props.productUpdate : props.productSave} large name="Primary button" primary value="default">
            SAVE
          </Button>
        </div>
        <div className={styles.colMd2}>
          <Button large name="Basic button" onClick={props.pressCancel} value="default">
            CANCEL
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;