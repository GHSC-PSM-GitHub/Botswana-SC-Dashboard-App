import React from 'react';
import { useState, useEffect } from 'react'
import { useDataEngine, DataQuery } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants'
import styles from '../../Pages.module.css';
import { SingleSelect, SingleSelectOption } from '@dhis2/ui';
import { useLocation, useHistory } from 'react-router-dom';
import { Input, Divider, AlertBar, Menu, MenuItem, Button, Table, TableHead, TableBody, TableRow, TableRowHead, TableCellHead, TableCell, CircularLoader } from '@dhis2/ui-core';

const ArtProductsList = (props) => {

  return (
    <div className={styles.tabEditSettings}>
      <div className={styles.row}>
        <div className={styles.colMd8}>
          <h3>Total {props.artTemplateDataList.length} Products</h3>
        </div>
        <div className={styles.colMd4}>
          <Button name="Primary button" onClick={props.productAdd} primary value="default">
            New Product
          </Button>
        </div>
        <div className={styles.colMd4}>
          <Input
            inputWidth="100px"
            name="seach"
            value={props.searchText}
            onChange={(e) => props.searchProducts(e)}
            placeholder="Product Code or Product Name"
          />
        </div>
      </div>
      <br />
      <div className={styles.productListTable}>
        <Table dataTest="dhis2-uicore-table">
          <TableHead dataTest="dhis2-uicore-tablehead">
            <TableRowHead dataTest="dhis2-uicore-tablerowhead">
              <TableCellHead dataTest="dhis2-uicore-tablecellhead">
                SI#
              </TableCellHead>
              <TableCellHead dataTest="dhis2-uicore-tablecellhead">
                Product Code
              </TableCellHead>
              <TableCellHead dataTest="dhis2-uicore-tablecellhead">
                Product Name
              </TableCellHead>
              <TableCellHead dataTest="dhis2-uicore-tablecellhead" colSpan="4">
                Action
              </TableCellHead>
            </TableRowHead>
          </TableHead>
          <TableBody dataTest="dhis2-uicore-tablebody">
            {
              props.artTemplateData && props.artTemplateData.map((item, index) => {
                if (item["__EMPTY"] && item["__EMPTY_2"] && item["__EMPTY"].trim() !== "Code") {
                  return (
                    <TableRow dataTest="dhis2-uicore-tablerow">
                      <TableCell dataTest="dhis2-uicore-tablecell">
                        {index + 1}
                      </TableCell>
                      <TableCell dataTest="dhis2-uicore-tablecell">
                        {item["__EMPTY"]}
                      </TableCell>
                      <TableCell dataTest="dhis2-uicore-tablecell">
                        <label>{item["__EMPTY_1"]}</label>
                      </TableCell>
                      <TableCell dense className={styles.cellSize}>
                        <Button
                          icon={<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" /></svg>}
                          name="Icon small button"
                          onClick={() => props.productEditView(item)}
                          small
                          value="default"
                        />
                        <Button
                          icon={<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" /></svg>}
                          name="Icon small button"
                          onClick={() => props.deleteProduct(item["__EMPTY"])}
                          small
                          value="default"
                        />
                      </TableCell>
                    </TableRow>
                  )
                }
              })
            }
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default ArtProductsList;