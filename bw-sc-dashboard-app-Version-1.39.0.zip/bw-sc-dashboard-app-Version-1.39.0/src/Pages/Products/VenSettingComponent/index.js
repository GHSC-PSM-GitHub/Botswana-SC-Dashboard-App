import React, { Component } from 'react';
import { Button, Input, SingleSelectOption, SingleSelect, CircularLoader } from '@dhis2/ui-core';
import styles from '../../Pages.module.css';
import {DataQuery } from '@dhis2/app-runtime'
import VenProductsList from './VenProductsList';
import ProductDetail from './ProductDetail';
import UpdateProduct from './UpdateProduct';

import Constants from '../../../helpers/constants';
import { GetVenTemplateSettings } from '../../ImportVenTemplate/venTemplateApi';

const venTemplateQuery = {
  "dataStore": {
      "resource": `dataStore/${Constants.namespace}/${Constants.VenTemplateKey}`
  }
}
const cmsVenTemplateQuery = {
  "dataStore": {
      "resource": `dataStore/${Constants.namespace}/${Constants.CmsVenTemplateKey}`
  }
}

class VenSettingComponent extends Component {
	constructor( props ) {
		super( props );
		this.state = {
			getVenTemplateData: true,
			getCmsVenTemplateData: false,
			cmsVenTemplateData:[],
			venTemplateData:[],
			venTemplateDataList: [],
			venTemplateDataItems: [],
			VenProductJsonFormat: {},
			CmsVenProductJsonFormat: {},
			productEdit: false,
			productAdd: false,
			showProductList: true,
			productCode: null,
			productDetail: null,
			updateProduct: false,
			saveProduct: false,
			updateCmsVenProduct:false,
			saveCmsVenProduct: false,
			searchText: null,
			loading: true
		}
		this.getVenTemplateSettings = this.getVenTemplateSettings.bind(this);
		this.getCmsVenTemplateSettings = this.getCmsVenTemplateSettings.bind(this);
		this.productEditView = this.productEditView.bind(this);
		this.productUpdate = this.productUpdate.bind(this);
		this.productAdd = this.productAdd.bind(this);
		this.searchProducts = this.searchProducts.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.pressCancel = this.pressCancel.bind(this);
		this.deleteProduct = this.deleteProduct.bind(this);
		this.productUpdateResponse = this.productUpdateResponse.bind(this);
		this.cmdVenProductUpdateResponse = this.cmdVenProductUpdateResponse.bind(this);
		this.productSave = this.productSave.bind(this);
		this.cmsVenProductSave = this.cmsVenProductSave.bind(this);
	}

	productSave(isEdit = false){
		let VenProductJsonFormat = Constants.VenProductJsonFormat
		let productDetail = this.state.productDetail || {}
			VenProductJsonFormat["__EMPTY"] = productDetail.productCode
			VenProductJsonFormat["__EMPTY_1"] = productDetail.productName
			VenProductJsonFormat["__EMPTY_5"] = productDetail.numericElementId+"-dWTgv7nQzp3"
			VenProductJsonFormat["__EMPTY_6"] = productDetail.numericElementId+"-cqr9Qz4S9ir"
			VenProductJsonFormat["__EMPTY_7"] = productDetail.numericElementId+"-d1ha3qv5NVz"
			VenProductJsonFormat["__EMPTY_8"] = productDetail.numericElementId+"-H8wShkXgdh5"
			VenProductJsonFormat["__EMPTY_9"] = productDetail.numericElementId+"-BH0lye2amGG"
			VenProductJsonFormat["__EMPTY_10"] = productDetail.numericElementId+"-lNjhiBWostD"
			VenProductJsonFormat["__EMPTY_11"] = productDetail.numericElementId+"-gdfxU93ELmJ"
			VenProductJsonFormat["__EMPTY_12"] = productDetail.numericElementId+"-eJcatASNrDD"
			
			VenProductJsonFormat["__EMPTY_13"] = productDetail.numericElementId+"-sgMj8LBiFW2"

			VenProductJsonFormat["__EMPTY_14"] = productDetail.numericElementId+"-X8TZ8BA9Q5w"
			VenProductJsonFormat["__EMPTY_15"] = productDetail.commentsElementId+"-f8tqseFk9CK"
			VenProductJsonFormat["__EMPTY_16"] = productDetail.numericElementId+"-qmKxrGMLfcL"
			VenProductJsonFormat["__EMPTY_17"] = productDetail.adjustmentTypeElementId+"-XxPpu51hMrn"

			VenProductJsonFormat["__EMPTY_21"] = productDetail.numericElementId+"-UXUSOHc5zOq"
			VenProductJsonFormat["__EMPTY_22"] = productDetail.numericElementId+"-sUKxIAlbTae"
			VenProductJsonFormat["__EMPTY_23"] = productDetail.numericElementId+"-PRUXDoeBnuF"
			VenProductJsonFormat["__EMPTY_24"] = productDetail.numericElementId+"-twup75lNJpt"
			VenProductJsonFormat["__EMPTY_25"] = productDetail.numericElementId+"-CN2fhPx8zAL"
			VenProductJsonFormat["__EMPTY_26"] = productDetail.numericElementId+"-JiiluEpMlcp"
			VenProductJsonFormat["__EMPTY_27"] = productDetail.numericElementId+"-ahPxmw900L3"
			VenProductJsonFormat["__EMPTY_28"] = productDetail.numericElementId+"-VP94GszpMBM"
			VenProductJsonFormat["__EMPTY_29"] = productDetail.numericElementId+"-f1kqIsBp0Y5"
			VenProductJsonFormat["__EMPTY_30"] = productDetail.numericElementId+"-fFivozbWLLH"

			VenProductJsonFormat["__EMPTY_32"] = productDetail.numericElementId + "-GRbijGRY1aU"
			VenProductJsonFormat["__EMPTY_33"] = productDetail.numericElementId + "-Q2eOWHcvLYE"
			
		let venTemplateDataItems = this.state.venTemplateDataItems;
		if(isEdit === true){
			venTemplateDataItems = venTemplateDataItems.map((template)=>{
				if(template["__EMPTY"] == productDetail.productCode){
						return VenProductJsonFormat
				}else{
						return template
				}
			})
		}else{
			venTemplateDataItems.push(VenProductJsonFormat)
		}
		this.setState({
			venTemplateDataItems,
			VenProductJsonFormat,
			saveProduct: true,
			loading: true
		})
	}

	cmsVenProductSave(isEdit = false){
		let CmsVenProductJsonFormat = Constants.CmsVenProductJsonFormat
		let productDetail = this.state.productDetail || {}
		let currentStock = CmsVenProductJsonFormat && Object.keys(CmsVenProductJsonFormat).filter((data) => data.includes("Current stock"))[0]


		CmsVenProductJsonFormat["Code"] = productDetail.productCode
		CmsVenProductJsonFormat["Description"] = productDetail.productName
		CmsVenProductJsonFormat[" Unit Price (bwp) "] = productDetail.numericElementId+"-UXUSOHc5zOq"
		CmsVenProductJsonFormat[currentStock] = productDetail.numericElementId+"-gdfxU93ELmJ"

		let cmsVenTemplateData = this.state.cmsVenTemplateData;
		if(isEdit === true){
			cmsVenTemplateData = cmsVenTemplateData.map((template)=>{
				if(template["Code"] == productDetail.productCode){
						return CmsVenProductJsonFormat
				}else{
						return template
				}
			})
		}else{
			cmsVenTemplateData.push(CmsVenProductJsonFormat)
		}
		this.setState({
			cmsVenTemplateData,
			CmsVenProductJsonFormat,
			saveCmsVenProduct: true,
			loading: true
		})
	}

	deleteProduct(productCode){
		let venTemplateDataItems = this.state.venTemplateDataItems.filter((item) => item["__EMPTY"] !== productCode)

		let cmsVenTemplateData = this.state.cmsVenTemplateData.filter((item) => item["Code"] !== productCode)
		this.setState({venTemplateDataItems, cmsVenTemplateData, updateProduct: true, loading: true});
	}
	productUpdateResponse(venTemplate_data){
		if(venTemplate_data.httpStatusCode==200){
			this.setState({
				saveProduct: false,
				updateProduct: false,
				productEdit: false,
				productAdd: false,
				saveCmsVenProduct: true,
				// getVenTemplateData: true,
				// showProductList: true,
				// productDetail: null,
			});
			this.cmsVenProductSave(this.state.updateProduct || this.state.productEdit);
		}
	}

	cmdVenProductUpdateResponse(cmsVenTemplateData){
		if(cmsVenTemplateData.httpStatusCode==200){
			this.setState({
				saveCmsVenProduct: false,
				updateCmsVenProduct: false,
				productEdit: false,
				productAdd: false,
				getVenTemplateData: true,
				showProductList: true,
				productDetail: null,
			});
		}
	}

	pressCancel(){
		this.setState({
			productEdit: false,
			productAdd: false,
			showProductList: true,
			productDetail: null,
			productCode: null,
		})
	}
	productAdd(){
		this.setState({
			productAdd: true,
			showProductList: false
		})
	}

	handleChange(e){
		let productDetail = this.state.productDetail || {}
		productDetail[e.name] = e.value
		this.setState({productDetail});
	}

	searchProducts(e){
		let venTemplateData = []
		let searchText = e.value.toLowerCase()
		if(searchText){
			venTemplateData = this.state.venTemplateDataList.filter((item) => {
				if(item["__EMPTY"].toLowerCase().includes(searchText) || item["__EMPTY_1"].toLowerCase().includes(searchText)){
					return item
				}
			})
		}else{
			venTemplateData = this.state.venTemplateDataList
		}
		this.setState({venTemplateData, searchText});
	}

	productUpdate(){
		this.productSave(true);
	}

	productEditView(product){
		let productDetail = this.state.productDetail || {}

		productDetail["productCode"] = product["__EMPTY"]
		productDetail["productName"] = product["__EMPTY_1"]
		productDetail["numericElementId"] = (product["__EMPTY_5"] ? product["__EMPTY_5"].split("-")[0] : "")
		productDetail["commentsElementId"] =  (product["__EMPTY_14"] ? product["__EMPTY_14"].split("-")[0] : "")
		productDetail["adjustmentTypeElementId"] =  (product["__EMPTY_16"] ? product["__EMPTY_16"].split("-")[0] : "")

		this.setState({
			productDetail: productDetail,
			productCode: product["__EMPTY"],
			productEdit: true,
			showProductList: false
		})
	}

	getVenTemplateSettings(data){
		if(data && data.dataStore){
			let venTemplateData = data.dataStore.filter((item)=> (item["__EMPTY"] && item["__EMPTY_1"] && item["__EMPTY"].trim() !== "Code"))
			let searchText = this.state.searchText || ""
			this.setState({
				getCmsVenTemplateData: true,
				getVenTemplateData: false,
				venTemplateDataItems: data.dataStore,
				venTemplateDataList: venTemplateData,
				venTemplateData: venTemplateData.filter((item) => {
					if(item["__EMPTY"].toLowerCase().includes(searchText) || item["__EMPTY_1"].toLowerCase().includes(searchText)){
						return item
					}
				}),
			});
		}
	}

	getCmsVenTemplateSettings(data){
		if(data && data.dataStore){
			this.setState({
				getCmsVenTemplateData: false,
				loading: false,
				getVenTemplateData: false,
				cmsVenTemplateData: data.dataStore,
			});
		}
	}

	render(){
		return(
			<>
				{
					this.state.loading && <center>
						<CircularLoader className={styles.loading_icon}  dataTest="dhis2-uicore-circularloader" large />
					</center>
				}
				{
					this.state.getVenTemplateData &&
					<GetVenTemplateSettings query = {venTemplateQuery} onResponse = {this.getVenTemplateSettings}
					/>
				}
				{
					this.state.getCmsVenTemplateData &&
					<GetVenTemplateSettings query = {cmsVenTemplateQuery} onResponse = {this.getCmsVenTemplateSettings}
					/>
				}
				{
					(this.state.updateProduct || this.state.saveProduct) &&
					<UpdateProduct
						venTemplateData = {this.state.venTemplateDataItems}
						productUpdateResponse = {this.productUpdateResponse}
						updateProduct = {this.state.updateProduct}
						type = "ven"
					/>
				}
				{
					(this.state.updateCmsVenProduct || this.state.saveCmsVenProduct) &&
					<UpdateProduct
						venTemplateData = {this.state.cmsVenTemplateData}
						productUpdateResponse = {this.cmdVenProductUpdateResponse}
						updateProduct = {this.state.updateCmsVenProduct}
						type = "cmsVen"
					/>
				}
				{
					this.state.showProductList &&
						<VenProductsList
						setMessageAndError = {this.props.setMessageAndError}
						venTemplateData = {this.state.venTemplateData}	
						productEditView = {this.productEditView}
						searchProducts = {this.searchProducts}
						productAdd = {this.productAdd}
						deleteProduct = {this.deleteProduct}
						searchText = {this.state.searchText}
						venTemplateDataList = {this.state.venTemplateDataList}
					/>
				}
				{
					(this.state.productEdit || this.state.productAdd) &&
					<ProductDetail
						productDetail = {this.state.productDetail}
						setMessageAndError = {this.props.setMessageAndError}
						productEditView = {this.productEditView}
						handleChange = {this.handleChange}
						pressCancel = {this.pressCancel}
						productSave = {this.productSave}
						productUpdate = {this.productUpdate}
						productEdit = {this.state.productEdit}
					/>
				}
			</>
		)
	}
}

export default VenSettingComponent;