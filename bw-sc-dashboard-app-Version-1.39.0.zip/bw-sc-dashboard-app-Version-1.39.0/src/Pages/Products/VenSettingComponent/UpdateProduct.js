import React from 'react';
import { useState, useEffect } from 'react'
import { useConfig } from '@dhis2/app-runtime'
import Constants from '../../../helpers/constants';
import { venTemplateUpdateSettings, cmsVenTemplateUpdateSettings } from '../../../actions/settings';

const UpdateProduct = (props) => {
  const { baseUrl, apiVersion } = useConfig();  
  useEffect(() => {    
  }, []);

  if(props.type == "ven"){
    let venTemplateSettings = Constants.VenTemplateSettingsCreate
    venTemplateSettings["data"] = props.venTemplateData
    venTemplateSettings["type"] = "update"

    const { venTemplate_update_loading, venTemplate_update_req, venTemplate_update_data, venTemplate_update_error } = venTemplateSettings && venTemplateSettings.data && venTemplateUpdateSettings(venTemplateSettings)

    if(venTemplate_update_data && venTemplate_update_data.httpStatusCode && venTemplate_update_data.httpStatusCode==200){
      props.productUpdateResponse(venTemplate_update_data)
    }
  }

  if(props.type == "cmsVen"){
    let cmsVenTemplateSettings = Constants.CmsVenTemplateSettingsCreate
    cmsVenTemplateSettings["data"] = props.venTemplateData
    cmsVenTemplateSettings["type"] = "update"

    const { cmsVenTemplate_update_loading, cmsVenTemplate_update_req, cmsVenTemplate_update_data, cmsVenTemplate_update_error } = cmsVenTemplateSettings && cmsVenTemplateSettings.data && cmsVenTemplateUpdateSettings(cmsVenTemplateSettings)

    if(cmsVenTemplate_update_data && cmsVenTemplate_update_data.httpStatusCode && cmsVenTemplate_update_data.httpStatusCode==200){
      props.productUpdateResponse(cmsVenTemplate_update_data)
    }
  }
  return (
    <>
    </>
  );
};

export default UpdateProduct;