import React, { useState, useEffect, useLayoutEffect } from "react";
import styles from "./App.module.css";
import { HashRouter } from "react-router-dom";
import { Sidebar } from "./components/Sidebar/Sidebar";
import { Router } from "./components/Router/Router";
import AppInitialSettings from "./Pages/Settings/AppInitialSettings";
import ArtTemplateAppLogs from "./Pages/ImportArtTemplate/ArtTemplateAppLogs";
import { useUser } from "./hooks/useUser";

import { Button } from "@dhis2/ui";
import Constants from "./helpers/constants";
import { useDataEngine } from "@dhis2/app-runtime";

const meandsettings = {
  dataStore: {
    resource: `dataStore/${Constants.namespace}/${Constants.GeneralKey}`,
  },
  me: {
    resource: "me",
    params: {
      fields: ["userCredentials[userRoles[id,name]]"],
    },
  },
};

const genSettingsQuery = {
  dataStore: {
    resource: `dataStore/Excel-Import-App/General-Settings`,
  },
};

const MyApp = () => {
  const engine = useDataEngine();
  const { loading, error, user } = useUser();
  const [importTemplateLogs, setImportTemplateLogs] = useState([]);
  const [sideToggleActive, changeActiveToggle] = useState(true);
  const [userRoles, setUserRoles] = useState([]);
  //const [operatorRoleOptions, setOperatorRoleOption] = useState([]);
  const [currentUserRole, setCurrentUserRole] = useState(null);
  const [generalSettingData, setGeneralSettingData] = useState({
    AdjustmentOptionSet: "",
    LossOptionSet: "",
    AdminRole: "",
    OperatorRole: "",
  });

  const [userGuideURL, setUserGuideURL] = useState("");

  const getGeneralSettings = async () => {
    const genSettings = await engine.query(genSettingsQuery);
    const genSettingsResult = genSettings.dataStore;
    setUserGuideURL(genSettingsResult.UserGuidURL);
    console.log("genSettingsResult: ", genSettingsResult.UserGuidURL);
  };

  const functionExample = (userRoles, generalSettings) => {
    //console.log("functionExample",userRoles, generalSettings);
    let isAdmin = false;
    let currentUserRole = null;
    //console.log("gsadminrole:",generalSettings.AdminRole);
    if (userRoles.length && generalSettings.AdminRole) {
      let adminRole = userRoles.find((role) => role["name"] == "Superuser");
      if (adminRole && adminRole.name) {
        isAdmin = true;
        currentUserRole = "admin";
      }
      if (isAdmin == false) {
        let adminRole = userRoles.find(
          (role) => role["id"] == generalSettings.AdminRole
        );
        if (adminRole) {
          isAdmin = true;
          currentUserRole = "admin";
        }
      }
      if (isAdmin == false) {
        let operatorRole = userRoles.find(
          (role) => role["id"] == generalSettings.OperatorRole
        );
        if (operatorRole) {
          currentUserRole = "operator";
        }
      }

      console.log("CURRENT USER ROLE:", currentUserRole);
      setCurrentUserRole(currentUserRole);
    }
  };

  useLayoutEffect(() => {
    console.log("I am called only once");
    engine.query(meandsettings, {
      onComplete: (data) => {
        console.log("meandsettings", data);
        const generalSettings = data.dataStore;
        const userRoles = data.me.userCredentials.userRoles;
        console.log("datastore, user", userRoles, generalSettings);
        functionExample(userRoles, generalSettings);
      },
      onError: (error) => {
        //setError(error.message);
        console.error("error: ", error.message);
        if (
          error &&
          error.details &&
          error.details.httpStatusCode &&
          error.details.httpStatusCode == 404
        ) {
          location.reload();
        }
      },
    });

    getGeneralSettings();
  }, []);

  return (
    <>
      <AppInitialSettings />

      {userGuideURL && <HashRouter>
        <div
          className={sideToggleActive ? styles.container : styles.fullContainer}
        >
          <div className={sideToggleActive ? styles.sidebar : styles.MenuHide}>      
              <Sidebar
                sideToggleActive={sideToggleActive}
                currentUserRole={currentUserRole}
                userGuideURL={userGuideURL}
              />            
          </div>
          <Button
            style={{ outline: "none" }}
            className={
              sideToggleActive
                ? styles.collapseMenuActive
                : styles.collapseMenuInactive
            }
            dataTest="dhis2-uicore-button"
            icon={
              sideToggleActive ? (
                <svg
                  width="24"
                  height="24"
                  xmlns="http://www.w3.org/2000/svg"
                  fillRule="evenodd"
                  clipRule="evenodd"
                >
                  <path d="M20 .755l-14.374 11.245 14.374 11.219-.619.781-15.381-12 15.391-12 .609.755z" />
                </svg>
              ) : (
                <svg
                  width="24"
                  height="24"
                  xmlns="http://www.w3.org/2000/svg"
                  fillRule="evenodd"
                  clipRule="evenodd"
                >
                  <path d="M4 .755l14.374 11.245-14.374 11.219.619.781 15.381-12-15.391-12-.609.755z" />
                </svg>
              )
            }
            name="Icon button"
            type="button"
            value="default"
            onClick={() => {
              changeActiveToggle(!sideToggleActive);
            }}
          />

          <main
            className={sideToggleActive ? styles.content : styles.fullContent}
          >
            <ArtTemplateAppLogs
              setImportTemplateLogs={setImportTemplateLogs}
              importTemplateLogs={importTemplateLogs}
            />
            {!loading && (
              <Router
                user={user}
                importTemplateLogs={importTemplateLogs}
                currentUserRole={currentUserRole}
              />
            )}
          </main>
        </div>
      </HashRouter>}
    </>
  );
};

export default MyApp;
