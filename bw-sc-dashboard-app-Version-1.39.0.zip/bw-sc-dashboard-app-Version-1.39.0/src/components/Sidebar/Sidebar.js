
import React, { useState } from 'react';

import { useLocation, useHistory } from 'react-router-dom'
import PropTypes from 'prop-types'
import cx from 'classnames'
import i18n from '@dhis2/d2-i18n'
import { Divider, Menu, MenuItem, Button } from '@dhis2/ui'
import styles from './Sidebar.module.css'

const homePage = {
    name: i18n.t('Home'),
    code: 'Home',
    //icon: <DataIcon />,
    path: '/',
}

const importPage = {
    name: i18n.t('Import'),
    code: 'import',
    //icon: <DataIcon />,
    path: '/import',
}

const importArtTemplatePage = {
  name: i18n.t("Import ARV LMIS Report"),
  code: "import-art-template",
  //icon: <DataIcon />,
  path: "/import-art-template",
};

const importVENTemplatePage = {
  name: i18n.t("Import VEN LMIS Report"),
  code: "import-ven-template",
  //icon: <DataIcon />,
  path: "/import-ven-template",
};

const importLabTemplatePage = {
  name: i18n.t("Import LAB LMIS Report"),
  code: "import-lab-template",
  //icon: <DataIcon />,
  path: "/import-lab-template",
};

const importPulseWMSDataPage = {
  name: i18n.t("Import CMS Stock Report"),
  code: "import-pulse-wms-data",
  //icon: <DataIcon />,
  path: "/import-pulse-wms-data",
};

// const importPipelineDataPage = {
//   name: i18n.t("Import QAT/S. Plan Data Excel"),
//   code: "import-pipeline-data",
//   //icon: <DataIcon />,
//   path: "/import-pipeline-data",
// };

const importQATSPlanDataPage = {
  name: i18n.t("Import QAT/S. Plan Data"),
  code: "import-qats-data",
  //icon: <DataIcon />,
  path: "/import-qats-plan-data",
};

const settings = {
    name: i18n.t('Settings'),
    code: 'settings',
    //icon: <DataIcon />,
    path: '/settings',
}

const products = {
    name: i18n.t('Products'),
    code: 'products',
    //icon: <DataIcon />,
    path: '/products',
}

const userGuide = {
  name: i18n.t("User Guide"),
  code: "user-guide",
  //icon: <DataIcon />,
  path: "/user-guide",
};


const allPages = [    
    importPage,  
    importArtTemplatePage,  
    importVENTemplatePage,
    importLabTemplatePage,
    importPulseWMSDataPage,
    //importPipelineDataPage,
    importQATSPlanDataPage,
    settings,
    products,
    userGuide
]

const SidebarItem = ({ name, path, code, active, className, userGuideURL }) => {
 // console.log('userGuideURL 888: ', userGuideURL);
    const history = useHistory()
    const navigateToPath = () => history.push(path)

    const userGuidelink = () => window.open(userGuideURL);

    return (
        <MenuItem
            active={active}
            onClick={code === "user-guide" ? userGuidelink : navigateToPath}
            label={name}
            className={cx(className, {
                [styles.sidebarItem]: !active,
                [styles.sidebarItemActive]: active,
            })}
            dataTest={`sidebar-link-${code}`}
        />
    )
}

SidebarItem.propTypes = {
    active: PropTypes.bool.isRequired,
    code: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    path: PropTypes.string.isRequired,
    className: PropTypes.string,
}

const Sidebar = (props) => {
    const location = useLocation()
    const pathname = location.pathname
    const { currentUserRole, userGuideURL } = props

    return (
      <>
        <Menu className={styles.Menu}>
            {allPages.map(({ icon, name, code, path }) => {
                const active = pathname == path
                if (currentUserRole) {     
                    if(!["settings", "products"].includes(code) || currentUserRole == "admin"){
                    return (
                        <SidebarItem
                            name={name}
                            path={path}
                            code={code}
                            icon={icon}
                            active={active}
                            key={path}
                            userGuideURL={userGuideURL}
                        />
                    )
                    }
                }
                  
            })}            
        </Menu>       
      </>
    )
}

export { Sidebar }
