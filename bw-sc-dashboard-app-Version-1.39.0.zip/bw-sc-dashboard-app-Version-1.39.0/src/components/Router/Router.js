import React from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import { Home } from "../../Pages/Home/Home";
import ImportArtTemplate from "../../Pages/ImportArtTemplate";
import ImportLabTemplate from "../../Pages/ImportLabTemplate";
import ImportPulseWMSData from "../../Pages/ImportPulseWMSData";
import ImportPipelineTemplate from "../../Pages/ImportPipelineTemplate";
import ImportQATSPlanData from "../../Pages/ImportQATSPlanData";
import Import from "../../Pages/Import/Import";
import ImportVenTemplate from "../../Pages/ImportVenTemplate";
import Settings from "../../Pages/Settings";
import Products from "../../Pages/Products";

const Router = (props) => {
  return (
    <Switch>
      <Route exact path="/" render={() => <Import user={props.user} />} />

      <Route path="/import" render={() => <Import user={props.user} />} />

      <Route
        path="/import-art-template"
        render={() => (
          <ImportArtTemplate
            user={props.user}
            importTemplateLogs={props.importTemplateLogs}
          />
        )}
      />
      <Route
        path="/import-ven-template"
        render={() => (
          <ImportVenTemplate
            user={props.user}
            importTemplateLogs={props.importTemplateLogs}
          />
        )}
      />
      <Route
        path="/import-lab-template"
        render={() => (
          <ImportLabTemplate
            user={props.user}
            importTemplateLogs={props.importTemplateLogs}
          />
        )}
      />
      <Route
        path="/import-pulse-wms-data"
        render={() => (
          <ImportPulseWMSData
            user={props.user}
            importTemplateLogs={props.importTemplateLogs}
          />
        )}
      />
      {/* <Route
        path="/import-pipeline-data"
        render={() => (
          <ImportPipelineTemplate
            user={props.user}
            importTemplateLogs={props.importTemplateLogs}
          />
        )}
      /> */}

      <Route
        path="/import-qats-plan-data"
        render={() => (
          <ImportQATSPlanData
            user={props.user}
            importTemplateLogs={props.importTemplateLogs}
          />
        )}
      />

      {props.currentUserRole == "admin" && (
        <Route path="/settings" component={Settings} />
      )}
      {props.currentUserRole == "admin" && (
        <Route path="/products" component={Products} />
      )}
      <Redirect from="*" to="/import" />
    </Switch>
  );
};

export { Router };
