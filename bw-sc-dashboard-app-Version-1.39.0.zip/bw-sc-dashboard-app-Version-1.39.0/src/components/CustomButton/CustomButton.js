import React from 'react';
import './CustomButton.css'; // Import the CSS for styling the button

const CustomButton = ({ text, size, onClick, isLoading }) => {
    const sizeClass = size === 'large' ? 'large-button' : size === 'small' ? 'small-button' : 'medium-button';

    return (
        <button
            className={`custom-button ${sizeClass}`}
            onClick={onClick}
            disabled={isLoading} // Disable the button if isLoading is true
        >
            {text}
        </button>
    );
};

export default CustomButton;