const config = {
    type: 'app',
    name: 'excel-import',
    title: 'Excel Import',

    entryPoints: {
        app: './src/App',
    },
}

module.exports = config
